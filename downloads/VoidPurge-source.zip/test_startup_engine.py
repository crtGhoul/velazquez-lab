import os, winreg, subprocess, json
from pathlib import Path
from typing import List, Dict, Any, Tuple

STARTUP_CRITICAL_DRIVERS = [
    "rtkauduservice", "securityhealth", "realtek", "vanguard", "vgtray",
    "nvidia", "amd", "radeon", "intel", "touchpad", "synaptics", "audio",
    "tailscale", "wireless", "bluetooth"
]

STARTUP_BLOAT_KEYWORDS = [
    "logitech download assistant", "logilda", "microsoftedgeautolaunch",
    "edge", "af_counter", "af_uuid", "onedrive", "cortana", "telemetry",
    "update assistant", "browser helper", "ccleaner", "skype", "teams",
    "updater", "crashpad", "errorreporting"
]

def assess_startup_safety(name: str, command: str) -> Tuple[str, str]:
    nl = (name or "").lower()
    cl = (command or "").lower()

    for kw in STARTUP_CRITICAL_DRIVERS:
        if kw in nl or kw in cl:
            return "CRITICAL_DRIVER", "Hardware Driver / Windows Security (Keep Enabled)"

    for kw in STARTUP_BLOAT_KEYWORDS:
        if kw in nl or kw in cl:
            return "STARTUP_BLOAT", "Startup Bloatware / Background Autostart (Safe to Disable)"

    return "USER_APP", "User Application (Disable to accelerate Windows boot)"

def test_startup_scan(show_system_tasks: bool = False):
    entries = []
    seen = set()

    # 1. Startup Folders
    appdata = Path(os.environ.get("APPDATA", ""))
    programdata = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))
    folders = [
        (appdata / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup", "Startup Folder (User)"),
        (programdata / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup", "Startup Folder (Common)"),
    ]
    for fpath, src in folders:
        if fpath.exists():
            for item in fpath.iterdir():
                if item.name.lower() != "desktop.ini":
                    uid = f"file::{item.name.lower()}"
                    if uid not in seen:
                        seen.add(uid)
                        s_tier, s_desc = assess_startup_safety(item.name, str(item))
                        entries.append({
                            "name": item.name,
                            "command": str(item),
                            "source": src,
                            "file_path": str(item),
                            "safety_tier": s_tier,
                            "safety_desc": s_desc,
                            "enabled": True,
                        })

    # 2. Registry Run Keys
    REG_LOCS = [
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKCU Run"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU RunOnce"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM Run"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run", "HKLM Run (32-bit)"),
    ]
    for root, path, src in REG_LOCS:
        try:
            with winreg.OpenKey(root, path, 0, winreg.KEY_READ) as k:
                _, val_count, _ = winreg.QueryInfoKey(k)
                for i in range(val_count):
                    try:
                        n, d, _ = winreg.EnumValue(k, i)
                        uid = f"reg::{src}::{n.lower()}"
                        if uid in seen: continue
                        seen.add(uid)
                        s_tier, s_desc = assess_startup_safety(n, str(d))
                        entries.append({
                            "name": n,
                            "command": str(d),
                            "source": src,
                            "registry_path": path,
                            "registry_root": "HKCU" if root == winreg.HKEY_CURRENT_USER else "HKLM",
                            "safety_tier": s_tier,
                            "safety_desc": s_desc,
                            "enabled": True,
                        })
                    except OSError:
                        pass
        except OSError:
            pass

    # 3. Task Scheduler
    try:
        if show_system_tasks:
            ps = r'Get-ScheduledTask | Where-Object { $_.Triggers | Where-Object { $_.CimClass.CimClassName -like "*Logon*" -or $_.CimClass.CimClassName -like "*Boot*" } } | Select-Object TaskName, TaskPath | ConvertTo-Json -Compress'
        else:
            ps = r'Get-ScheduledTask | Where-Object { $_.TaskPath -notlike "\Microsoft\Windows\*" -and ($_.Triggers | Where-Object { $_.CimClass.CimClassName -like "*Logon*" -or $_.CimClass.CimClassName -like "*Boot*" }) } | Select-Object TaskName, TaskPath | ConvertTo-Json -Compress'
        raw = subprocess.check_output(["powershell", "-NoProfile", "-Command", ps], text=True).strip()
        if raw:
            tasks = json.loads(raw)
            if isinstance(tasks, dict): tasks = [tasks]
            for t in tasks:
                tname = t.get("TaskName", "")
                tpath = t.get("TaskPath", "")
                uid = f"task::{tname.lower()}"
                if uid in seen: continue
                seen.add(uid)
                s_tier, s_desc = assess_startup_safety(tname, tpath)
                entries.append({
                    "name": tname,
                    "command": f"Task Scheduler: {tpath}\\{tname}",
                    "source": "Task Scheduler",
                    "task_name": tname,
                    "safety_tier": s_tier,
                    "safety_desc": s_desc,
                    "enabled": True,
                })
    except Exception:
        pass

    entries.sort(key=lambda x: (0 if x["safety_tier"] == "STARTUP_BLOAT" else 1 if x["safety_tier"] == "USER_APP" else 2, x["name"].lower()))
    return entries

results = test_startup_scan(show_system_tasks=False)
print(f"Discovered {len(results)} clean startup entries:")
bloat = [e for e in results if e['safety_tier'] == 'STARTUP_BLOAT']
drivers = [e for e in results if e['safety_tier'] == 'CRITICAL_DRIVER']
user_apps = [e for e in results if e['safety_tier'] == 'USER_APP']

print(f"\n🚨 Startup Bloatware Detected ({len(bloat)}):")
for b in bloat:
    print(f"  • {b['name']} [{b['source']}]")

print(f"\n🛡️ Protected Drivers & Security ({len(drivers)}):")
for d in drivers:
    print(f"  • {d['name']} [{d['source']}]")

print(f"\n👤 User Applications ({len(user_apps)}):")
for u in user_apps:
    print(f"  • {u['name']} [{u['source']}]")
