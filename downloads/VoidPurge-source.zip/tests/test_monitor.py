"""Linux-runnable tests for voidpurge/monitor.py (pure diff logic).

take_snapshot() is Windows-only; diff_snapshots() is pure and tested here
with hand-built snapshot dicts.
"""
import os
import sys
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

_fake_winreg = types.ModuleType("winreg")
_fake_winreg.HKEY_CURRENT_USER = 0
_fake_winreg.HKEY_LOCAL_MACHINE = 1
_fake_winreg.KEY_READ = 0x20019
sys.modules["winreg"] = _fake_winreg

import voidpurge.monitor as monitor

FAILURES = []


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        FAILURES.append(name)


def blank():
    return {"reg_keys": {}, "reg_values": {}, "services": set(),
            "tasks": set(), "dirs": {}}


# Empty / empty -> nothing
r = monitor.diff_snapshots(blank(), blank())
check("empty diff -> no items", r == {"files": [], "registry": []})
check("empty before -> no crash, no items",
      monitor.diff_snapshots({}, blank()) == {"files": [], "registry": []})

before = blank()
after = blank()
after["dirs"] = {r"C:\Program Files": {"Windhawk", "Common Files"}}
before["dirs"] = {r"C:\Program Files": {"Common Files"}}
after["reg_keys"] = {(1, "path"): {"Windhawk"}, (0, "p2"): set()}
before["reg_keys"] = {(1, "path"): set(), (0, "p2"): set()}
after["reg_values"] = {(0, "run"): {"WindhawkTray"}}
before["reg_values"] = {(0, "run"): set()}
after["services"] = {"WindhawkService"}
before["services"] = set()
after["tasks"] = {"\\WindhawkUpdater"}
before["tasks"] = set()

r = monitor.diff_snapshots(before, after)
check("new dir detected", any(i["name"] == "Windhawk" and i["type"] == "folder" for i in r["files"]))
check("unchanged dir not flagged", not any(i["name"] == "Common Files" for i in r["files"]))
check("new reg key detected", any(i["name"] == "Windhawk" and i["type"] == "registry" for i in r["registry"]))
check("new run value detected",
      any(i["type"] == "registry_value" and i.get("value_name") == "WindhawkTray" for i in r["registry"]))
check("new service detected", any(i["type"] == "service" and i["name"] == "WindhawkService" for i in r["files"]))
check("new task detected", any(i["type"] == "task" for i in r["files"]))
check("monitor items carry confidence 95",
      all(i.get("confidence") == 95 for i in r["files"] + r["registry"]))
check("monitor items carry reason",
      all(i.get("reasons") for i in r["files"] + r["registry"]))

# take_snapshot is inert on Linux
check("take_snapshot -> {} on linux", monitor.take_snapshot() == {})

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILED: {FAILURES}")
    sys.exit(1)
print("ALL MONITOR TESTS PASSED")
