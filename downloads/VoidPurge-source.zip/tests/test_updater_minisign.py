"""Linux-runnable tests for the VoidPurge auto-updater security fix.

Covers: minisign Ed25519 signature accept/reject (our tool's format AND real
minisign's "ED" prehashed mode), fail-closed behavior on every bad input,
Codeberg releases API parsing, and the download/verify/apply flow with the
destructive tail mocked out.

Run: /tmp/updtest/bin/python tests/test_updater_minisign.py
"""
import base64
import io
import json
import os
import secrets
import sys
import tempfile
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import voidpurge.updater as updater
from nacl.signing import SigningKey

FAILURES = []


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        FAILURES.append(name)


# ---------------------------------------------------------------- helpers
def make_keypair():
    """Throwaway test keypair in OUR release tooling's format (never the real key)."""
    sk = SigningKey.generate()
    keynum = secrets.token_bytes(8)
    pub = sk.verify_key.encode()
    pubkey_str = base64.b64encode(b"Ed" + keynum + pub).decode()
    return sk, keynum, pubkey_str


def our_minisig(sk, keynum, data: bytes) -> str:
    """Replicate ~/workspace/signing/minisign.py sign() output exactly."""
    sig = sk.sign(data).signature
    blob = base64.b64encode(b"Ed" + keynum + sig).decode()
    return "untrusted comment: signature from minisign secret key\n" + blob + "\n"


def real_minisign_hashed_minisig(sk, keynum, data: bytes) -> str:
    """Real `minisign -H` style: b"ED" algo over BLAKE2b-512(data)."""
    import hashlib
    digest = hashlib.blake2b(data, digest_size=64).digest()
    sig = sk.sign(digest).signature
    blob = base64.b64encode(b"ED" + keynum + sig).decode()
    return "untrusted comment: signature from minisign secret key\n" + blob + "\n"


def tmpfile(data: bytes) -> Path:
    p = Path(tempfile.mkdtemp()) / "payload.bin"
    p.write_bytes(data)
    return p


# ---------------------------------------------------------------- verify: accept
sk, keynum, pubkey = make_keypair()
payload = os.urandom(4096)
f = tmpfile(payload)
sig = our_minisig(sk, keynum, payload)
check("valid our-format signature verifies",
      updater.verify_minisign_signature(f, sig, pubkey) is True)

# ---------------------------------------------------------------- verify: reject paths (all must be False = fail closed)
tampered = bytearray(payload)
tampered[100] ^= 0xFF
ft = tmpfile(bytes(tampered))
check("tampered file bytes rejected",
      updater.verify_minisign_signature(ft, sig, pubkey) is False)

sk2, keynum2, pubkey2 = make_keypair()
sig_other_key = our_minisig(sk2, keynum2, payload)
check("signature from different key rejected",
      updater.verify_minisign_signature(f, sig_other_key, pubkey) is False)

check("garbage signature rejected",
      updater.verify_minisign_signature(f, "not base64 at all!!!", pubkey) is False)
check("empty signature rejected",
      updater.verify_minisign_signature(f, "", pubkey) is False)
check("wrong-length signature rejected",
      updater.verify_minisign_signature(
          f, "untrusted comment: x\n" + base64.b64encode(b"short").decode() + "\n",
          pubkey) is False)

# keynum mismatch: valid sig bytes but re-wrapped under a different key number
raw = base64.b64decode(our_minisig(sk, keynum, payload).splitlines()[1])
bad_keynum_blob = base64.b64encode(raw[0:2] + secrets.token_bytes(8) + raw[10:]).decode()
check("key number mismatch rejected",
      updater.verify_minisign_signature(
          f, "untrusted comment: x\n" + bad_keynum_blob + "\n", pubkey) is False)

# missing file
check("missing file rejected",
      updater.verify_minisign_signature(Path("/no/such/file.bin"), sig, pubkey) is False)

# ---------------------------------------------------------------- real minisign compatibility
hashed_sig = real_minisign_hashed_minisig(sk, keynum, payload)
check("real minisign -H (ED prehashed) signature verifies",
      updater.verify_minisign_signature(f, hashed_sig, pubkey) is True)

# classic minisign pubkey string format: "RW" + base64(keynum||pubkey)
classic_pub = "RW" + base64.b64encode(keynum + sk.verify_key.encode()).decode()
check("classic minisign pubkey format accepted",
      updater.verify_minisign_signature(f, sig, classic_pub) is True)

check("malformed pubkey rejected",
      updater.verify_minisign_signature(f, sig, "garbage-key") is False)

# ---------------------------------------------------------------- check_for_updates: Codeberg API parsing
GITEA_RELEASE = {
    "tag_name": "v1.3.0",
    "name": "VoidPurge v1.3.0",
    "body": "signed updater",
    "html_url": "https://codeberg.org/crtGhoul/VoidPurge/releases/tag/v1.3.0",
    "assets": [
        {"name": "VoidPurge.exe",
         "browser_download_url": "https://codeberg.org/crtGhoul/VoidPurge/releases/download/v1.3.0/VoidPurge.exe"},
        {"name": "VoidPurge.exe.minisig",
         "browser_download_url": "https://codeberg.org/crtGhoul/VoidPurge/releases/download/v1.3.0/VoidPurge.exe.minisig"},
    ],
}


class FakeResp:
    def __init__(self, payload, status=200):
        self._payload = payload
        self.status = status

    def read(self):
        return self._payload

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def fake_urlopen_factory(payload_obj, status=200):
    def _fake(req, timeout=None):
        assert "codeberg.org/api/v1/repos/crtGhoul/VoidPurge/releases/latest" in req.full_url, \
            f"updater must query Codeberg, got {req.full_url}"
        return FakeResp(json.dumps(payload_obj).encode(), status)
    return _fake


with mock.patch.object(updater.urllib.request, "urlopen",
                       fake_urlopen_factory(GITEA_RELEASE)):
    info = updater.check_for_updates()
check("Codeberg release parsed", info is not None)
check("exe url found", info and info["download_url"].endswith("VoidPurge.exe"))
check(".minisig url found", info and info["minisig_url"].endswith("VoidPurge.exe.minisig"))
check("version compare works", info and info["latest_version"] == "v1.3.0")

no_sig = dict(GITEA_RELEASE)
no_sig["assets"] = [a for a in GITEA_RELEASE["assets"] if not a["name"].endswith(".minisig")]
with mock.patch.object(updater.urllib.request, "urlopen", fake_urlopen_factory(no_sig)):
    info2 = updater.check_for_updates()
check("release without .minisig -> minisig_url None (caller must refuse)",
      info2 is not None and info2["minisig_url"] is None)

old = dict(GITEA_RELEASE, tag_name="v1.0.0")
with mock.patch.object(updater.urllib.request, "urlopen", fake_urlopen_factory(old)):
    check("older release -> no update", updater.check_for_updates() is None)

with mock.patch.object(updater.urllib.request, "urlopen",
                       fake_urlopen_factory({}, status=404)):
    check("API error -> no update", updater.check_for_updates() is None)

# ---------------------------------------------------------------- download_and_apply_update: fail closed
os.environ["TEMP"] = tempfile.mkdtemp()


def fake_retrieve(url, filename, reporthook=None):
    Path(filename).write_bytes(b"X" * 2_000_000)  # > 1MB size gate


with mock.patch.object(updater.urllib.request, "urlretrieve", fake_retrieve):
    check("missing minisig_url -> False, temp cleaned",
          updater.download_and_apply_update("https://x/y.exe", minisig_url=None,
                                            exe_name="y.exe") is False)
    check("temp file removed on reject",
          not (Path(os.environ["TEMP"]) / "VoidPurge_Update.exe").exists())

    with mock.patch.object(updater, "_download_text", return_value=None):
        check("unreachable .minisig -> False",
              updater.download_and_apply_update("https://x/y.exe",
                                                minisig_url="https://x/y.exe.minisig",
                                                exe_name="y.exe") is False)

    with mock.patch.object(updater, "_download_text", return_value="garbage"):
        check("bad signature -> False",
              updater.download_and_apply_update("https://x/y.exe",
                                                minisig_url="https://x/y.exe.minisig",
                                                exe_name="y.exe") is False)

# ---------------------------------------------------------------- success path (destructive tail mocked)
good_payload = b"Z" * 2_000_000
sk3, keynum3, pubkey3 = make_keypair()
good_sig = our_minisig(sk3, keynum3, good_payload)


def fake_retrieve2(url, filename, reporthook=None):
    Path(filename).write_bytes(good_payload)


calls = {}


def fake_popen(*a, **k):
    calls["popen"] = True
    return mock.Mock()


def fake_exit(code=0):
    calls["exit"] = code
    raise SystemExit(code)


with mock.patch.object(updater.urllib.request, "urlretrieve", fake_retrieve2), \
     mock.patch.object(updater, "_download_text", return_value=good_sig), \
     mock.patch.object(updater, "MINISIGN_PUBLIC_KEY", pubkey3), \
     mock.patch.object(updater.subprocess, "Popen", fake_popen), \
     mock.patch.object(updater.sys, "exit", fake_exit):
    try:
        updater.download_and_apply_update("https://x/y.exe",
                                          minisig_url="https://x/y.exe.minisig",
                                          exe_name="y.exe")
        exited = False
    except SystemExit:
        exited = True
check("valid signature -> proceeds to self-replace",
      exited and calls.get("popen") and calls.get("exit") == 0)

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILED: {FAILURES}")
    sys.exit(1)
print("ALL UPDATER MINISIGN TESTS PASSED")
