@echo off
setlocal enabledelayedexpansion

echo =======================================================
echo          VOIDPURGE STANDALONE BUILD SCRIPT
echo =======================================================
echo.

cd /d "%~dp0"

set PYTHON=python
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
    set PYTHON="%LocalAppData%\Programs\Python\Python312\python.exe"
)

echo [*] Checking icon assets...
if not exist "icon.ico" (
    echo [*] Generating icons...
    %PYTHON% generate_icon.py
)

echo [*] Checking and installing Python dependencies...
%PYTHON% -m pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo [-] Failed to install dependencies. Check your internet connection or Python path.
    pause
    exit /b 1
)

echo.
echo [*] Compiling standalone portable VoidPurge.exe with PyInstaller...
echo [*] Embedding icon into .exe binary, Taskbar, and Windows AppUserModelID...
echo.

%PYTHON% -m PyInstaller ^
    --noconfirm ^
    --onefile ^
    --windowed ^
    --uac-admin ^
    --clean ^
    --icon "icon.ico" ^
    --add-data "icon.ico;." ^
    --add-data "icon.png;." ^
    --name "VoidPurge" ^
    --collect-all "customtkinter" ^
    --collect-all "nacl" ^
    main.py

if errorlevel 1 (
    echo.
    echo [-] PyInstaller build failed! Review errors above.
    pause
    exit /b 1
)

echo.
echo =======================================================
echo [x] BUILD SUCCESSFUL!
echo [x] Executable: dist\VoidPurge.exe
echo =======================================================
echo.
pause
