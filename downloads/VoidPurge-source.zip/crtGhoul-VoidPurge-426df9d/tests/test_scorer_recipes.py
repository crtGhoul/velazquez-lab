"""Linux-runnable tests for the VoidPurge confidence scorer + silent recipe engine.

Runs on Linux by stubbing the Windows-only `winreg` module (and `psutil`,
which the package __init__ imports) before importing voidpurge modules.
Only pure logic is exercised: detect_installer_type, build_quiet_command,
score_candidate, get_installed_app_index, and the delete_leftovers
confidence gate. No Windows APIs are touched.

Usage: python3 test_scorer_recipes.py
"""
import csv
import os
import sys
import types

# ---------------------------------------------------------------------------
# Stub Windows-only modules BEFORE importing voidpurge.
# ---------------------------------------------------------------------------
try:
    import winreg  # noqa: F401  (real one on Windows)
except ImportError:
    _fake_winreg = types.ModuleType("winreg")
    _fake_winreg.HKEY_CURRENT_USER = 0x80000001
    _fake_winreg.HKEY_LOCAL_MACHINE = 0x80000002
    _fake_winreg.KEY_READ = 0x20019

    def _raise(*_a, **_k):
        raise OSError("winreg stub: no Windows registry on this platform")

    _fake_winreg.OpenKey = _raise
    _fake_winreg.QueryInfoKey = _raise
    _fake_winreg.EnumKey = _raise
    _fake_winreg.EnumValue = _raise
    sys.modules["winreg"] = _fake_winreg

try:
    import psutil  # noqa: F401
except ImportError:
    sys.modules["psutil"] = types.ModuleType("psutil")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from voidpurge import uninstaller
from voidpurge import scrubber

PASS = 0
FAIL = 0
FAILURES = []


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS  {name}")
    else:
        FAIL += 1
        FAILURES.append(name)
        print(f"  FAIL  {name} {detail}")


# ---------------------------------------------------------------------------
# 1. detect_installer_type
# ---------------------------------------------------------------------------
def test_detect_installer_type():
    print("\n== detect_installer_type ==")
    cases = [
        (r"MsiExec.exe /I{11111111-2222-3333-4444-555555555555}", "msi"),
        (r'"C:\Program Files\Foo\unins000.exe"', "inno"),
        (r'"C:\Program Files\Foo\unins001.exe"', "inno"),
        (r'"C:\Program Files\Foo\uninstall.exe"', "nsis"),
        (r'"C:\Foo\IsUninst.exe" -f"C:\Foo\Uninst.isu"', "installshield"),
        (r'"C:\Foo\setup.exe" -s -f1"C:\Foo\setup.iss"', "installshield"),
        (r'"C:\Foo\setup.exe"', "unknown"),
        (r'"C:\Program Files\Adobe\AdobeARM.exe" /someflag', "adobe"),
        (r'"C:\Program Files (x86)\Steam\steam.exe" steam://uninstall/570', "steam"),
        (r'"C:\Tools\helper.exe" --remove', "unknown"),
        ("", "unknown"),
    ]
    for cmd, expected in cases:
        got = uninstaller.detect_installer_type(cmd)
        check(f"type({cmd[:45]!r}) == {expected!r}", got == expected, f"got {got!r}")


# ---------------------------------------------------------------------------
# 2. build_quiet_command
# ---------------------------------------------------------------------------
def test_build_quiet_command():
    print("\n== build_quiet_command ==")
    b = uninstaller.build_quiet_command

    # MSI: /I -> /X, ensure /qn /norestart
    msi = b(r"MsiExec.exe /I{11111111-2222-3333-4444-555555555555}")
    check("msi /I -> /X", "/x{11111111-2222-3333-4444-555555555555}" in msi.lower()
          and "/i{" not in msi.lower(), msi)
    check("msi gains /qn /norestart", "/qn" in msi and "/norestart" in msi, msi)

    # MSI already quiet: unchanged, no duplicated flags
    msi_q = r"MsiExec.exe /X{11111111-2222-3333-4444-555555555555} /qn"
    check("msi already quiet unchanged", b(msi_q) == msi_q and b(msi_q).count("/qn") == 1, b(msi_q))

    # Inno
    inno = b(r'"C:\Program Files\Foo\unins000.exe"')
    check("inno recipe", inno.endswith("/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-"), inno)
    inno_q = r'"C:\Program Files\Foo\unins000.exe" /VERYSILENT'
    check("inno already silent unchanged", b(inno_q) == inno_q, b(inno_q))

    # NSIS
    nsis = b(r'"C:\Program Files\Foo\uninstall.exe"')
    check("nsis recipe", nsis.endswith(" /S"), nsis)
    nsis_q = r'"C:\Program Files\Foo\uninstall.exe" /S'
    check("nsis already /S unchanged", b(nsis_q) == nsis_q, b(nsis_q))

    # InstallShield
    ish = b(r'"C:\Foo\IsUninst.exe" -f"C:\Foo\Uninst.isu"')
    check("installshield recipe", ish.endswith(" /s"), ish)

    # Unknown / generic: SAFETY — original returned unchanged, no guessed flags
    unk = r'"C:\Tools\helper.exe" --remove'
    check("unknown unchanged (no guessed flags)", b(unk) == unk, b(unk))
    setup = r'"C:\Foo\setup.exe"'
    check("generic setup.exe unchanged", b(setup) == setup, b(setup))

    # Adobe / Steam: no verified silent form -> unchanged
    adobe = r'"C:\Program Files\Adobe\AdobeARM.exe" /x'
    check("adobe unchanged", b(adobe) == adobe, b(adobe))
    steam = r'"C:\Program Files (x86)\Steam\steam.exe" steam://uninstall/570'
    check("steam unchanged", b(steam) == steam, b(steam))

    # QuietUninstallString preference is honored in get_installed_programs logic path:
    # (direct unit check of the recipe used when no QuietUninstallString exists)
    check("deprecated alias still works", uninstaller._inject_silent_flags(setup) == setup)


# ---------------------------------------------------------------------------
# 3. score_candidate (pure function, fake installed-app index)
# ---------------------------------------------------------------------------
FAKE_INDEX = {
    "target_name": "coolapp",
    "target_publisher": "coolsoft",
    "install_locations": {
        scrubber._canon_path(r"C:\Program Files\OtherApp"): "OtherApp",
    },
    "publisher_apps": {
        "coolsoft": ["CoolApp", "CoolApp Helper"],
        "othercorp": ["OtherApp"],
    },
}


def test_score_candidate():
    print("\n== score_candidate ==")
    s = scrubber.score_candidate

    # Exact app-name match -> +40
    c, reasons = s("CoolApp", "CoolSoft", FAKE_INDEX)
    check("exact name -> 40", c == 40, f"got {c}, {reasons}")
    check("reasons non-empty", len(reasons) >= 1)

    # Near-exact (separators/version suffix) -> +40
    c, _ = s("cool-app", "CoolSoft", FAKE_INDEX)
    check("near-exact name -> 40", c == 40, f"got {c}")
    c, _ = s("CoolApp (x64)", "CoolSoft", FAKE_INDEX)
    check("name with suffix -> 40", c == 40, f"got {c}")

    # Weak token-only match -> +15
    c, reasons = s("mycoolappstuffishere", "NoPub", FAKE_INDEX)
    check("weak token -> 15", c == 15, f"got {c}, {reasons}")

    # Publisher match: +15 weak +25 publisher = 40, then -30 (publisher has
    # other installed apps) -> 10
    c, reasons = s("CoolSoft", "CoolSoft", FAKE_INDEX)
    check("publisher folder with sibling apps -> 10", c == 10, f"got {c}, {reasons}")

    # -50: candidate is another installed app's InstallLocation -> clamped 0
    c, reasons = s("OtherApp", "", FAKE_INDEX,
                   path=r"C:\Program Files\OtherApp", item_type="folder")
    check("other app's install dir -> 0", c == 0, f"got {c}, {reasons}")

    # -50 via containment: subdir of another app's install dir
    c, _ = s("data", "", FAKE_INDEX,
             path=r"C:\Program Files\OtherApp\data", item_type="folder")
    check("subdir of live install dir penalized", c == 0, f"got {c}")

    # -20: under Common Files shared root
    c, _ = s("CoolApp", "CoolSoft", FAKE_INDEX,
             path=r"C:\Program Files\Common Files\CoolApp", item_type="folder")
    check("common files -> 40-20=20", c == 20, f"got {c}")

    # Clamp sanity across a batch
    for nm, pub, pth, typ in [
        ("CoolApp", "CoolSoft", "", ""),
        ("x", "y", r"C:\Program Files\OtherApp", "folder"),
        ("CoolSoft Shared", "CoolSoft", r"C:\Program Files\Common Files\CoolSoft", "folder"),
    ]:
        c, _ = s(nm, pub, FAKE_INDEX, path=pth, item_type=typ)
        check(f"clamp 0-100 for {nm!r}", 0 <= c <= 100, f"got {c}")

    # Registry items: no filesystem penalties, publisher -30 still applies
    c, _ = s("CoolSoft", "CoolSoft", FAKE_INDEX, path=r"HKCU\Software\CoolSoft", item_type="registry")
    check("registry publisher item -> 10", c == 10, f"got {c}")


# ---------------------------------------------------------------------------
# 4. get_installed_app_index (monkeypatched programs, cache behavior)
# ---------------------------------------------------------------------------
def test_installed_app_index():
    print("\n== get_installed_app_index ==")
    fake_programs = [
        {"name": "CoolApp", "publisher": "CoolSoft", "install_location": r"C:\Program Files\CoolApp"},
        {"name": "OtherApp", "publisher": "OtherCorp", "install_location": r"C:\Program Files\OtherApp"},
        {"name": "CoolApp Helper", "publisher": "CoolSoft", "install_location": ""},
    ]
    orig = uninstaller.get_installed_programs
    scrubber._installed_programs_cache = None
    calls = {"n": 0}

    def fake_get(include_uwp=True):
        calls["n"] += 1
        return fake_programs

    uninstaller.get_installed_programs = fake_get
    try:
        idx = scrubber.get_installed_app_index("CoolApp", "CoolSoft")
        key = scrubber._canon_path(r"C:\Program Files\OtherApp")
        check("install location indexed", idx["install_locations"].get(key) == "OtherApp",
              str(idx["install_locations"]))
        check("publisher apps grouped",
              idx["publisher_apps"].get("coolsoft") == ["CoolApp", "CoolApp Helper"],
              str(idx["publisher_apps"]))
        check("target normalized", idx["target_name"] == "coolapp" and idx["target_publisher"] == "coolsoft")

        # Cache: second call must not re-query
        scrubber.get_installed_app_index("Other", "OtherCorp")
        check("programs cached (1 query for 2 index builds)", calls["n"] == 1, f"queries={calls['n']}")

        # Index drives the -50 signal end to end
        c, _ = scrubber.score_candidate("OtherApp", "", idx,
                                        path=r"C:\Program Files\OtherApp", item_type="folder")
        check("index -50 signal end-to-end", c == 0, f"got {c}")
    finally:
        uninstaller.get_installed_programs = orig
        scrubber._installed_programs_cache = None


# ---------------------------------------------------------------------------
# 5. delete_leftovers confidence gate (low-confidence items skipped, 3-tuple kept)
# ---------------------------------------------------------------------------
def test_delete_leftovers_gate():
    print("\n== delete_leftovers confidence gate ==")
    low_items = [
        {"type": "folder", "path": "/tmp/voidpurge-test-nope-1", "name": "nope1", "confidence": 10},
        {"type": "registry", "path": r"HKCU\Software\Nope", "name": "Nope", "confidence": 5},
    ]
    result = scrubber.delete_leftovers(low_items, app_hint="")
    check("3-tuple return preserved", isinstance(result, tuple) and len(result) == 3, str(type(result)))
    del_f, del_r, errs = result
    check("nothing deleted for low-confidence", del_f == 0 and del_r == 0, str(result))
    info_lines = [e for e in errs if e.startswith("INFO:")]
    check("skip info lines logged", len(info_lines) >= 3, str(errs))  # 2 per-item + 1 summary
    check("summary mentions skipped count",
          any("Skipped 2 low-confidence" in e for e in errs), str(errs))

    # force=True bypasses the gate; nonexistent folder path is a safe no-op
    ghost = [{"type": "folder", "path": "/tmp/voidpurge-test-ghost-xyz", "name": "ghost", "confidence": 5}]
    del_f2, del_r2, errs2 = scrubber.delete_leftovers(ghost, app_hint="", force=True)
    check("force=True bypasses gate (no INFO skips)",
          not any(e.startswith("INFO: Skipped low-confidence item") for e in errs2), str(errs2))

    # Unscored legacy items default to confidence 100 (backward compatible)
    legacy = [{"type": "folder", "path": "/tmp/voidpurge-test-ghost-xyz", "name": "ghost"}]
    del_f3, _, errs3 = scrubber.delete_leftovers(legacy, app_hint="")
    check("unscored items treated as high-confidence (no skip)",
          not any("Skipped low-confidence item" in e for e in errs3), str(errs3))


def main():
    test_detect_installer_type()
    test_build_quiet_command()
    test_score_candidate()
    test_installed_app_index()
    test_delete_leftovers_gate()
    print(f"\n{'='*50}\nRESULT: {PASS} passed, {FAIL} failed")
    if FAILURES:
        print("Failed:", ", ".join(FAILURES))
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
