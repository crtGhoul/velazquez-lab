"""Linux-runnable tests for voidpurge/wipe.py (pure-Python parts)."""
import os
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import voidpurge.wipe as wipe

FAILURES = []


def check(name, cond, detail=""):
    status = "PASS" if cond else "FAIL"
    print(f"[{status}] {name}" + (f" - {detail}" if detail and not cond else ""))
    if not cond:
        FAILURES.append(name)


def main():
    tmp = Path(tempfile.mkdtemp(prefix="wipe-test-"))

    # --- single-pass wipe: file is gone ---
    f1 = tmp / "secret.txt"
    f1.write_bytes(b"top secret data" * 1000)
    ok, msg = wipe.secure_wipe(f1, method="single")
    check("single-pass wipe returns True", ok, msg)
    check("wiped file is gone", not f1.exists() and not any(tmp.iterdir()))
    check("status message mentions pass", "pass" in msg.lower(), msg)

    # --- verify=True ---
    f2 = tmp / "v.txt"
    f2.write_bytes(os.urandom(5000))
    ok, msg = wipe.secure_wipe(f2, method="single", verify=True)
    check("verify wipe ok", ok, msg)
    check("verify wipe file gone", not f2.exists())
    check("verify message", "verified" in msg.lower() or "verify" in msg.lower(), msg)

    # --- method validation ---
    f3 = tmp / "m.txt"
    f3.write_text("x")
    ok, msg = wipe.secure_wipe(f3, method="nonsense")
    check("bad method refused", not ok, msg)
    check("file untouched after bad method", f3.exists())

    # --- pass-count logic ---
    check("single = 1 pass", len(wipe._PASS_PATTERNS["single"]) == 1)
    check("dod = 3 passes", len(wipe._PASS_PATTERNS["dod"]) == 3)
    check("gutmann = 35 passes", len(wipe._PASS_PATTERNS["gutmann"]) == 35)
    check(
        "dod pattern order (00, ff, random)",
        wipe._PASS_PATTERNS["dod"] == [b"\x00", b"\xff", b"R"],
    )

    # --- chunked I/O happens once per pass (monkeypatched urandom counter) ---
    calls = {"n": 0}
    real_urandom = os.urandom

    def counting_urandom(n):
        calls["n"] += 1
        return real_urandom(n)

    wipe.os.urandom = counting_urandom
    try:
        f4 = tmp / "c1.bin"
        f4.write_bytes(b"A" * 100)  # 1 chunk per pass
        wipe.secure_wipe(f4, method="single")
        single_calls = calls["n"]
        calls["n"] = 0
        f5 = tmp / "c2.bin"
        f5.write_bytes(b"B" * 100)
        wipe.secure_wipe(f5, method="gutmann")
        gutmann_calls = calls["n"]
    finally:
        wipe.os.urandom = real_urandom
    # per method: passes * 1 chunk + 1 slack-pad call
    check("single uses 2 urandom calls (1 pass + slack)", single_calls == 2,
          f"got {single_calls}")
    check("gutmann uses 36 urandom calls (35 + slack)", gutmann_calls == 36,
          f"got {gutmann_calls}")

    # --- dod wipe on a dir (recursive) ---
    d1 = tmp / "wipe-me"
    (d1 / "sub").mkdir(parents=True)
    (d1 / "sub" / "a.dat").write_bytes(b"data1" * 500)
    (d1 / "b.dat").write_bytes(b"data2" * 500)
    ok, msg = wipe.secure_wipe(d1, method="dod")
    check("dir wipe returns True", ok, msg)
    check("dir fully removed", not d1.exists())

    # --- protected path refusal (home dir is protected in utils) ---
    ok, msg = wipe.secure_wipe(Path.home(), method="single")
    check("wipe refuses protected path", not ok, msg)

    # --- symlink refusal ---
    target = tmp / "real.txt"
    target.write_text("keep me")
    link = tmp / "link.txt"
    link.symlink_to(target)
    ok, msg = wipe.secure_wipe(link, method="single")
    check("wipe refuses symlinks", not ok, msg)
    check("symlink target untouched", target.exists())

    # --- missing path ---
    ok, msg = wipe.secure_wipe(tmp / "ghost.txt")
    check("wipe refuses missing path", not ok)

    # --- read-only file still wiped ---
    f6 = tmp / "ro.txt"
    f6.write_text("readonly")
    os.chmod(f6, 0o444)
    ok, msg = wipe.secure_wipe(f6, method="single")
    check("read-only file wiped", ok and not f6.exists(), msg)

    # --- SSD warning constant sanity ---
    w = wipe.SSD_WARNING
    check("SSD_WARNING mentions wear-leveling", "wear-leveling" in w.lower())
    check("SSD_WARNING mentions Secure Erase", "Secure Erase" in w)
    check("SSD_WARNING mentions HDD honesty", "HDD" in w or "spinning" in w)

    shutil.rmtree(tmp, ignore_errors=True)

    print()
    if FAILURES:
        print(f"{len(FAILURES)} FAILURES: {FAILURES}")
        sys.exit(1)
    print("ALL WIPE TESTS PASSED")


if __name__ == "__main__":
    main()
