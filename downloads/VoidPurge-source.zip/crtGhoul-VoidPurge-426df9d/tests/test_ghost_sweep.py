"""Linux-runnable tests for the VoidPurge ghost sweep (pure-Python parts).

The Windows-only scanners are guarded by `os.name != "nt"` and must return []
without touching the OS here. Only pure logic is exercised:
_uninstall_target_missing and the near-exact shortcut-name scoring.
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Stub winreg like the other test modules do (scrubber imports it at top level).
import types
_fake_winreg = types.ModuleType("winreg")
_fake_winreg.HKEY_CURRENT_USER = 0
_fake_winreg.HKEY_LOCAL_MACHINE = 1
_fake_winreg.KEY_READ = 0x20019
sys.modules["winreg"] = _fake_winreg

# Stub the package __init__ imports that need Windows (psutil is fine on Linux).
import voidpurge.scrubber as scrubber

FAILURES = []


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        FAILURES.append(name)


# --- _uninstall_target_missing ---
check("empty string -> missing", scrubber._uninstall_target_missing("") is True)
check("blank -> missing", scrubber._uninstall_target_missing("   ") is True)
check("msiexec never flagged by file check",
      scrubber._uninstall_target_missing("MsiExec.exe /X{12345}") is False)
check("quoted missing exe -> missing",
      scrubber._uninstall_target_missing('"C:\\Nope\\uninstall.exe" /S') is True)
# This file exists (we are running from it), so it must NOT be flagged.
here = os.path.abspath(__file__)
check("existing file -> not missing",
      scrubber._uninstall_target_missing(f'"{here}"') is False)

# --- nt-guarded scanners are inert on Linux ---
toks = ["windhawk"]
check("shortcuts -> [] on linux", scrubber._scan_shortcuts(toks) == [])
check("app paths -> [] on linux", scrubber._scan_app_paths(toks) == [])
check("muicache -> [] on linux", scrubber._scan_muicache(toks) == [])
check("orphan uninstall -> [] on linux", scrubber._scan_orphan_uninstall_entries(toks) == [])
check("resolve lnk targets -> {} on linux", scrubber._resolve_lnk_targets([]) == {})

# --- shortcut-name scoring: 'Windhawk.lnk' must near-exact match 'windhawk' ---
idx = {"target_name": "windhawk", "target_publisher": ""}
conf, reasons = scrubber.score_candidate("Windhawk.lnk", "", idx, path="", item_type="shortcut")
check("Windhawk.lnk scores exact-name bonus", conf >= 40)
check("reasons mention exact match", any("exact" in r for r in reasons))

print()
if FAILURES:
    print(f"RESULT: {len(FAILURES)} FAILED: {FAILURES}")
    sys.exit(1)
print("ALL GHOST SWEEP TESTS PASSED")
