"""Linux-runnable tests for voidpurge/purgebin.py (pure-Python parts)."""
import json
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import voidpurge.purgebin as purgebin
from voidpurge.utils import is_protected_path

FAILURES = []


def check(name, cond, detail=""):
    status = "PASS" if cond else "FAIL"
    print(f"[{status}] {name}" + (f" - {detail}" if detail and not cond else ""))
    if not cond:
        FAILURES.append(name)


def main():
    tmp = Path(tempfile.mkdtemp(prefix="purgebin-test-"))
    bin_dir = tmp / "bin"
    # Isolate: point the module at a temp purge-bin, and a fake Desktop.
    purgebin.PURGE_BIN_DIR = bin_dir
    fake_desktop = tmp / "Desktop"
    purgebin._desktop_path = lambda: fake_desktop

    # --- stage a file ---
    f1 = tmp / "notes.txt"
    f1.write_text("hello world")
    ok, msg, item_id = purgebin.stage(f1)
    check("stage file ok", ok and item_id, msg)
    check("stage removes original", not f1.exists())
    check("stage creates item dir", (bin_dir / item_id).is_dir())
    check("manifest written", (bin_dir / item_id / "manifest.json").is_file())

    # --- list_items ---
    items = purgebin.list_items()
    check("list_items count", len(items) == 1, f"got {len(items)}")
    check(
        "list_items keys",
        all(k in items[0] for k in ("id", "original_path", "name", "size", "staged_at")),
        str(items[0]),
    )
    check("list_items name/size", items[0]["name"] == "notes.txt" and items[0]["size"] == 11)

    # --- restore ---
    ok, msg = purgebin.restore(item_id)
    check("restore ok", ok, msg)
    check("restore brings file back", f1.exists() and f1.read_text() == "hello world")
    check("restore cleans item dir", not (bin_dir / item_id).exists())
    check("list empty after restore", purgebin.list_items() == [])

    # --- stage a directory ---
    d1 = tmp / "mydir"
    (d1 / "sub").mkdir(parents=True)
    (d1 / "sub" / "a.bin").write_bytes(b"x" * 100)
    ok, msg, did = purgebin.stage(d1)
    check("stage dir ok", ok and did, msg)
    check("stage dir removes original", not d1.exists())

    # --- restore with missing original parent -> Desktop fallback ---
    # Remove original parent path is tmp itself... instead simulate by staging
    # a file whose original parent we delete: stage, then recreate scenario.
    f2 = tmp / "orphan" / "doc.txt"
    f2.parent.mkdir(parents=True)
    f2.write_text("orphan data")
    ok, msg, oid = purgebin.stage(f2)
    check("stage orphan ok", ok, msg)
    import shutil
    shutil.rmtree(f2.parent)  # original parent gone
    ok, msg = purgebin.restore(oid)
    check("restore fallback ok", ok, msg)
    check("fallback lands on Desktop", (fake_desktop / "doc.txt").exists())
    check("fallback message says Desktop", "Desktop" in msg, msg)

    # restore the staged dir too (cleanup)
    ok, msg = purgebin.restore(did)
    check("restore dir ok", ok, msg)
    check("dir restored with contents", (d1 / "sub" / "a.bin").exists())

    # --- restore when target already exists ---
    f3 = tmp / "clash.txt"
    f3.write_text("v1")
    ok, msg, cid = purgebin.stage(f3)
    f3.write_text("v2")  # something new at the original path
    ok2, msg2 = purgebin.restore(cid)
    check("restore refuses when target exists", not ok2, msg2)

    # --- empty ---
    ok, msg, eid = purgebin.stage(tmp / "clash.txt")  # stage v2 file
    n = purgebin.empty()
    check("empty removes items", n >= 1, f"removed={n}")
    check("empty leaves bin dir", bin_dir.is_dir())
    check("bin empty after empty()", purgebin.list_items() == [])

    # --- auto_empty ---
    old_file = tmp / "old.txt"
    old_file.write_text("old")
    ok, msg, old_id = purgebin.stage(old_file)
    new_file = tmp / "new.txt"
    new_file.write_text("new")
    ok, msg, new_id = purgebin.stage(new_file)
    # backdate the old item's manifest
    mpath = bin_dir / old_id / "manifest.json"
    m = json.loads(mpath.read_text())
    m["staged_at"] = (datetime.now() - timedelta(days=45)).isoformat(timespec="seconds")
    mpath.write_text(json.dumps(m))
    removed = purgebin.auto_empty(max_age_days=30)
    check("auto_empty removes old only", removed == 1, f"removed={removed}")
    remaining = purgebin.list_items()
    check("auto_empty keeps new", len(remaining) == 1 and remaining[0]["id"] == new_id)

    # --- protected path refusal ---
    ok, msg, iid = purgebin.stage(Path.home())
    check("stage refuses protected path", not ok and iid == "", msg)
    check("home dir untouched", Path.home().exists())

    # --- stage nonexistent ---
    ok, msg, iid = purgebin.stage(tmp / "nope.txt")
    check("stage refuses missing path", not ok and iid == "")

    # --- restore unknown id ---
    ok, msg = purgebin.restore("does-not-exist")
    check("restore refuses unknown id", not ok)

    shutil.rmtree(tmp, ignore_errors=True)

    print()
    if FAILURES:
        print(f"{len(FAILURES)} FAILURES: {FAILURES}")
        sys.exit(1)
    print("ALL PURGEBIN TESTS PASSED")


if __name__ == "__main__":
    main()
