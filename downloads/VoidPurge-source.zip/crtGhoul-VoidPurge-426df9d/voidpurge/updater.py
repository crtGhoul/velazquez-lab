import os
import sys
import json
import hashlib
import urllib.request
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any, Tuple

# IMPORTANT: bump this on every release. If it lags behind the release tag,
# the updater will keep offering the same update in a loop.
CURRENT_VERSION = "1.2.0"
GITHUB_REPO = "crtGhoul/VoidPurge"
API_URL = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"

def parse_semver(v_str: str) -> Tuple[int, ...]:
    """Parse version string into tuple of integers."""
    clean = v_str.strip().lstrip("vV")
    parts = []
    for part in clean.split("."):
        try:
            parts.append(int(part))
        except ValueError:
            break
    return tuple(parts)

def check_for_updates() -> Optional[Dict[str, Any]]:
    """
    Check GitHub Releases for a newer version of VoidPurge.
    Returns release info dict if an update is available, else None.
    """
    try:
        req = urllib.request.Request(
            API_URL,
            headers={
                "User-Agent": "VoidPurge-AutoUpdater",
                "Accept": "application/vnd.github.v3+json",
            },
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            if resp.status != 200:
                return None
            data = json.loads(resp.read().decode("utf-8"))

        latest_tag = data.get("tag_name", "")
        if not latest_tag:
            return None

        current = parse_semver(CURRENT_VERSION)
        latest = parse_semver(latest_tag)

        if latest > current:
            # Find .exe asset if available
            exe_url = None
            exe_name = None
            checksums_url = None
            for asset in data.get("assets", []):
                a_name = asset.get("name", "")
                if a_name.lower().endswith(".exe"):
                    exe_url = asset.get("browser_download_url")
                    exe_name = a_name
                elif a_name.lower() in ("checksums.txt", "sha256sums.txt"):
                    checksums_url = asset.get("browser_download_url")

            return {
                "current_version": CURRENT_VERSION,
                "latest_version": latest_tag,
                "release_name": data.get("name", latest_tag),
                "html_url": data.get("html_url", f"https://github.com/{GITHUB_REPO}/releases"),
                "body": data.get("body", "Bug fixes and improvements."),
                "download_url": exe_url,
                "exe_name": exe_name,
                "checksums_url": checksums_url,
            }
    except Exception as e:
        print(f"Update check error: {e}")
    return None

def _fetch_expected_sha256(checksums_url: str, exe_name: str) -> Optional[str]:
    """
    Download the release's checksums.txt and return the expected SHA256 for exe_name.
    Expected format per line: "<sha256>  <filename>". Returns None if unavailable.
    """
    try:
        req = urllib.request.Request(
            checksums_url,
            headers={"User-Agent": "VoidPurge-AutoUpdater"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status != 200:
                return None
            text = resp.read().decode("utf-8", errors="replace")
        for line in text.splitlines():
            parts = line.strip().split()
            if len(parts) >= 2 and parts[1].lstrip("*") == exe_name:
                digest = parts[0].lower()
                if len(digest) == 64 and all(c in "0123456789abcdef" for c in digest):
                    return digest
        return None
    except Exception as e:
        print(f"Checksum fetch error: {e}")
        return None


def _sha256_of_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download_and_apply_update(download_url: str, progress_callback=None,
                              checksums_url: Optional[str] = None,
                              exe_name: Optional[str] = None,
                              require_checksum: bool = True) -> bool:
    """
    Download updated executable, verify its SHA256 against the release's
    checksums.txt, and spawn a batch script to replace the running executable.

    require_checksum=True (default): refuse to self-replace if no verifiable
    checksum is available. Set False only for manual/dev flows.
    """
    try:
        current_exe = Path(sys.executable).resolve()
        temp_dir = Path(os.environ.get("TEMP", "."))
        new_exe = temp_dir / "VoidPurge_Update.exe"

        # Download updated binary with progress
        def _reporthook(blocknum, blocksize, totalsize):
            if progress_callback and totalsize > 0:
                percent = min(100, int((blocknum * blocksize / totalsize) * 100))
                progress_callback(percent)

        urllib.request.urlretrieve(download_url, str(new_exe), reporthook=_reporthook)

        if not new_exe.exists() or new_exe.stat().st_size < 1000000:
            return False

        # --- SHA256 verification (hardening) ---
        expected = None
        if checksums_url and exe_name:
            expected = _fetch_expected_sha256(checksums_url, exe_name)

        if expected:
            actual = _sha256_of_file(new_exe)
            if actual != expected:
                print(f"UPDATE REJECTED: checksum mismatch for {exe_name}\n"
                      f"  expected: {expected}\n  actual:   {actual}")
                try:
                    new_exe.unlink()
                except Exception:
                    pass
                return False
            print(f"Update checksum verified: {exe_name}")
        elif require_checksum:
            print("UPDATE REJECTED: no verifiable checksum published for this release. "
                  "Aborting self-replace to protect against a compromised release pipeline.")
            try:
                new_exe.unlink()
            except Exception:
                pass
            return False
        # --- end verification ---

        # Create self-replacing updater batch script
        updater_bat = temp_dir / "voidpurge_updater.bat"
        pid = os.getpid()
        bat_content = f"""@echo off
timeout /t 2 /nobreak > nul
:retry
taskkill /F /PID {pid} > nul 2>&1
timeout /t 1 /nobreak > nul
move /Y "{new_exe}" "{current_exe}" > nul 2>&1
if errorlevel 1 (
    timeout /t 1 /nobreak > nul
    goto retry
)
start "" "{current_exe}"
del "%~f0"
"""
        with open(updater_bat, "w") as f:
            f.write(bat_content)

        # Launch the updater script and terminate current process
        subprocess.Popen(
            ["cmd.exe", "/c", str(updater_bat)],
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        sys.exit(0)
    except Exception as e:
        print(f"Failed to apply update: {e}")
        return False
