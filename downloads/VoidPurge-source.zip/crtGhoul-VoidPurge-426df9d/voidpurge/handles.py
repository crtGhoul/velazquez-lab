"""Surgical handle engine for VoidPurge (Windows user-mode only).

Finds which processes hold a file or directory open by enumerating ALL
system handles via ntdll!NtQuerySystemInformation(SystemExtendedHandleInformation),
and closes just the offending handle via NtDuplicateObject(DUPLICATE_CLOSE_SOURCE)
instead of killing the whole process.

Unlike psutil's open_files(), this catches memory-mapped files, loaded DLLs,
and directory locks.

Everything here is user-mode (no kernel driver, ever). Protected processes
(see utils.is_protected_process) are never touched: their handles are neither
enumerated into results meant for closing nor closed.

All functions fail safe: they return [] / False on non-Windows platforms or
on any unexpected error, so importing this module can never crash the app.
"""

import ctypes
import os
import struct
from ctypes import wintypes
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .utils import is_protected_process

__all__ = [
    "enable_debug_privilege",
    "find_locking_processes_detailed",
    "close_handles_on_path",
]

# ---------------------------------------------------------------------------
# Platform guard: every windll binding below is Windows-only. On any other
# platform the module still imports cleanly and every public function
# degrades to returning [] / False.
# ---------------------------------------------------------------------------
_ON_WINDOWS = os.name == "nt"

_ntdll = _kernel32 = _advapi32 = None
if _ON_WINDOWS:
    try:
        _ntdll = ctypes.WinDLL("ntdll")
        _kernel32 = ctypes.WinDLL("kernel32")
        _advapi32 = ctypes.WinDLL("advapi32")
    except Exception:
        _ntdll = _kernel32 = _advapi32 = None

_HAVE_NT = _ntdll is not None and _kernel32 is not None and _advapi32 is not None


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
_SYSTEM_EXTENDED_HANDLE_INFORMATION = 64  # SystemExtendedHandleInformation
_STATUS_INFO_LENGTH_MISMATCH = 0xC0000004
_STATUS_BUFFER_OVERFLOW = 0x80000005

_DUPLICATE_SAME_ACCESS = 0x0002
_DUPLICATE_CLOSE_SOURCE = 0x0001
_OBJECT_NAME_INFORMATION = 1

_PROCESS_DUP_HANDLE = 0x0040
_PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

_SE_DEBUG_NAME = "SeDebugPrivilege"
_SE_PRIVILEGE_ENABLED = 0x00000002
_TOKEN_ADJUST_PRIVILEGES = 0x0020
_TOKEN_QUERY = 0x0008

_PTR = ctypes.sizeof(ctypes.c_void_p)
# sizeof(SYSTEM_HANDLE_TABLE_ENTRY_INFO_EX): 3 pointers + ULONG + 2*USHORT + 2*ULONG
_ENTRY_SIZE = 3 * _PTR + 4 + 2 + 2 + 4 + 4
# sizeof(SYSTEM_HANDLE_INFORMATION_EX) header: NumberOfHandles + Reserved
_HEADER_SIZE = 2 * _PTR

# PIDs we never touch: 0 (System Idle) and 4 (System / kernel).
_SKIP_PIDS = {0, 4}


# ---------------------------------------------------------------------------
# Token privilege structures (plain ctypes; no windll needed to define)
# ---------------------------------------------------------------------------
class _LUID(ctypes.Structure):
    _fields_ = [
        ("LowPart", wintypes.DWORD),
        ("HighPart", wintypes.LONG),
    ]


class _LUID_AND_ATTRIBUTES(ctypes.Structure):
    _fields_ = [
        ("Luid", _LUID),
        ("Attributes", wintypes.DWORD),
    ]


class _TOKEN_PRIVILEGES(ctypes.Structure):
    _fields_ = [
        ("PrivilegeCount", wintypes.DWORD),
        ("Privileges", _LUID_AND_ATTRIBUTES * 1),
    ]


# ---------------------------------------------------------------------------
# Bind native entry points (Windows only)
# ---------------------------------------------------------------------------
if _HAVE_NT:
    _ntdll.NtQuerySystemInformation.argtypes = [
        wintypes.ULONG, wintypes.LPVOID, wintypes.ULONG,
        ctypes.POINTER(wintypes.ULONG),
    ]
    _ntdll.NtQuerySystemInformation.restype = wintypes.LONG

    _ntdll.NtDuplicateObject.argtypes = [
        wintypes.HANDLE, wintypes.HANDLE, wintypes.HANDLE,
        ctypes.POINTER(wintypes.HANDLE),
        wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
    ]
    _ntdll.NtDuplicateObject.restype = wintypes.LONG

    _ntdll.NtQueryObject.argtypes = [
        wintypes.HANDLE, wintypes.ULONG, wintypes.LPVOID,
        wintypes.ULONG, ctypes.POINTER(wintypes.ULONG),
    ]
    _ntdll.NtQueryObject.restype = wintypes.LONG

    _kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    _kernel32.OpenProcess.restype = wintypes.HANDLE
    _kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    _kernel32.CloseHandle.restype = wintypes.BOOL
    _kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    _kernel32.GetLastError.restype = wintypes.DWORD
    _kernel32.QueryDosDeviceW.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, wintypes.DWORD]
    _kernel32.QueryDosDeviceW.restype = wintypes.DWORD
    _kernel32.QueryFullProcessImageNameW.argtypes = [
        wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
        ctypes.POINTER(wintypes.DWORD),
    ]
    _kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL

    _advapi32.OpenProcessToken.argtypes = [
        wintypes.HANDLE, wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE),
    ]
    _advapi32.OpenProcessToken.restype = wintypes.BOOL
    _advapi32.LookupPrivilegeValueW.argtypes = [
        wintypes.LPCWSTR, wintypes.LPCWSTR, ctypes.POINTER(_LUID),
    ]
    _advapi32.LookupPrivilegeValueW.restype = wintypes.BOOL
    _advapi32.AdjustTokenPrivileges.argtypes = [
        wintypes.HANDLE, wintypes.BOOL, ctypes.POINTER(_TOKEN_PRIVILEGES),
        wintypes.DWORD, wintypes.LPVOID, wintypes.LPVOID,
    ]
    _advapi32.AdjustTokenPrivileges.restype = wintypes.BOOL


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def enable_debug_privilege() -> bool:
    """Enable SeDebugPrivilege on the current process token.

    Needed to open handles of processes owned by other users / the system.
    Returns False on non-Windows or if the privilege cannot be enabled.
    Never raises.
    """
    if not _HAVE_NT:
        return False
    try:
        h_token = wintypes.HANDLE()
        if not _advapi32.OpenProcessToken(
            _kernel32.GetCurrentProcess(),
            _TOKEN_ADJUST_PRIVILEGES | _TOKEN_QUERY,
            ctypes.byref(h_token),
        ):
            return False
        try:
            luid = _LUID()
            if not _advapi32.LookupPrivilegeValueW(None, _SE_DEBUG_NAME, ctypes.byref(luid)):
                return False
            tp = _TOKEN_PRIVILEGES()
            tp.PrivilegeCount = 1
            tp.Privileges[0].Luid = luid
            tp.Privileges[0].Attributes = _SE_PRIVILEGE_ENABLED
            if not _advapi32.AdjustTokenPrivileges(
                h_token, False, ctypes.byref(tp), 0, None, None
            ):
                return False
            # AdjustTokenPrivileges can "succeed" while granting nothing.
            return _kernel32.GetLastError() == 0
        finally:
            try:
                _kernel32.CloseHandle(h_token)
            except Exception:
                pass
    except Exception:
        return False


def find_locking_processes_detailed(target) -> List[Dict]:
    """Find every non-kernel process holding a handle on *target*.

    Returns a list of dicts:
        {pid, name, exe, handle_count, is_protected}
    Returns [] on non-Windows or on any failure. Never raises.
    """
    if not _HAVE_NT or not target:
        return []
    try:
        enable_debug_privilege()
        target_lower = str(Path(target).expanduser().resolve()).lower()
    except Exception:
        return []
    try:
        device_map = _get_drive_device_map()
        matches = _matching_handles(target_lower, device_map)
    except Exception:
        return []

    name_cache: Dict[int, Tuple[str, str]] = {}
    per_pid: Dict[int, Dict] = {}
    for pid, _hval in matches:
        entry = per_pid.get(pid)
        if entry is None:
            if pid not in name_cache:
                name_cache[pid] = _process_image_name(pid)
            pname, pexe = name_cache[pid]
            entry = {
                "pid": pid,
                "name": pname or f"PID {pid}",
                "exe": pexe or "",
                "handle_count": 0,
                "is_protected": is_protected_process(pname),
            }
            per_pid[pid] = entry
        entry["handle_count"] += 1
    return list(per_pid.values())


def close_handles_on_path(target) -> List[Dict]:
    """Close handles held by non-protected processes on *target*.

    For each process (other than our own, the kernel, and protected system
    processes) holding a handle whose object name resolves to *target* (or a
    path inside it), the individual handle is closed via
    NtDuplicateObject(DUPLICATE_CLOSE_SOURCE) -- the process itself is left
    running.

    Returns a list of dicts {pid, name} for the processes whose handles were
    closed. Returns [] on non-Windows or on any failure. Never raises.
    """
    if not _HAVE_NT or not target:
        return []
    try:
        enable_debug_privilege()
        target_lower = str(Path(target).expanduser().resolve()).lower()
    except Exception:
        return []
    try:
        device_map = _get_drive_device_map()
        matches = _matching_handles(target_lower, device_map)
    except Exception:
        return []

    closed: List[Dict] = []
    seen_pids = set()
    by_pid: Dict[int, List[int]] = {}
    for pid, hval in matches:
        by_pid.setdefault(pid, []).append(hval)

    for pid, hvals in by_pid.items():
        try:
            pname, _pexe = _process_image_name(pid)
            # Never touch protected processes -- or processes we cannot
            # identify (fail safe).
            if not pname or is_protected_process(pname):
                continue
            proc_h = _open_process(pid, _PROCESS_DUP_HANDLE)
            if not proc_h:
                continue
            try:
                closed_any = False
                for hval in hvals:
                    try:
                        status = _ntdll.NtDuplicateObject(
                            proc_h,
                            wintypes.HANDLE(hval),
                            None,  # TargetProcessHandle: NULL + CLOSE_SOURCE closes it
                            None,  # TargetHandle: ignored for CLOSE_SOURCE
                            0,
                            0,
                            _DUPLICATE_CLOSE_SOURCE,
                        )
                        if status == 0:
                            closed_any = True
                    except Exception:
                        continue
                if closed_any and pid not in seen_pids:
                    seen_pids.add(pid)
                    closed.append({"pid": pid, "name": pname})
            finally:
                _close_handle(proc_h)
        except Exception:
            continue
    return closed


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------
_drive_device_map_cache: Optional[List[Tuple[str, str]]] = None


def _get_drive_device_map() -> List[Tuple[str, str]]:
    """Map NT device prefixes (e.g. \\Device\\HarddiskVolume3) to drive letters.

    Returns a list of (device_prefix_lower, "X:") sorted by descending prefix
    length so the longest match wins. Cached after the first call.
    """
    global _drive_device_map_cache
    if _drive_device_map_cache is not None:
        return _drive_device_map_cache
    entries: List[Tuple[str, str]] = []
    if _HAVE_NT:
        try:
            buf = ctypes.create_unicode_buffer(512)
            for code in range(ord("A"), ord("Z") + 1):
                letter = chr(code)
                try:
                    if _kernel32.QueryDosDeviceW(f"{letter}:", buf, 512):
                        entries.append((buf.value.lower(), f"{letter}:"))
                except Exception:
                    continue
        except Exception:
            pass
    entries.sort(key=lambda kv: -len(kv[0]))
    _drive_device_map_cache = entries
    return entries


def _device_path_to_drive_path(obj_name: str, device_map: List[Tuple[str, str]]) -> Optional[str]:
    """Convert an NT object path (\\Device\\...) to a drive-letter path.

    Returns the lowercased drive-letter path, or None if no drive mapping
    applies (network redirector paths, etc.).
    """
    low = obj_name.lower()
    for device_prefix, letter in device_map:
        if low.startswith(device_prefix):
            rest = obj_name[len(device_prefix):]
            return (letter + rest).lower()
    return None


def _path_matches(candidate_lower: str, target_lower: str) -> bool:
    """True if candidate is the target itself or lives inside the target dir."""
    cand = candidate_lower.rstrip("\\")
    targ = target_lower.rstrip("\\")
    if cand == targ:
        return True
    return cand.startswith(targ + "\\")


def _open_process(pid: int, access: int):
    """OpenProcess wrapper; returns a handle or None. Never raises."""
    if not _HAVE_NT:
        return None
    try:
        handle = _kernel32.OpenProcess(access, False, pid)
        return handle if handle else None
    except Exception:
        return None


def _close_handle(handle) -> None:
    if not _HAVE_NT or not handle:
        return
    try:
        _kernel32.CloseHandle(handle)
    except Exception:
        pass


def _enumerate_handle_entries() -> List[Tuple[int, int]]:
    """Return [(pid, handle_value)] for every handle in the system.

    Uses NtQuerySystemInformation(SystemExtendedHandleInformation). Never raises.
    """
    if not _HAVE_NT:
        return []
    size = 1 << 20
    for _attempt in range(8):  # bounded buffer-growth attempts
        try:
            buf = (ctypes.c_byte * size)()
            ret_len = wintypes.ULONG(0)
            status = _ntdll.NtQuerySystemInformation(
                _SYSTEM_EXTENDED_HANDLE_INFORMATION, buf, size, ctypes.byref(ret_len)
            )
        except Exception:
            return []
        if status == _STATUS_INFO_LENGTH_MISMATCH:
            size = max(int(ret_len.value) + 65536, size * 2)
            continue
        if status != 0:
            return []
        try:
            fmt = "<Q" if _PTR == 8 else "<I"
            count = struct.unpack_from(fmt, buf, 0)[0]
        except Exception:
            return []
        entries: List[Tuple[int, int]] = []
        off = _HEADER_SIZE
        try:
            for _i in range(count):
                if off + _ENTRY_SIZE > size:
                    break
                if _PTR == 8:
                    _obj, pid, hval, _acc = struct.unpack_from("<QQQI", buf, off)
                else:
                    _obj, pid, hval, _acc = struct.unpack_from("<IIII", buf, off)
                entries.append((pid, hval))
                off += _ENTRY_SIZE
        except Exception:
            break
        return entries
    return []


def _duplicate_same_access(proc_handle, handle_value):
    """Duplicate a handle from another process into ours. Returns handle or None."""
    try:
        dup = wintypes.HANDLE()
        status = _ntdll.NtDuplicateObject(
            proc_handle,
            wintypes.HANDLE(handle_value),
            _kernel32.GetCurrentProcess(),
            ctypes.byref(dup),
            0,
            0,
            _DUPLICATE_SAME_ACCESS,
        )
        if status == 0 and dup.value:
            return dup.value
        return None
    except Exception:
        return None


def _query_object_name(handle) -> Optional[str]:
    """Return the NT object name (\\Device\\...) of a handle, or None."""
    if not _HAVE_NT:
        return None
    try:
        buf_size = 512
        buf = (ctypes.c_byte * buf_size)()
        ret_len = wintypes.ULONG(0)
        status = _ntdll.NtQueryObject(
            handle, _OBJECT_NAME_INFORMATION, buf, buf_size, ctypes.byref(ret_len)
        )
        if status in (_STATUS_INFO_LENGTH_MISMATCH, _STATUS_BUFFER_OVERFLOW):
            need = int(ret_len.value) + 64
            if need > (1 << 20):  # sanity cap
                return None
            buf = (ctypes.c_byte * need)()
            status = _ntdll.NtQueryObject(
                handle, _OBJECT_NAME_INFORMATION, buf, need, ctypes.byref(ret_len)
            )
        if status != 0:
            return None
        length = struct.unpack_from("<H", buf, 0)[0]
        if length == 0 or length > 65534:
            return None
        # UNICODE_STRING: USHORT Length; USHORT MaximumLength; PWSTR Buffer
        # (Buffer pointer sits at the next pointer-aligned offset).
        name_ptr = struct.unpack_from("<Q" if _PTR == 8 else "<I", buf, _PTR)[0]
        if not name_ptr:
            return None
        name = ctypes.wstring_at(name_ptr, length // 2)
        if not name or not name.lower().startswith("\\device\\"):
            return None
        return name
    except Exception:
        return None


def _process_image_name(pid: int) -> Tuple[str, str]:
    """Return (base_name, full_exe_path) for a pid; ("", "") on failure."""
    if not _HAVE_NT:
        return "", ""
    handle = None
    try:
        handle = _open_process(pid, _PROCESS_QUERY_LIMITED_INFORMATION)
        if not handle:
            return "", ""
        buf = ctypes.create_unicode_buffer(1024)
        size = wintypes.DWORD(1024)
        if _kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            exe = buf.value or ""
            return (Path(exe).name if exe else ""), exe
        return "", ""
    except Exception:
        return "", ""
    finally:
        _close_handle(handle)


def _matching_handles(target_lower: str, device_map: List[Tuple[str, str]]) -> List[Tuple[int, int]]:
    """Return [(pid, handle_value)] whose object name resolves under *target*.

    Groups enumeration by pid so each process is opened only once. Skips our
    own process and the kernel (pids 0 and 4). Never raises.
    """
    matches: List[Tuple[int, int]] = []
    my_pid = os.getpid()
    by_pid: Dict[int, List[int]] = {}
    try:
        entries = _enumerate_handle_entries()
    except Exception:
        return []
    for pid, hval in entries:
        if pid in _SKIP_PIDS or pid == my_pid:
            continue
        by_pid.setdefault(pid, []).append(hval)

    for pid, hvals in by_pid.items():
        proc_h = _open_process(pid, _PROCESS_DUP_HANDLE)
        if not proc_h:
            continue
        try:
            for hval in hvals:
                try:
                    dup = _duplicate_same_access(proc_h, hval)
                    if dup is None:
                        continue
                    try:
                        obj_name = _query_object_name(dup)
                    finally:
                        _close_handle(dup)
                    if not obj_name:
                        continue
                    drive_path = _device_path_to_drive_path(obj_name, device_map)
                    if drive_path and _path_matches(drive_path, target_lower):
                        matches.append((pid, hval))
                except Exception:
                    continue
        except Exception:
            continue
        finally:
            _close_handle(proc_h)
    return matches
