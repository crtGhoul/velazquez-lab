"""Secure multi-pass file wiping (the real "shredder").

Overwrites file contents (plus cluster slack), verifies on request, renames
the file to a random name (MFT filename obfuscation), then deletes it.
Directories are wiped recursively, then the empty directories are removed.

Protected system paths are ALWAYS refused - this module never weakens the
guards in utils.is_protected_path.
"""
import os
import random
import stat
import string
from pathlib import Path
from typing import Dict, List, Tuple

from .utils import is_protected_path, to_long_path, format_bytes

# ---------------------------------------------------------------------------
# Plain-language warning shown in the UI before a wipe runs.
# ---------------------------------------------------------------------------
SSD_WARNING = (
    "IMPORTANT: On SSDs, USB flash drives, and SD cards, software overwrite "
    "cannot guarantee that your data is unrecoverable. These drives use "
    "wear-leveling and over-provisioning: the drive's controller silently "
    "redirects writes to spare flash cells, so overwritten data can survive "
    "in hidden spare blocks that no program can reach. This wipe tool does "
    "its best (multiple overwrite passes, slack-area padding, filename "
    "obfuscation), but on flash media it is a best-effort cleanup, NOT a "
    "guarantee.\n\n"
    "If you need a real guarantee on flash media:\n"
    "1. Use the drive's built-in hardware Secure Erase (via the SSD maker's "
    "toolbox or your PC's BIOS/UEFI), or\n"
    "2. Encrypt the entire drive first, then throw away the key.\n\n"
    "On traditional spinning hard drives (HDDs), overwrite passes are "
    "effective: one full pass of random data is enough for any modern drive."
)

CHUNK_SIZE = 1024 * 1024        # 1 MiB I/O chunks
SLACK_BOUNDARY = 4096           # assume 4K clusters for slack-area padding

# Pass definitions: "R" = pseudorandom bytes, otherwise a single byte pattern.
# DoD 5220.22-M 3-pass: 0x00, 0xFF, then random.
# Gutmann 35-pass: the original 1996 patterns were designed for MFM/RLL
# floppy-era encodings and are MEANINGLESS on any modern drive - 35 random
# passes are included purely for the checkbox crowd. One random pass already
# defeats any plausible recovery on a modern HDD.
_PASS_PATTERNS: Dict[str, List[bytes]] = {
    "single": [b"R"],
    "dod": [b"\x00", b"\xff", b"R"],
    "gutmann": [b"R"] * 35,
}

_METHOD_LABELS = {
    "single": "1-pass pseudorandom",
    "dod": "DoD 5220.22-M (3-pass)",
    "gutmann": "Gutmann (35-pass)",
}

_RANDOM_NAME_CHARS = string.ascii_lowercase + string.digits


def _pass_bytes(pattern: bytes, n: int) -> bytes:
    """Return n bytes of overwrite data for a pass pattern."""
    if pattern == b"R":
        return os.urandom(n)
    return bytes([pattern[0]]) * n


def _make_writable(lp: str) -> None:
    """Clear the read-only flag so overwrite/rename/delete succeed."""
    try:
        os.chmod(lp, stat.S_IWRITE | stat.S_IREAD)
    except Exception:
        pass


def _overwrite_file(lp: str, size: int, patterns: List[bytes], verify: bool) -> bool:
    """Run overwrite passes over the file at long-path lp. Returns verify status."""
    verified = True
    for p_idx, pattern in enumerate(patterns):
        last_pass = p_idx == len(patterns) - 1
        first_chunk = None
        with open(lp, "r+b") as f:
            remaining = size
            offset = 0
            while remaining > 0:
                n = min(CHUNK_SIZE, remaining)
                chunk = _pass_bytes(pattern, n)
                if offset == 0:
                    first_chunk = chunk
                f.seek(offset)
                f.write(chunk)
                offset += n
                remaining -= n
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        # Verify (last pass only): re-read the head of the file and compare.
        # This proves the bytes we wrote actually landed in the file; it can
        # NOT prove anything about flash-media spare blocks (see SSD_WARNING).
        if verify and last_pass and size > 0 and first_chunk is not None:
            try:
                with open(lp, "rb") as f:
                    probe = f.read(min(CHUNK_SIZE, size))
                if probe != first_chunk:
                    verified = False
            except Exception:
                verified = False

    # Cluster-tip / slack wipe: extend-pad to the next 4K boundary with random
    # bytes (hits the cluster slack), fsync, then truncate back to real size.
    if size > 0:
        try:
            padded = ((size + SLACK_BOUNDARY - 1) // SLACK_BOUNDARY) * SLACK_BOUNDARY
            with open(lp, "r+b") as f:
                f.seek(size)
                f.write(os.urandom(padded - size))
                f.flush()
                try:
                    os.fsync(f.fileno())
                except Exception:
                    pass
                f.truncate(size)
        except Exception:
            pass
    return verified


def _wipe_single_file(path: Path, method: str, verify: bool) -> Tuple[bool, str]:
    """Securely wipe one regular file. Never called on protected paths."""
    patterns = _PASS_PATTERNS[method]
    lp = to_long_path(path)
    _make_writable(lp)
    try:
        size = os.path.getsize(lp)
    except OSError as e:
        return False, f"Could not read '{path.name}': {e}"

    ok_verify = _overwrite_file(lp, size, patterns, verify)

    # Rename to a random name (MFT filename obfuscation), then delete.
    rand_name = "".join(random.choice(_RANDOM_NAME_CHARS) for _ in range(16))
    rand_lp = to_long_path(path.parent / rand_name)
    try:
        os.rename(lp, rand_lp)
    except OSError:
        # Rename failed (odd FS); delete under the original name instead.
        rand_lp = lp
    try:
        os.remove(rand_lp)
    except OSError as e:
        return False, f"Overwrote '{path.name}' but could not delete it: {e}"

    label = _METHOD_LABELS[method]
    msg = (
        f"Securely wiped '{path.name}' ({label}, {format_bytes(size)} overwritten "
        f"incl. cluster slack), renamed and deleted."
    )
    if verify:
        msg += " Overwrite verified." if ok_verify else " WARNING: verify re-read mismatch."
    msg += " Note: on SSDs/flash media software overwrite cannot be guaranteed."
    return True, msg


def secure_wipe(path, method: str = "single", verify: bool = False) -> Tuple[bool, str]:
    """Securely wipe a file or directory.

    method: 'single' (default), 'dod', or 'gutmann'.
    Returns (success, human-readable status message).
    """
    p = Path(path).expanduser()

    # Guard 1: never touch protected system paths, symlinks included.
    if is_protected_path(p):
        return False, f"Refused: '{p}' is a protected system path."
    if p.is_symlink():
        return False, f"Refused: '{p}' is a symlink; wipe targets directly instead."

    # Guard 2: valid method only.
    if method not in _PASS_PATTERNS:
        return False, f"Unknown wipe method '{method}' (choose single, dod, or gutmann)."

    if not p.exists():
        return False, f"'{p}' does not exist."

    if p.is_dir():
        files = sorted(
            (f for f in p.rglob("*") if f.is_file() and not f.is_symlink()),
            key=lambda f: str(f),
        )
        wiped = 0
        total = 0
        failures: List[str] = []
        for f in files:
            ok, msg = _wipe_single_file(f, method, verify)
            if ok:
                wiped += 1
            else:
                failures.append(msg)
        # Remove directories bottom-up (deepest first).
        dirs = sorted(
            (d for d in p.rglob("*") if d.is_dir() and not d.is_symlink()),
            key=lambda d: len(str(d)),
            reverse=True,
        )
        for d in dirs:
            try:
                os.rmdir(to_long_path(d))
            except OSError:
                pass
        try:
            os.rmdir(to_long_path(p))
        except OSError:
            pass
        label = _METHOD_LABELS[method]
        msg = f"Securely wiped directory '{p.name}': {wiped} file(s), {label}."
        if failures:
            msg += f" {len(failures)} file(s) failed: " + "; ".join(failures[:3])
            return False, msg
        msg += " Note: on SSDs/flash media software overwrite cannot be guaranteed."
        return True, msg

    return _wipe_single_file(p, method, verify)
