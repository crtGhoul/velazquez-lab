import os
import winreg
import subprocess
import json
import re
import shlex
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# System and Driver keywords that should NOT be uninstalled casually
CORE_CRITICAL_KEYWORDS = [
    "visual c++", "directx", "vulkan", "runtime", "net framework",
    ".net", "chipset", "nvidia graphics driver", "amd software",
    "realtek audio", "intel(r) management engine", "wireless driver",
    "bluetooth driver", "windows driver", "synaptics", "touchpad",
    "host controller", "sound driver", "system firmware"
]

SAFE_RECOMMENDED_BLOAT = [
    "cortana", "xbox gaming overlay", "solitaire", "candy crush",
    "bing news", "bing weather", "tips", "skype", "feedback hub",
    "get help", "phone link", "clipchamp", "disney+", "spotify"
]

def assess_app_safety(app_name: str, publisher: str, is_uwp: bool = False) -> Tuple[str, str]:
    """
    Returns (safety_tier, reason)
    Tiers:
      - 'CRITICAL_SYSTEM' (Red: Keep - Core OS driver/runtime)
      - 'SAFE_BLOAT' (Green: Safe to remove - Store bloat/unneeded bundle)
      - 'USER_APP' (Yellow/Neutral: Safe if user doesn't use it anymore)
    """
    name_low = app_name.lower()
    pub_low = publisher.lower()

    for kw in CORE_CRITICAL_KEYWORDS:
        if kw in name_low:
            return "CRITICAL_SYSTEM", "System Runtime / Hardware Driver (Recommended to KEEP)"

    if is_uwp:
        for kw in SAFE_RECOMMENDED_BLOAT:
            if kw in name_low:
                return "SAFE_BLOAT", "Pre-installed Windows Store Bloat (Safe to remove)"
        return "SAFE_BLOAT", "Windows Store App (Safe to remove if unused)"

    if "microsoft" in pub_low and any(w in name_low for w in ["edge update", "edge webview2", "defender"]):
        return "CRITICAL_SYSTEM", "Windows Core Component (Keep)"

    return "USER_APP", "User Installed Application (Safe to remove if you don't need it)"

REG_UNINSTALL_LOCATIONS = [
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", "Win32 (64-bit)"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", "Win32 (32-bit)"),
    (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", "Win32 (User)"),
]

def _read_registry_values(root, subkey_path: str) -> Dict[str, Any]:
    values = {}
    try:
        with winreg.OpenKey(root, subkey_path, 0, winreg.KEY_READ) as key:
            subkeys_count, values_count, _ = winreg.QueryInfoKey(key)
            for i in range(values_count):
                try:
                    val_name, val_data, _ = winreg.EnumValue(key, i)
                    values[val_name] = val_data
                except OSError:
                    continue
    except OSError:
        pass
    return values

def _already_has_quiet_flags(cmd_lower: str) -> bool:
    """True if the command already carries a silent/unattended switch."""
    patterns = [
        r"(?:^|\s)/(?:s|silent|verysilent|qn|qb|quiet|passive)(?=\s|$|/)",
        r"(?:^|\s)--?(?:silent|quiet)(?=\s|$)",
        r"(?:^|\s)-s(?=\s|$)",
    ]
    return any(re.search(p, cmd_lower, re.IGNORECASE) for p in patterns)


def detect_installer_type(cmd: str) -> str:
    """Identify the installer technology behind an uninstall command string.

    Returns one of: 'msi', 'inno', 'nsis', 'installshield', 'adobe', 'steam',
    or 'unknown' when nothing matches (never guess).
    """
    lower = (cmd or "").lower()

    if "msiexec" in lower:
        return "msi"
    if "unins000.exe" in lower or "unins001.exe" in lower:
        return "inno"
    if "isuninst.exe" in lower or "isunist.exe" in lower:
        return "installshield"
    if "setup.exe" in lower and ("-f1" in lower or "/s-" in lower or "installshield" in lower):
        return "installshield"
    if "adobe" in lower and ("adobearm" in lower or "creative cloud" in lower or "acrobat" in lower):
        return "adobe"
    if "steam.exe" in lower:
        return "steam"

    # First executable token's basename decides NSIS (Inno markers already excluded above).
    m = re.search(r"([a-z0-9_\-\.]+\.exe)", lower)
    exe = m.group(1) if m else ""
    if exe in ("uninstall.exe", "uninst.exe"):
        return "nsis"
    return "unknown"


def build_quiet_command(cmd: str) -> str:
    """Build a silent variant of an uninstall command using per-installer recipes.

    QuietUninstallString (when the registry provides one) is always preferred
    over this — callers should only use this as a fallback. Unknown installer
    types are returned UNCHANGED: guessing flags is worse than prompting.
    """
    cleaned = (cmd or "").strip()
    if not cleaned:
        return ""
    lower = cleaned.lower()

    # Already silent: keep as-is.
    if _already_has_quiet_flags(lower):
        return cleaned

    itype = detect_installer_type(cleaned)

    if itype == "msi":
        # /i (install) -> /x (uninstall); product code usually follows directly
        # as /I{GUID}, so allow {/quote/whitespace/end after the switch.
        if re.search(r'(?i)(^|[\s"])/i(?=[\{"\s]|$)', cleaned):
            cleaned = re.sub(r'(?i)(^|[\s"])/i(?=[\{"\s]|$)', r"\1/x", cleaned)
        if "/qn" not in lower:
            cleaned += " /qn"
        if "/norestart" not in lower:
            cleaned += " /norestart"
        return cleaned

    if itype == "inno":
        return f"{cleaned} /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-"

    if itype == "nsis":
        return f"{cleaned} /S"

    if itype == "installshield":
        # /s is silent only with a recorded response file; the caller-facing
        # note about that lives in execute_uninstall().
        return f"{cleaned} /s"

    # adobe / steam / unknown: no verified silent form — return the original
    # command unchanged rather than guessing flags.
    return cleaned


def _inject_silent_flags(uninstall_str: str) -> str:
    """Deprecated alias for build_quiet_command(). Kept for backward compatibility."""
    return build_quiet_command(uninstall_str)

def get_installed_programs(include_uwp: bool = True) -> List[Dict[str, Any]]:
    """Scan and retrieve all installed Win32, Registry, and UWP / Store apps."""
    programs: List[Dict[str, Any]] = []
    seen_identifiers = set()

    # 1. Scan Registry Hives
    for root, hive_path, source_desc in REG_UNINSTALL_LOCATIONS:
        try:
            with winreg.OpenKey(root, hive_path, 0, winreg.KEY_READ) as parent_key:
                num_subkeys, _, _ = winreg.QueryInfoKey(parent_key)
                for i in range(num_subkeys):
                    try:
                        subkey_name = winreg.EnumKey(parent_key, i)
                        full_subkey = f"{hive_path}\\{subkey_name}"
                        data = _read_registry_values(root, full_subkey)

                        display_name = data.get("DisplayName", "").strip()
                        if not display_name:
                            continue

                        # Check if SystemComponent is flagged (often hidden drivers/dependencies)
                        if data.get("SystemComponent") == 1:
                            continue

                        # Size calculation (EstimatedSize is in KB in Windows registry)
                        est_size_kb = data.get("EstimatedSize", 0)
                        size_bytes = est_size_kb * 1024 if isinstance(est_size_kb, (int, float)) else 0

                        uninstall_cmd = str(data.get("UninstallString", "")).strip()
                        quiet_cmd = str(data.get("QuietUninstallString", "")).strip()
                        if not quiet_cmd and uninstall_cmd:
                            quiet_cmd = build_quiet_command(uninstall_cmd)

                        key_id = f"{display_name.lower()}_{data.get('Publisher', '').lower()}"
                        if key_id in seen_identifiers:
                            continue
                        seen_identifiers.add(key_id)

                        s_tier, s_desc = assess_app_safety(display_name, data.get("Publisher", ""), is_uwp=False)
                        programs.append({
                            "name": display_name,
                            "publisher": data.get("Publisher", "Unknown"),
                            "version": data.get("DisplayVersion", ""),
                            "install_date": str(data.get("InstallDate", "")),
                            "size_bytes": size_bytes,
                            "install_location": data.get("InstallLocation", ""),
                            "uninstall_string": uninstall_cmd,
                            "quiet_uninstall_string": quiet_cmd,
                            "registry_key": f"{'HKLM' if root == winreg.HKEY_LOCAL_MACHINE else 'HKCU'}\\{full_subkey}",
                            "source": "Win32",
                            "source_detail": source_desc,
                            "is_uwp": False,
                            "safety_tier": s_tier,
                            "safety_desc": s_desc,
                        })
                    except OSError:
                        continue
        except OSError:
            continue

    # 2. Scan UWP / Windows Store Apps via PowerShell
    if include_uwp:
        try:
            ps_cmd = (
                "Get-AppxPackage -AllUsers | "
                "Where-Object { -not $_.IsFramework -and $_.NonRemovable -ne $true } | "
                "Select-Object Name, PackageFullName, PublisherId, InstallLocation | "
                "ConvertTo-Json -Compress"
            )
            proc = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_cmd],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                timeout=12,
            )
            if proc.returncode == 0 and proc.stdout.strip():
                try:
                    loaded = json.loads(proc.stdout)
                    items = loaded if isinstance(loaded, list) else [loaded]
                    for item in items:
                        pkg_name = item.get("Name", "").strip()
                        pkg_full_name = item.get("PackageFullName", "").strip()
                        loc = item.get("InstallLocation", "")

                        if not pkg_name or not pkg_full_name:
                            continue

                        # NOTE (perf): package sizes used to be computed by walking
                        # every install dir — that made the whole scan take
                        # 10-30s. Sizes now stay 0 ("—") until measured on demand.
                        uwp_size = 0

                        s_tier, s_desc = assess_app_safety(pkg_name, "Microsoft Store / UWP", is_uwp=True)
                        programs.append({
                            "name": pkg_name,
                            "publisher": "Microsoft Store / UWP",
                            "version": pkg_full_name.split("_")[1] if "_" in pkg_full_name else "",
                            "install_date": "",
                            "size_bytes": uwp_size,
                            "install_location": loc,
                            "uninstall_string": f'powershell -NoProfile -Command "Remove-AppxPackage -Package {pkg_full_name}"',
                            "quiet_uninstall_string": f'powershell -NoProfile -Command "Remove-AppxPackage -Package {pkg_full_name}"',
                            "registry_key": "",
                            "source": "UWP",
                            "source_detail": "Windows Store App",
                            "is_uwp": True,
                            "safety_tier": s_tier,
                            "safety_desc": s_desc,
                        })
                except Exception:
                    pass
        except Exception:
            pass

    # Sort alphabetically by App Name
    programs.sort(key=lambda x: x["name"].lower())
    return programs

def execute_uninstall(prog_info: Dict[str, Any], silent: bool = False) -> Tuple[bool, str]:
    """Execute standard or silent uninstaller and await exit."""
    from .utils import terminate_app_processes, stop_and_delete_service

    app_name = prog_info.get("name", "")
    # Kill any active process / service for this app first so uninstaller doesn't get blocked
    if app_name and len(app_name) >= 3:
        terminate_app_processes(app_name)
        stop_and_delete_service(app_name)

    cmd = prog_info.get("quiet_uninstall_string") if silent else prog_info.get("uninstall_string")
    if not cmd:
        cmd = prog_info.get("uninstall_string")

    if not cmd:
        return False, "No valid uninstaller command found."

    # InstallShield /s is only fully silent with a recorded response file (.iss).
    is_note = ""
    if silent and detect_installer_type(cmd) == "installshield":
        is_note = (" Note: InstallShield's /s switch needs a recorded response file "
                   "(.iss) for a fully silent uninstall; it may still show UI otherwise.")

    try:
        if prog_info.get("is_uwp"):
            # UWP removal via PowerShell
            res = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            if res.returncode == 0:
                return True, f"Successfully removed Store package {prog_info['name']}."
            return False, f"Failed UWP uninstall: {res.stderr.strip() or res.stdout.strip()}"
        else:
            # Win32 uninstaller execution
            process = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            process.wait(timeout=300)

            # Post-uninstall kill check
            if app_name and len(app_name) >= 3:
                terminate_app_processes(app_name)

            return True, f"Completed uninstaller process for {prog_info['name']}.{is_note}"
    except subprocess.TimeoutExpired:
        return False, f"Timeout expired while executing uninstaller for {prog_info['name']}.{is_note}"
    except Exception as e:
        return False, f"Failed execution: {str(e)}"
