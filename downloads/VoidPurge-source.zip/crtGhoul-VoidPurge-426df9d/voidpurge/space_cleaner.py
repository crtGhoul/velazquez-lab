import os
import shutil
from pathlib import Path
from typing import List, Dict, Any, Tuple

from .utils import format_bytes, is_protected_path

def get_cache_targets() -> List[Dict[str, Any]]:
    """Define known junk, temporary, and cache directories."""
    user_home = Path.home()
    local_appdata = Path(os.environ.get("LOCALAPPDATA", str(user_home / "AppData" / "Local")))
    system_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))

    targets = [
        {
            "name": "User Temp Folder",
            "category": "System Temp",
            "path": Path(os.environ.get("TEMP", str(local_appdata / "Temp"))),
            "description": "Per-user application and installer temporary cache files.",
        },
        {
            "name": "Windows System Temp",
            "category": "System Temp",
            "path": system_root / "Temp",
            "description": "Operating system and background service temp files.",
        },
        {
            "name": "Windows Error Reporting (WER) Dumps",
            "category": "Crash Dumps",
            "path": Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "Microsoft" / "Windows" / "WER",
            "description": "App crash logs, minidumps, and queued error reports.",
        },
        {
            "name": "DirectX Shader Cache",
            "category": "Graphics Cache",
            "path": local_appdata / "D3DSCache",
            "description": "Precompiled graphics shader cache files.",
        },
        {
            "name": "NVIDIA / AMD DXCache",
            "category": "Graphics Cache",
            "path": local_appdata / "NVIDIA" / "DXCache",
            "description": "GPU driver DirectX compiled shaders.",
        },
        {
            "name": "pip (Python) Cache",
            "category": "Developer Caches",
            "path": local_appdata / "pip" / "cache",
            "description": "Cached Python wheels and package download archives.",
        },
        {
            "name": "npm (Node.js) Cache",
            "category": "Developer Caches",
            "path": Path(os.environ.get("APPDATA", str(user_home / "AppData" / "Roaming"))) / "npm-cache",
            "description": "Cached Node packages and tarballs.",
        },
        {
            "name": "Windows Delivery Optimization Cache",
            "category": "Windows Update",
            "path": system_root / "SoftwareDistribution" / "DeliveryOptimization",
            "description": "P2P peer update transfer cache files.",
        },
    ]

    return targets

def scan_caches() -> List[Dict[str, Any]]:
    """Scan all configured cache targets and compute sizes."""
    targets = get_cache_targets()
    results = []

    for t in targets:
        p: Path = t["path"]
        size_bytes = 0
        file_count = 0

        if p.exists() and not is_protected_path(p):
            try:
                for root_dir, _, files in os.walk(p):
                    for f in files:
                        try:
                            fp = os.path.join(root_dir, f)
                            size_bytes += os.path.getsize(fp)
                            file_count += 1
                        except Exception:
                            continue
            except Exception:
                pass

        results.append({
            "name": t["name"],
            "category": t["category"],
            "path": str(p),
            "description": t["description"],
            "size_bytes": size_bytes,
            "size_formatted": format_bytes(size_bytes),
            "file_count": file_count,
            "exists": p.exists(),
        })

    return results

def purge_cache(target_path_str: str) -> Tuple[int, int]:
    """Purge files inside target cache directory without deleting the root folder itself."""
    p = Path(target_path_str)
    if not p.exists() or is_protected_path(p):
        return 0, 0

    reclaimed_bytes = 0
    items_deleted = 0

    try:
        for entry in os.scandir(p):
            try:
                if entry.is_file(follow_symlinks=False):
                    f_size = entry.stat().st_size
                    os.unlink(entry.path)
                    reclaimed_bytes += f_size
                    items_deleted += 1
                elif entry.is_dir(follow_symlinks=False):
                    # compute dir size before removal
                    dir_path = Path(entry.path)
                    for root_dir, _, files in os.walk(dir_path):
                        for f in files:
                            try:
                                reclaimed_bytes += os.path.getsize(os.path.join(root_dir, f))
                            except Exception:
                                pass
                    shutil.rmtree(entry.path, ignore_errors=True)
                    items_deleted += 1
            except Exception:
                continue
    except Exception:
        pass

    return reclaimed_bytes, items_deleted
