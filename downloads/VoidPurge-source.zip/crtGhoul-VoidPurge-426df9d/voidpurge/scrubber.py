import csv
import ctypes
import os
import re
import shutil
import subprocess
import winreg
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional, Iterator

from .utils import (
    is_protected_path,
    backup_registry_key,
    ensure_ownership,
    format_bytes,
    BACKUP_DIR,
)

COMMON_LEFTOVER_ROOTS = [
    Path(os.environ.get("APPDATA", "")),
    Path(os.environ.get("LOCALAPPDATA", "")),
    Path(os.environ.get("PROGRAMDATA", "")),
    Path(r"C:\Program Files"),
    Path(r"C:\Program Files (x86)"),
    # Start Menu & Desktop shortcuts
    Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
    Path(os.environ.get("PROGRAMDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
    Path(os.environ.get("USERPROFILE", "")) / "Desktop",
    Path(os.environ.get("PUBLIC", r"C:\Users\Public")) / "Desktop",
]

# Roots that get a deeper recursive walk (bounded depth, see DEEP_SCAN_MAX_DEPTH).
DEEP_SCAN_ROOTS = [
    Path(os.environ.get("APPDATA", "")),
    Path(os.environ.get("LOCALAPPDATA", "")),
    Path(os.environ.get("PROGRAMDATA", "")),
]
DEEP_SCAN_MAX_DEPTH = 4

REG_SOFTWARE_ROOTS = [
    (winreg.HKEY_CURRENT_USER, r"Software", "HKCU\\Software"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE", "HKLM\\SOFTWARE"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node", "HKLM\\SOFTWARE\\WOW6432Node"),
    # Startup Run keys
    (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU\\Run"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM\\Run"),
]

# Confidence scoring (BCU-style). Items below CONFIDENCE_MIN_DELETE are skipped
# by delete_leftovers() unless force=True.
CONFIDENCE_MIN_DELETE = 40
CONFIDENCE_EXACT_NAME = 40
CONFIDENCE_PUBLISHER = 25
CONFIDENCE_WEAK_TOKEN = 15
CONFIDENCE_PENALTY_LIVE_LOCATION = -50
CONFIDENCE_PENALTY_SHARED_PUBLISHER = -30
CONFIDENCE_PENALTY_SHARED_ROOT = -20

# Path fragments that mark a shared system root (weaker leftover signal there).
SHARED_ROOT_MARKERS = ("common files",)


def _norm(s: str) -> str:
    """Normalize a name for near-exact comparison (lowercase, alphanumerics only)."""
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _build_tokens(app_name: str, publisher: str = "") -> Tuple[List[str], str, str]:
    """Build substring tokens + cleaned app/publisher names used for matching."""
    clean_name = (app_name or "").strip().lower()
    clean_pub = (publisher or "").strip().lower() if publisher and publisher.lower() != "unknown" else ""

    tokens = [clean_name]
    # If app name has multiple words, include primary token if length >= 4
    words = [w for w in clean_name.replace("-", " ").replace("_", " ").split() if len(w) >= 4]
    if len(words) == 1:
        tokens.append(words[0])

    if clean_pub and len(clean_pub) >= 4 and clean_pub not in ["microsoft corporation", "google llc"]:
        tokens.append(clean_pub)

    # Filter out dangerous short tokens
    tokens = [t for t in set(tokens) if len(t) >= 3]
    return tokens, clean_name, clean_pub


def _near_exact_name(item_name: str, target_name: str) -> bool:
    """True when the item name is the target name modulo separators/versions/suffixes.

    Catches 'CoolApp', 'cool-app', 'CoolApp (x64)', 'coolapp-2.1' for target 'coolapp',
    while rejecting genuinely different names that merely share a substring.
    """
    if not item_name or not target_name:
        return False
    ni, nt = _norm(item_name), _norm(target_name)
    if not ni or not nt:
        return False
    if ni == nt:
        return True
    # Target embedded with only a short suffix/prefix (version, arch, 'setup', ...)
    if nt in ni and len(ni) <= len(nt) + 8:
        return True
    return False


def _publisher_matches(item_name: str, publisher: str) -> bool:
    """True when the publisher/company name (or a significant word of it) is in the item name."""
    if not item_name or not publisher:
        return False
    n = item_name.lower()
    pub = publisher.lower()
    if pub in n:
        return True
    return any(len(w) >= 4 and w in n for w in re.split(r"[^a-z0-9]+", pub))


# ---------------------------------------------------------------------------
# Installed-app index (drives the negative confidence signals)
# ---------------------------------------------------------------------------

def _canon_path(p: str) -> str:
    """Canonicalize a path for comparison: unify separators, normalize, normcase.

    Works for Windows-style paths even when running on other platforms (tests).
    """
    s = (p or "").replace("\\", os.sep).replace("/", os.sep)
    return os.path.normcase(os.path.normpath(s))


_installed_programs_cache: Optional[List[Dict[str, Any]]] = None


def _get_installed_programs_cached() -> List[Dict[str, Any]]:
    """Return uninstaller.get_installed_programs(), cached for the process lifetime."""
    global _installed_programs_cache
    if _installed_programs_cache is None:
        try:
            from . import uninstaller
            _installed_programs_cache = uninstaller.get_installed_programs()
        except Exception:
            _installed_programs_cache = []
    return _installed_programs_cache


def get_installed_app_index(target_name: str = "", target_publisher: str = "") -> Dict[str, Any]:
    """Build a lookup index over currently installed programs for confidence scoring.

    Returns a dict with:
      target_name / target_publisher : normalized name of the app being scrubbed
      install_locations : {normcase(install dir) -> app display name}
      publisher_apps    : {publisher lower -> [app display names]}
    Never raises: failures yield an empty index.
    """
    index: Dict[str, Any] = {
        "target_name": (target_name or "").strip().lower(),
        "target_publisher": (target_publisher or "").strip().lower(),
        "install_locations": {},
        "publisher_apps": {},
    }
    try:
        programs = _get_installed_programs_cached()
    except Exception:
        return index
    for prog in programs:
        try:
            name = str(prog.get("name", "")).strip()
            pub = str(prog.get("publisher", "")).strip().lower()
            loc = str(prog.get("install_location", "")).strip()
            if pub and pub != "unknown":
                index["publisher_apps"].setdefault(pub, []).append(name)
            if loc:
                index["install_locations"][_canon_path(loc)] = name
        except Exception:
            continue
    return index


def _is_other_apps_location(path: str, index: Dict[str, Any]) -> Optional[str]:
    """Return the owning app name if path is (inside) another installed app's dir."""
    if not path:
        return None
    target = (index.get("target_name") or "")
    norm = _canon_path(path)
    locations = index.get("install_locations", {})
    # Exact match first, then containment (candidate inside a live install dir).
    owner = locations.get(norm)
    if owner and owner.strip().lower() != target:
        return owner
    for loc, owner_name in locations.items():
        if owner_name.strip().lower() == target:
            continue
        if norm.startswith(loc + os.sep):
            return owner_name
    return None


def _dir_contains_exe(path: str) -> bool:
    """Cheap top-level check: does this directory directly contain .exe files?"""
    try:
        with os.scandir(path) as it:
            for entry in it:
                if entry.is_file(follow_symlinks=False) and entry.name.lower().endswith(".exe"):
                    return True
    except (PermissionError, OSError, FileNotFoundError):
        pass
    return False


def score_candidate(
    name: str,
    publisher: str = "",
    installed_index: Optional[Dict[str, Any]] = None,
    path: str = "",
    item_type: str = "",
) -> Tuple[int, List[str]]:
    """Score one leftover candidate, BCU-style. Pure function (no I/O).

    Args:
        name: folder/file/registry-key/task/service display name.
        publisher: publisher of the app being scrubbed (drives the publisher signal).
        installed_index: dict from get_installed_app_index() (may be a test fake).
        path: filesystem path of the candidate ("" for registry/task/service items).
        item_type: "folder", "file", "registry", "task", "service".

    Returns (confidence 0-100, reasons list).
    """
    reasons: List[str] = []
    score = 0
    index = installed_index or {}
    target_name = (index.get("target_name") or "").strip().lower()
    target_pub = (publisher or index.get("target_publisher") or "").strip().lower()
    n = (name or "").lower()

    # --- Positive signals -------------------------------------------------
    if target_name and _near_exact_name(n, target_name):
        score += CONFIDENCE_EXACT_NAME
        reasons.append("name matches the application name (exact/near-exact)")
    else:
        score += CONFIDENCE_WEAK_TOKEN
        reasons.append("name only shares a leftover token (weak match)")

    publisher_hit = bool(target_pub) and _publisher_matches(n, target_pub)
    if publisher_hit:
        score += CONFIDENCE_PUBLISHER
        reasons.append("name matches the publisher/company name")

    # --- Negative signals --------------------------------------------------
    is_fs = item_type in ("folder", "file") and bool(path)
    if is_fs:
        owner = _is_other_apps_location(path, index)
        if owner:
            score += CONFIDENCE_PENALTY_LIVE_LOCATION
            reasons.append(f"path belongs to still-installed app '{owner}' (looks live)")
        elif item_type == "folder" and _dir_contains_exe(path):
            score += CONFIDENCE_PENALTY_LIVE_LOCATION
            reasons.append("folder still contains .exe files (looks live)")
        if any(m in path.lower() for m in SHARED_ROOT_MARKERS):
            score += CONFIDENCE_PENALTY_SHARED_ROOT
            reasons.append("under a shared root (Common Files)")

    if publisher_hit and target_pub:
        others = [
            a for a in index.get("publisher_apps", {}).get(target_pub, [])
            if a.strip().lower() != target_name
        ]
        if others:
            score += CONFIDENCE_PENALTY_SHARED_PUBLISHER
            reasons.append(f"publisher still has other installed apps ({len(others)})")

    score = max(0, min(100, score))
    return score, reasons


# ---------------------------------------------------------------------------
# Deep scan helpers
# ---------------------------------------------------------------------------

def _iter_deep_matches(roots: List[Path], tokens: List[str], max_depth: int = DEEP_SCAN_MAX_DEPTH) -> Iterator[Path]:
    """Yield directories (up to max_depth) under roots whose name matches a token."""
    for root in roots:
        try:
            if not root or not root.exists():
                continue
        except OSError:
            continue
        stack = [(root, 0)]
        while stack:
            cur, depth = stack.pop()
            if depth >= max_depth:
                continue
            try:
                with os.scandir(cur) as it:
                    entries = list(it)
            except (PermissionError, OSError):
                continue
            for entry in entries:
                try:
                    if entry.is_symlink():
                        continue
                    if not entry.is_dir(follow_symlinks=False):
                        continue
                    p = Path(entry.path)
                    if is_protected_path(p):
                        continue
                    name_lower = entry.name.lower()
                    if any(t in name_lower for t in tokens):
                        yield p
                    stack.append((p, depth + 1))
                except OSError:
                    continue


def _scan_prefetch(tokens: List[str]) -> List[Dict[str, Any]]:
    """Match Windows Prefetch (*.pf) entries by app token."""
    items: List[Dict[str, Any]] = []
    try:
        pf_dir = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "Prefetch"
        if not pf_dir.exists():
            return items
        for entry in pf_dir.iterdir():
            try:
                if not entry.is_file() or entry.suffix.lower() != ".pf":
                    continue
                if any(t in entry.stem.lower() for t in tokens):
                    size = entry.stat().st_size
                    items.append({
                        "type": "file",
                        "path": str(entry),
                        "name": entry.name,
                        "size_bytes": size,
                        "size_formatted": format_bytes(size),
                    })
            except OSError:
                continue
    except (PermissionError, OSError):
        pass
    return items


def _scan_wer(tokens: List[str]) -> List[Dict[str, Any]]:
    """Match Windows Error Reporting queues (ReportQueue/ReportArchive) by app token."""
    items: List[Dict[str, Any]] = []
    try:
        wer_base = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "Microsoft" / "Windows" / "WER"
        for sub in ("ReportQueue", "ReportArchive"):
            d = wer_base / sub
            if not d.exists():
                continue
            for entry in d.iterdir():
                try:
                    if not entry.is_dir():
                        continue
                    if any(t in entry.name.lower() for t in tokens):
                        size = _calculate_path_size(entry)
                        items.append({
                            "type": "folder",
                            "path": str(entry),
                            "name": entry.name,
                            "size_bytes": size,
                            "size_formatted": format_bytes(size),
                        })
                except OSError:
                    continue
    except (PermissionError, OSError):
        pass
    return items


def _scan_scheduled_tasks(tokens: List[str]) -> List[Dict[str, Any]]:
    """Match scheduled-task names via `schtasks /query /fo csv` (Windows only)."""
    items: List[Dict[str, Any]] = []
    if os.name != "nt":
        return items
    try:
        res = subprocess.run(
            ["schtasks", "/query", "/fo", "csv"],
            capture_output=True,
            text=True,
            timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        if res.returncode != 0 or not res.stdout.strip():
            return items
        for row in csv.reader(res.stdout.splitlines()):
            if not row:
                continue
            full_name = row[0].strip()
            leaf = full_name.rsplit("\\", 1)[-1].lower()
            if any(t in leaf for t in tokens):
                items.append({
                    "type": "task",
                    "path": full_name,
                    "name": leaf,
                    "size_bytes": 0,
                    "size_formatted": "Scheduled Task",
                })
    except Exception:
        pass
    return items


def _scan_services(tokens: List[str]) -> List[Dict[str, Any]]:
    """Match Windows service names via `sc query` (Windows only)."""
    items: List[Dict[str, Any]] = []
    if os.name != "nt":
        return items
    try:
        res = subprocess.run(
            ["sc", "query", "type=", "service", "state=", "all", "bufsize=", "8192"],
            capture_output=True,
            text=True,
            timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        if res.returncode != 0 or not res.stdout:
            return items
        svc_name = ""
        display_name = ""
        for line in res.stdout.splitlines():
            s = line.strip()
            if s.upper().startswith("SERVICE_NAME:"):
                # flush previous
                if svc_name:
                    items.extend(_match_service(svc_name, display_name, tokens))
                svc_name = s.split(":", 1)[1].strip()
                display_name = ""
            elif s.upper().startswith("DISPLAY_NAME:"):
                display_name = s.split(":", 1)[1].strip()
        if svc_name:
            items.extend(_match_service(svc_name, display_name, tokens))
    except Exception:
        pass
    return items


def _match_service(svc_name: str, display_name: str, tokens: List[str]) -> List[Dict[str, Any]]:
    hay = f"{svc_name} {display_name}".lower()
    if any(t in hay for t in tokens):
        return [{
            "type": "service",
            "path": svc_name,
            "name": display_name or svc_name,
            "size_bytes": 0,
            "size_formatted": "Windows Service",
        }]
    return []


# ---------------------------------------------------------------------------
# Ghost sweep: orphaned shortcuts, App Paths, MuiCache, orphan uninstall entries.
# These are what keep a deleted app visible in Windows Search ("missing path"
# on click). Killed shortcuts/index ghosts = the app truly disappears.
# ---------------------------------------------------------------------------

SHORTCUT_ROOTS = [
    Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
    Path(os.environ.get("PROGRAMDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
    Path(os.environ.get("USERPROFILE", "")) / "Desktop",
    Path(os.environ.get("PUBLIC", r"C:\Users\Public")) / "Desktop",
    Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Internet Explorer" / "Quick Launch" / "User Pinned" / "TaskBar",
]

APP_PATHS_KEYS = [
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths", "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths"),
    (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths", "HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths"),
]

MUICACHE_KEY = (winreg.HKEY_CURRENT_USER, r"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\MuiCache")


def _resolve_lnk_targets(lnk_paths: List[Path]) -> Dict[str, str]:
    """Resolve .lnk targets via a single PowerShell call (WScript.Shell).

    Returns {str(lnk_path): target_path or ""}. Windows-only; {} elsewhere.
    """
    if os.name != "nt" or not lnk_paths:
        return {}
    try:
        # One process for all links: emit "path<TAB>target" lines.
        items = "\n".join("'" + str(p).replace("'", "''") + "'" for p in lnk_paths)
        ps = (
            "$sh = New-Object -ComObject WScript.Shell; "
            f"@({items}) | ForEach-Object {{ "
            "$t=''; try { $t = $sh.CreateShortcut($_).TargetPath } catch {}; "
            "\"$_`t$t\" }"
        )
        res = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            capture_output=True, text=True, timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        out: Dict[str, str] = {}
        if res.returncode == 0:
            for line in res.stdout.splitlines():
                if "\t" in line:
                    p, t = line.split("\t", 1)
                    out[p] = t.strip()
        return out
    except Exception:
        return {}


def _scan_shortcuts(tokens: List[str]) -> List[Dict[str, Any]]:
    """Find Start Menu / Desktop / TaskBar shortcuts matching the app tokens.

    Each hit records whether its target still exists — a dead target means an
    orphaned ghost shortcut (the classic 'missing path' in Windows Search).
    """
    results: List[Dict[str, Any]] = []
    if os.name != "nt":
        return results
    lnks: List[Path] = []
    for root in SHORTCUT_ROOTS:
        try:
            if not root.exists():
                continue
        except OSError:
            continue
        try:
            base_depth = len(root.parts)
            for dirpath, dirnames, filenames in os.walk(root):
                # Keep the walk shallow: Start Menu subfolders, not the world.
                if len(Path(dirpath).parts) - base_depth > 3:
                    dirnames[:] = []
                    continue
                for f in filenames:
                    if f.lower().endswith(".lnk") and any(t in f.lower() for t in tokens):
                        lnks.append(Path(dirpath) / f)
        except OSError:
            continue
    targets = _resolve_lnk_targets(lnks)
    for p in lnks:
        tgt = targets.get(str(p), "")
        dead = bool(tgt) and not os.path.exists(tgt)
        results.append({
            "type": "shortcut",
            "path": str(p),
            "name": p.name,
            "size_bytes": 0,
            "size_formatted": "Shortcut" + (" (orphaned — target missing)" if dead else ""),
            "target": tgt,
            "target_dead": dead,
        })
    return results


def _scan_app_paths(tokens: List[str]) -> List[Dict[str, Any]]:
    """Find App Paths registry keys matching the app tokens."""
    results: List[Dict[str, Any]] = []
    if os.name != "nt":
        return results
    for root_hkey, sub_path, prefix in APP_PATHS_KEYS:
        try:
            with winreg.OpenKey(root_hkey, sub_path, 0, winreg.KEY_READ) as parent:
                n, _, _ = winreg.QueryInfoKey(parent)
                for i in range(n):
                    try:
                        k_name = winreg.EnumKey(parent, i)
                    except OSError:
                        continue
                    if any(t in k_name.lower() for t in tokens):
                        results.append({
                            "type": "registry",
                            "path": f"{prefix}\\{k_name}",
                            "name": k_name,
                            "size_bytes": 0,
                            "size_formatted": "App Paths Key",
                        })
        except OSError:
            continue
    return results


def _scan_muicache(tokens: List[str]) -> List[Dict[str, Any]]:
    """Find MuiCache display-name values matching the app tokens.

    MuiCache is the cache Windows Search / Explorer uses for app display names —
    stale values here keep a deleted app's name surfacing in search.
    """
    results: List[Dict[str, Any]] = []
    if os.name != "nt":
        return results
    root_hkey, sub_path = MUICACHE_KEY
    full = "HKCU\\Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\Shell\\MuiCache"
    try:
        with winreg.OpenKey(root_hkey, sub_path, 0, winreg.KEY_READ) as key:
            _, n_vals, _ = winreg.QueryInfoKey(key)
            for i in range(n_vals):
                try:
                    v_name, v_data, _ = winreg.EnumValue(key, i)
                except OSError:
                    continue
                hay = f"{v_name} {v_data}".lower()
                if any(t in hay for t in tokens):
                    results.append({
                        "type": "registry_value",
                        "path": full,
                        "value_name": v_name,
                        "name": v_name,
                        "size_bytes": 0,
                        "size_formatted": "MuiCache Value",
                    })
    except OSError:
        return results
    return results


def _read_uninstall_values(root_hkey, subkey_path: str) -> Dict[str, Any]:
    """Read all values of an uninstall registry key (local copy; no cross-module import)."""
    values: Dict[str, Any] = {}
    try:
        with winreg.OpenKey(root_hkey, subkey_path, 0, winreg.KEY_READ) as key:
            _, n_vals, _ = winreg.QueryInfoKey(key)
            for i in range(n_vals):
                try:
                    v_name, v_data, _ = winreg.EnumValue(key, i)
                    values[v_name] = v_data
                except OSError:
                    continue
    except OSError:
        pass
    return values


def _uninstall_target_missing(uninstall_str: str) -> bool:
    """True when an uninstall string points at a file that no longer exists."""
    s = (uninstall_str or "").strip()
    if not s:
        return True
    m = re.match(r'^\s*"([^"]+)"', s)
    target = m.group(1) if m else re.split(r"\s+", s, 1)[0]
    target = target.strip().strip('"')
    # msiexec / MsiExec.exe entries are product-code based — not file checks.
    if "msiexec" in target.lower():
        return False
    return not os.path.exists(target)


def _scan_orphan_uninstall_entries(tokens: List[str]) -> List[Dict[str, Any]]:
    """Find uninstall registry entries for the app whose uninstaller is gone.

    'Already deleted but Windows still thinks it's installed' — the entry itself
    is the leftover.
    """
    results: List[Dict[str, Any]] = []
    if os.name != "nt":
        return results
    hives = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", "HKLM"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", "HKLM"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", "HKCU"),
    ]
    for root_hkey, hive_path, prefix in hives:
        try:
            with winreg.OpenKey(root_hkey, hive_path, 0, winreg.KEY_READ) as parent:
                n, _, _ = winreg.QueryInfoKey(parent)
                for i in range(n):
                    try:
                        sub = winreg.EnumKey(parent, i)
                    except OSError:
                        continue
                    vals = _read_uninstall_values(root_hkey, f"{hive_path}\\{sub}")
                    disp = str(vals.get("DisplayName", "")).strip()
                    if not disp or not any(t in disp.lower() for t in tokens):
                        continue
                    if _uninstall_target_missing(str(vals.get("UninstallString", ""))):
                        results.append({
                            "type": "registry",
                            "path": f"{prefix}\\{hive_path}\\{sub}",
                            "name": f"{disp} (orphan uninstall entry)",
                            "size_bytes": 0,
                            "size_formatted": "Orphan Uninstall Key",
                        })
        except OSError:
            continue
    return results


def _notify_shell_change() -> None:
    """Tell the Windows shell something changed so search/icons refresh promptly."""
    if os.name != "nt":
        return
    try:
        ctypes.windll.shell32.SHChangeNotify(0x08000000, 0x0000, None, None)  # SHCNE_ASSOCCHANGED
    except Exception:
        pass


def _calculate_path_size(p: Path) -> int:
    """Calculate total size of file or folder in bytes."""
    try:
        if p.is_file():
            return p.stat().st_size
        total = 0
        for entry in os.scandir(p):
            try:
                if entry.is_file(follow_symlinks=False):
                    total += entry.stat().st_size
                elif entry.is_dir(follow_symlinks=False):
                    total += _calculate_path_size(Path(entry.path))
            except Exception:
                continue
        return total
    except Exception:
        return 0


def _score_and_attach(item: Dict[str, Any], publisher: str, index: Dict[str, Any]) -> Dict[str, Any]:
    conf, reasons = score_candidate(
        item.get("name", ""),
        publisher,
        index,
        path=item.get("path", ""),
        item_type=item.get("type", ""),
    )
    item["confidence"] = conf
    item["reasons"] = reasons
    return item


def scan_leftovers(app_name: str, publisher: str = "") -> Dict[str, List[Dict[str, Any]]]:
    """Scan file system and registry for leftover folders and keys matching app/publisher.

    Every returned item carries ``confidence`` (0-100) and ``reasons`` (list of
    strings) from the BCU-style scorer. Deep sources covered: AppData /
    LocalAppData / ProgramData (recursive, depth 4), Prefetch, WER queues,
    scheduled tasks, services, orphaned shortcuts, App Paths keys, MuiCache
    values, and orphan uninstall entries (the "ghost sweep" that clears the app
    from Windows Search).
    """
    file_results: List[Dict[str, Any]] = []
    reg_results: List[Dict[str, Any]] = []

    tokens, clean_name, clean_pub = _build_tokens(app_name, publisher)
    index = get_installed_app_index(clean_name, clean_pub)

    seen_paths = set()

    def _add_file(item: Dict[str, Any]):
        key = os.path.normcase(item["path"])
        if key in seen_paths:
            return
        seen_paths.add(key)
        file_results.append(_score_and_attach(item, clean_pub, index))

    # 1. Top-level file system scan (existing behavior)
    for root in COMMON_LEFTOVER_ROOTS:
        try:
            if not root.exists():
                continue
        except OSError:
            continue
        try:
            for item in root.iterdir():
                if is_protected_path(item):
                    continue
                item_lower = item.name.lower()
                if any(token in item_lower for token in tokens):
                    try:
                        size = _calculate_path_size(item)
                        _add_file({
                            "type": "folder" if item.is_dir() else "file",
                            "path": str(item),
                            "name": item.name,
                            "size_bytes": size,
                            "size_formatted": format_bytes(size),
                        })
                    except OSError:
                        continue
        except (PermissionError, OSError):
            continue

    # 2. Deep recursive scan of AppData / LocalAppData / ProgramData (depth 4)
    try:
        for match in _iter_deep_matches(DEEP_SCAN_ROOTS, tokens):
            try:
                size = _calculate_path_size(match)
                _add_file({
                    "type": "folder",
                    "path": str(match),
                    "name": match.name,
                    "size_bytes": size,
                    "size_formatted": format_bytes(size),
                })
            except OSError:
                continue
    except Exception:
        pass

    # 3. Prefetch + WER
    for item in _scan_prefetch(tokens):
        _add_file(item)
    for item in _scan_wer(tokens):
        _add_file(item)

    # 4. Scheduled tasks + services (Windows only; no-ops elsewhere)
    for item in _scan_scheduled_tasks(tokens):
        _add_file(item)
    for item in _scan_services(tokens):
        _add_file(item)

    # 4b. Ghost sweep: shortcuts, App Paths, MuiCache, orphan uninstall entries.
    #     This is what removes the app from Windows Search results.
    seen_reg = set()

    def _add_reg(item: Dict[str, Any]):
        key = item["path"].lower()
        if key in seen_reg:
            return
        seen_reg.add(key)
        reg_results.append(_score_and_attach(item, clean_pub, index))

    for item in _scan_shortcuts(tokens):
        if item.get("target_dead"):
            item = _score_and_attach(item, clean_pub, index)
            item["confidence"] = min(100, item.get("confidence", 0) + 15)
            item["reasons"] = item.get("reasons", []) + [
                "shortcut points at a deleted target (orphaned ghost)"
            ]
            key = os.path.normcase(item["path"])
            if key not in seen_paths:
                seen_paths.add(key)
                file_results.append(item)
        else:
            _add_file(item)
    for item in _scan_app_paths(tokens):
        _add_reg(item)
    for item in _scan_muicache(tokens):
        key = (item["path"] + "\x00" + item.get("value_name", "")).lower()
        if key in seen_reg:
            continue
        seen_reg.add(key)
        reg_results.append(_score_and_attach(item, clean_pub, index))
    for item in _scan_orphan_uninstall_entries(tokens):
        _add_reg(item)

    # 5. Registry scan
    for root_hkey, sub_path, prefix in REG_SOFTWARE_ROOTS:
        try:
            with winreg.OpenKey(root_hkey, sub_path, 0, winreg.KEY_READ) as parent_key:
                num_subkeys, _, _ = winreg.QueryInfoKey(parent_key)
                for i in range(num_subkeys):
                    try:
                        k_name = winreg.EnumKey(parent_key, i)
                        k_lower = k_name.lower()
                        if any(token in k_lower for token in tokens):
                            full_reg = f"{prefix}\\{k_name}"
                            key = full_reg.lower()
                            if key in seen_reg:
                                continue
                            seen_reg.add(key)
                            reg_results.append(_score_and_attach({
                                "type": "registry",
                                "path": full_reg,
                                "name": k_name,
                                "size_bytes": 0,
                                "size_formatted": "Registry Key",
                            }, clean_pub, index))
                    except OSError:
                        continue
        except OSError:
            continue

    # Most confident first so the riskiest-looking items sort last.
    file_results.sort(key=lambda d: d.get("confidence", 0), reverse=True)
    reg_results.sort(key=lambda d: d.get("confidence", 0), reverse=True)

    return {
        "files": file_results,
        "registry": reg_results,
    }


def delete_leftovers(
    selected_items: List[Dict[str, Any]],
    use_recycle_bin: bool = False,
    app_hint: str = "",
    force: bool = False,
) -> Tuple[int, int, List[str]]:
    """Delete selected files and registry leftovers with automatic .reg backup.

    Items with confidence < 40 are skipped unless force=True (the skip is
    reported as an INFO line in the returned errors list; the 3-tuple return
    shape is unchanged for existing callers).
    """
    from .utils import terminate_app_processes, stop_and_delete_service, restart_explorer, schedule_delayed_deletion
    from .shredder import force_unlock_and_shred

    deleted_files = 0
    deleted_reg = 0
    skipped = 0
    errors: List[str] = []

    # 1. Terminate any running background processes or services associated with app_hint
    if app_hint and len(app_hint.strip()) >= 3:
        terminate_app_processes(app_hint)
        stop_and_delete_service(app_hint)

    for item in selected_items:
        itype = item.get("type")
        ipath = item.get("path", "")

        # Confidence gate: never auto-delete weak matches unless forced.
        confidence = item.get("confidence", 100)
        if not force and confidence < CONFIDENCE_MIN_DELETE:
            skipped += 1
            errors.append(f"INFO: Skipped low-confidence item ({confidence}%): {ipath or item.get('name', '')}")
            continue

        if itype == "registry":
            try:
                # 1. Export backup first
                backup_file = backup_registry_key(ipath, BACKUP_DIR)
                # 2. Delete registry key using reg.exe /f
                res = subprocess.run(
                    ["reg", "delete", ipath, "/f"],
                    capture_output=True,
                    text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                if res.returncode == 0:
                    deleted_reg += 1
                else:
                    errors.append(f"Reg delete failed ({ipath}): {res.stderr.strip()}")
            except Exception as e:
                errors.append(f"Reg error ({ipath}): {e}")

        elif itype == "registry_value":
            # Single registry value (e.g. MuiCache display-name entries). No key
            # backup needed — MuiCache is a cache Windows rebuilds on its own.
            vname = item.get("value_name", "")
            try:
                res = subprocess.run(
                    ["reg", "delete", ipath, "/v", vname, "/f"],
                    capture_output=True,
                    text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                if res.returncode == 0:
                    deleted_reg += 1
                else:
                    errors.append(f"Reg value delete failed ({ipath} \\ {vname}): {res.stderr.strip()}")
            except Exception as e:
                errors.append(f"Reg value error ({ipath} \\ {vname}): {e}")

        elif itype == "task":
            # Scheduled task removal (exact task path, user-selected only).
            try:
                res = subprocess.run(
                    ["schtasks", "/delete", "/tn", ipath, "/f"],
                    capture_output=True,
                    text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                if res.returncode == 0:
                    deleted_files += 1
                else:
                    errors.append(f"Task delete failed ({ipath}): {res.stderr.strip()}")
            except Exception as e:
                errors.append(f"Task error ({ipath}): {e}")

        elif itype == "service":
            # Service removal: stop (best effort), then delete by exact service name.
            try:
                subprocess.run(
                    ["sc", "stop", ipath],
                    capture_output=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                res = subprocess.run(
                    ["sc", "delete", ipath],
                    capture_output=True,
                    text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                if res.returncode == 0:
                    deleted_files += 1
                else:
                    errors.append(f"Service delete failed ({ipath}): {res.stderr.strip()}")
            except Exception as e:
                errors.append(f"Service error ({ipath}): {e}")

        else:
            p = Path(ipath)
            if not p.exists():
                continue
            if is_protected_path(p):
                errors.append(f"Blocked deletion of protected path: {ipath}")
                continue

            # Use Force Unlock & Shred engine for files/folders to unlock stubborn handles
            success, msg = force_unlock_and_shred(str(p), use_recycle_bin=use_recycle_bin)
            if success:
                deleted_files += 1
            else:
                errors.append(f"Delete failed ({ipath}): {msg}")

    if skipped:
        errors.append(
            f"INFO: Skipped {skipped} low-confidence item(s) (< {CONFIDENCE_MIN_DELETE}%). "
            "Re-run with force=True to include them."
        )

    # 2. Restart explorer if anything was deleted to clear dead taskbar/tray icons,
    #    and nudge the shell so Windows Search drops the ghosts promptly.
    if deleted_files > 0 or deleted_reg > 0:
        _notify_shell_change()
        restart_explorer()

    return deleted_files, deleted_reg, errors
