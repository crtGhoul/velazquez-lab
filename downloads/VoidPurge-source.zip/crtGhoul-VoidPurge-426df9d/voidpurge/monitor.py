"""Revo-style install monitor for VoidPurge.

Workflow: take_snapshot() captures the install-relevant system state *before*
the user runs an installer; take another snapshot after; diff_snapshots()
returns the exact set of things the install added, as scrubber-style item
dicts (confidence 95, "captured by install monitor") that drop straight into
the leftover UI for one-click removal.

This is the free answer to Revo Pro / IObit Pro's paywalled install monitor:
uninstall becomes an exact reversal instead of a heuristic hunt.
"""
import os
import subprocess
import winreg
from pathlib import Path
from typing import Any, Dict, List, Set

# Registry locations that installers write to.
SNAPSHOT_REG_KEYS = [
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
    (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"),
    (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"),
]
SNAPSHOT_REG_VALUES = [
    (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
]

# Filesystem roots where installers drop things (top-level names only — fast).
SNAPSHOT_DIR_ROOTS = [
    Path(os.environ.get("ProgramFiles", r"C:\Program Files")),
    Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")),
    Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")),
    Path(os.environ.get("APPDATA", "")),
    Path(os.environ.get("LOCALAPPDATA", "")),
]

_MONITORED = "captured by install monitor: created during the watched install"


def _safe_listdir(p: Path) -> Set[str]:
    try:
        if p.exists():
            return {e.name for e in os.scandir(p)}
    except OSError:
        pass
    return set()


def _reg_subkeys(root, path) -> Set[str]:
    try:
        with winreg.OpenKey(root, path, 0, winreg.KEY_READ) as k:
            n, _, _ = winreg.QueryInfoKey(k)
            return {winreg.EnumKey(k, i) for i in range(n)}
    except OSError:
        return set()


def _reg_value_names(root, path) -> Set[str]:
    try:
        with winreg.OpenKey(root, path, 0, winreg.KEY_READ) as k:
            _, n, _ = winreg.QueryInfoKey(k)
            names = set()
            for i in range(n):
                try:
                    names.add(winreg.EnumValue(k, i)[0])
                except OSError:
                    continue
            return names
    except OSError:
        return set()


def _service_names() -> Set[str]:
    try:
        res = subprocess.run(
            ["sc", "query", "state=", "all"],
            capture_output=True, text=True, timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        names = set()
        for line in res.stdout.splitlines():
            line = line.strip()
            if line.upper().startswith("SERVICE_NAME:"):
                names.add(line.split(":", 1)[1].strip())
        return names
    except Exception:
        return set()


def _task_names() -> Set[str]:
    try:
        res = subprocess.run(
            ["schtasks", "/query", "/fo", "csv", "/nh"],
            capture_output=True, text=True, timeout=60,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        names = set()
        for line in res.stdout.splitlines():
            line = line.strip().strip('"')
            if line.startswith("\\"):
                names.add(line)
        return names
    except Exception:
        return set()


def take_snapshot() -> Dict[str, Any]:
    """Capture install-relevant system state. Windows-only; {} elsewhere."""
    if os.name != "nt":
        return {}
    snap: Dict[str, Any] = {
        "reg_keys": {},
        "reg_values": {},
        "services": set(),
        "tasks": set(),
        "dirs": {},
    }
    for root, path in SNAPSHOT_REG_KEYS:
        snap["reg_keys"][(root, path)] = _reg_subkeys(root, path)
    for root, path in SNAPSHOT_REG_VALUES:
        snap["reg_values"][(root, path)] = _reg_value_names(root, path)
    snap["services"] = _service_names()
    snap["tasks"] = _task_names()
    for d in SNAPSHOT_DIR_ROOTS:
        snap["dirs"][str(d)] = _safe_listdir(d)
    return snap


def _monitored_item(item_type: str, path: str, name: str, size_note: str) -> Dict[str, Any]:
    return {
        "type": item_type,
        "path": path,
        "name": name,
        "size_bytes": 0,
        "size_formatted": size_note,
        "confidence": 95,
        "reasons": [_MONITORED],
    }


def diff_snapshots(before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    """Diff two snapshots -> {"files": [...], "registry": [...]} scrubber items.

    Pure function: works with hand-built snapshot dicts (used by the tests).
    """
    files: List[Dict[str, Any]] = []
    registry: List[Dict[str, Any]] = []
    if not before or not after:
        return {"files": files, "registry": registry}

    # New filesystem entries (top-level folders/files in watched roots).
    for root_str, after_names in after.get("dirs", {}).items():
        before_names = before.get("dirs", {}).get(root_str, set())
        for name in sorted(set(after_names) - set(before_names)):
            full = str(Path(root_str) / name)
            files.append(_monitored_item(
                "folder", full, name,
                "New during install" if os.path.isdir(full) else "New file during install",
            ))

    # New uninstall / App Paths keys.
    for (root, path), after_keys in after.get("reg_keys", {}).items():
        before_keys = before.get("reg_keys", {}).get((root, path), set())
        prefix = "HKLM" if root == winreg.HKEY_LOCAL_MACHINE else "HKCU"
        for sub in sorted(set(after_keys) - set(before_keys)):
            registry.append(_monitored_item(
                "registry", f"{prefix}\\{path}\\{sub}", sub, "Registry Key"))

    # New Run values.
    for (root, path), after_vals in after.get("reg_values", {}).items():
        before_vals = before.get("reg_values", {}).get((root, path), set())
        prefix = "HKLM" if root == winreg.HKEY_LOCAL_MACHINE else "HKCU"
        for val in sorted(set(after_vals) - set(before_vals)):
            item = _monitored_item("registry_value", f"{prefix}\\{path}", val, "Run Value")
            item["value_name"] = val
            registry.append(item)

    # New services / scheduled tasks.
    for svc in sorted(set(after.get("services", set())) - set(before.get("services", set()))):
        files.append(_monitored_item("service", svc, svc, "Windows Service"))
    for task in sorted(set(after.get("tasks", set())) - set(before.get("tasks", set()))):
        files.append(_monitored_item("task", task, task, "Scheduled Task"))

    return {"files": files, "registry": registry}
