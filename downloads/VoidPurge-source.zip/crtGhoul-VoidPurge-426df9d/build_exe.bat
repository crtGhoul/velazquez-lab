@echo off
setlocal enabledelayedexpansion

echo =======================================================
echo          VOIDPURGE STANDALONE BUILD SCRIPT
echo =======================================================
echo.

cd /d "%~dp0"

echo [*] Checking icon assets...
if not exist "icon.ico" (
    echo [*] Generating icons...
    python generate_icon.py
)

echo [*] Checking and installing Python dependencies...
python -m pip install -r requirements.txt --quiet
if errorlevel 1 (
    echo [-] Failed to install dependencies. Check your internet connection or Python path.
    pause
    exit /b 1
)

echo.
echo [*] Compiling standalone portable VoidPurge.exe with PyInstaller...
echo [*] Embedding icon into .exe binary, Taskbar, and Windows AppUserModelID...
echo.

python -m PyInstaller ^
    --noconfirm ^
    --onefile ^
    --windowed ^
    --uac-admin ^
    --clean ^
    --icon "icon.ico" ^
    --add-data "icon.ico;." ^
    --add-data "icon.png;." ^
    --name "VoidPurge" ^
    --collect-all "customtkinter" ^
    main.py

if errorlevel 1 (
    echo.
    echo [-] PyInstaller build failed! Review errors above.
    pause
    exit /b 1
)

echo.
echo =======================================================
echo [+] BUILD SUCCESSFUL!
echo =======================================================
echo.
echo Standalone executable created at:
echo "%~dp0dist\VoidPurge.exe"
echo.
echo The executable now has the VoidPurge cyber logo embedded in:
echo   - The .exe file icon in Windows Explorer
echo   - The running application window titlebar
echo   - The Windows Taskbar
echo.
pause
