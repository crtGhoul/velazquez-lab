# ⚡ VoidPurge

> **Advanced Windows Program Uninstaller, Deep Leftover Scrubber, and God-Mode Force File Shredder.**  
> Built with Python 3.12, CustomTkinter, Winreg, Psutil, and native Win32 APIs.

---

## ⚠️ Risks & Requirements

**This tool deletes things — read this first:**
- **Requires Administrator.** VoidPurge auto-prompts for UAC elevation on launch; most features won't work without it.
- **The Force Shredder permanently deletes files.** "Permanent Wipe" mode bypasses the Recycle Bin and overwrites data. The **Purge Bin mode** (default) quarantines deletions for 30 days with one-click restore — keep it on unless you know exactly what you're doing.
- **The Leftover Scrubber is aggressive by design.** It hunts files and registry keys across your whole system. Every registry key is auto-backed up to `%LocalAppData%\VoidPurge\backups\` before deletion, and a confirmation dialog gates every wipe — but **back up your system (restore point) before any major cleanup.**
- **Closing handles can crash apps.** Force-deleting a file an app is using may crash that app and lose unsaved work. VoidPurge shows you which process holds the file before acting.
- **Use at your own risk.** VoidPurge is provided as-is (see License). Never point it at anything you can't afford to lose.

---

## ⚡ Quickstart

1. Download `VoidPurge.exe` from the [latest release](https://github.com/crtGhoul/VoidPurge/releases/latest).
2. **Right-click → Run as administrator.**
3. Pick a tab: **Uninstaller** (remove programs), **Scrubber** (clean leftovers), **Shredder** (force-delete locked files), **Space** (purge caches/temp).
4. Review what it found, confirm, done. Deletions land in the Purge Bin first — restore anytime within 30 days.

---

## 🚀 Key Features

### 1. 📦 Deep Program Uninstaller (Win32 + Store Apps)
- **All 3 Registry Uninstall Hives:** Enumerate 64-bit `HKLM`, 32-bit `WOW6432Node`, and per-user `HKCU`.
- **Windows Store / UWP Bloatware Removal:** PowerShell package scanning and one-click removal via `Remove-AppxPackage`.
- **Silent & Standard Uninstall:** Uses native `QuietUninstallString` or injects silent flags (`/VERYSILENT`, `/qn`, `/S`, `/quiet`).
- **Safety Status Classification:** Automatically identifies apps as **🛡️ KEEP (System/Driver)**, **✨ SAFE TO REMOVE (Bloat)**, or **⚠️ SAFE IF UNUSED (User App)**.
- **Audit Export:** One-click export to interactive Cyber Dark **HTML Reports** and **CSV Spreadsheets**.

### 2. 🧹 Post-Uninstall Leftover Scrubber ("Deep Clean")
- Scans orphaned files and folders in `%AppData%`, `%LocalAppData%`, `%ProgramData%`, `C:\Program Files`, `C:\Program Files (x86)`, Start Menu, and Desktop.
- Scans `HKCU\Software`, `HKLM\Software`, and Windows Startup keys.
- **Automatic .reg Backups:** Every deleted registry key is automatically backed up to `%LocalAppData%\VoidPurge\backups\`.
- **Background Service & Process Slaying:** Automatically terminates associated Windows background services (`sc stop` & `sc delete`) and running processes.
- **Taskbar / Explorer Refresh:** Refreshes `explorer.exe` to flush stale taskbar and system tray ghost icons.

### 3. 💥 "God-Mode" Force File/Folder Shredder (LockHunter Engine)
- Enumerates **all** system handles on a target via native `NtQuerySystemInformation` (catches memory-mapped files, loaded DLLs, and directory locks) and **closes individual file handles** instead of killing whole processes.
- Strips NTFS ACL restrictions and takes ownership (`takeown /F <path> /R /D Y` & `icacls <path> /grant *S-1-5-32-544:F`).
- **Real secure wipe:** single-pass pseudorandom overwrite by default, DoD 5220.22-M 3-pass and Gutmann 35-pass optional. (Note: no software wipe can guarantee erasure on SSDs — wear-leveling hides old cells. VoidPurge says so in-app.)
- **Kernel-Locked Fallback:** Uses Win32 `MoveFileExW` (`MOVEFILE_DELAY_UNTIL_REBOOT`) for files locked by kernel drivers to delete them on the next reboot — with a visible queue you can inspect and cancel.
- **Purge Bin (default):** deletions are quarantined for 30 days with one-click restore; permanent delete is explicit opt-in. Recycle Bin (`send2trash`) mode also available.

### 4. 💾 Fast Space & Cache Purge
- One-click scan and sweep for User Temp, Windows Temp, Error Reporting (`WER`) Dumps, DirectX & GPU shader caches, and package caches (`pip`, `npm`).

---

## 🛡️ Built-in Safety Guardrails
- **Hardcoded Path Blacklist:** Prevents deletion of core OS components (`C:\Windows`, `C:\Windows\System32`, `C:\Users`, root drives).
- **Protected Processes:** Cannot kill vital Windows core processes (`explorer.exe`, `svchost.exe`, `csrss.exe`, `wininit.exe`, `services.exe`).
- **Automatic UAC Elevation:** Auto-prompts for Administrator privileges on launch.

---

## 🛠️ Building from Source

### Requirements
- Python 3.11+
- Install dependencies:
```bash
pip install -r requirements.txt
```

### Run
```bash
python main.py
```

### Compile Standalone Portable `.exe`
Run the included build script:
```cmd
build_exe.bat
```
The output executable will be generated at `./dist/VoidPurge.exe`.

---

## 📄 License

VoidPurge is released under the [MIT License](LICENSE). Free for everyone — personal and commercial use, no paywalls, no nag screens.
