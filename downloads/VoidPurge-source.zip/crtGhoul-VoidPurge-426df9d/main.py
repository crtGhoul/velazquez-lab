import os
import sys
import ctypes
import subprocess
import threading
from pathlib import Path

# Ensure running as admin, else re-launch with UAC elevation
def is_admin() -> bool:
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False

def run_as_admin():
    if sys.version_info >= (3, 8):
        params = ' '.join([f'"{arg}"' for arg in sys.argv])
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)
    else:
        script = ' '.join([f'"{arg}"' for arg in sys.argv])
        subprocess.run(['powershell', '-Command', f'Start-Process -FilePath "{sys.executable}" -ArgumentList "{script}" -Verb runAs'], check=True)
    sys.exit()

if not is_admin():
    print("[VoidPurge] Requesting administrator rights...")
    run_as_admin()

# Set cwd to script directory
os.chdir(Path(__file__).parent)

# Launch UI
from voidpurge.ui import launch_app

if __name__ == "__main__":
    launch_app()
