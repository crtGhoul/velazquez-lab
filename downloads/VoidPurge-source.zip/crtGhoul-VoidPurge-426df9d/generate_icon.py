import os
from PIL import Image, ImageDraw

def create_voidpurge_icon(output_ico_path: str, output_png_path: str):
    """Generate a cyber dark & crimson themed VoidPurge icon."""
    sizes = [(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)]
    images = []

    for width, height in sizes:
        # Create image with transparent background
        img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Scale factor
        s = width / 256.0

        # Rounded rectangle dark card backdrop
        card_margin = int(12 * s)
        corner_rad = int(36 * s)
        draw.rounded_rectangle(
            [(card_margin, card_margin), (width - card_margin, height - card_margin)],
            radius=corner_rad,
            fill=(14, 14, 19, 255),
            outline=(225, 29, 72, 230), # Crimson border
            width=max(1, int(6 * s)),
        )

        # High-energy Crimson / Ruby lightning bolt
        # Points normalized to 256x256
        raw_pts = [
            (145, 34),
            (75, 138),
            (130, 138),
            (105, 222),
            (185, 114),
            (132, 114),
            (168, 34),
        ]
        scaled_pts = [(int(x * s), int(y * s)) for x, y in raw_pts]

        # Draw glowing inner polygon
        draw.polygon(scaled_pts, fill=(225, 29, 72, 255))

        # Core highlight
        inner_pts = [
            (142, 54),
            (95, 132),
            (132, 132),
            (118, 195),
            (165, 120),
            (130, 120),
            (155, 54),
        ]
        scaled_inner = [(int(x * s), int(y * s)) for x, y in inner_pts]
        draw.polygon(scaled_inner, fill=(255, 100, 130, 255))

        images.append(img)

    # Save highest res as PNG
    images[0].save(output_png_path, format="PNG")

    # Save multi-resolution .ico
    images[0].save(
        output_ico_path,
        format="ICO",
        sizes=[(im.width, im.height) for im in images],
        append_images=images[1:],
    )
    print(f"Generated {output_ico_path} and {output_png_path}")

if __name__ == "__main__":
    icon_path = os.path.join(os.path.dirname(__file__), "icon.ico")
    png_path = os.path.join(os.path.dirname(__file__), "icon.png")
    create_voidpurge_icon(icon_path, png_path)
