import os
import sys
import ctypes
import subprocess
import threading
from pathlib import Path

# Ensure running as admin, else re-launch with UAC elevation
def is_admin() -> bool:
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False

def run_as_admin():
    params = ' '.join([f'"{arg}"' for arg in sys.argv if arg != "--no-elevate"])
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)
    if ret > 32:
        sys.exit()
    else:
        print(f"[VoidPurge] Elevation prompt dismissed or unavailable (code {ret}). Proceeding in standard user mode...")

if not is_admin() and "--no-elevate" not in sys.argv:
    print("[VoidPurge] Requesting administrator rights...")
    run_as_admin()

# Set cwd to script directory
os.chdir(Path(__file__).parent)

# Launch UI
from voidpurge.ui import launch_app

if __name__ == "__main__":
    launch_app()
