@echo off
cd /d "%~dp0"
echo Starting VoidPurge...
"C:\Users\velaz\AppData\Local\Programs\Python\Python312\python.exe" main.py
if errorlevel 1 pause
