import os
import sys
import json
import base64
import hashlib
import urllib.request
import subprocess
from pathlib import Path
from typing import Optional, Dict, Any, Tuple

# IMPORTANT: bump this on every release. If it lags behind the release tag,
# the updater will keep offering the same update in a loop.
CURRENT_VERSION = "1.2.0"

# Canonical update source: Codeberg releases (GitHub is not used).
REPO = "crtGhoul/VoidPurge"
API_URL = f"https://codeberg.org/api/v1/repos/{REPO}/releases/latest"

# Embedded minisign Ed25519 PUBLIC key (verifying only — safe to ship).
# Format: base64(b"Ed" + key_number(8) + ed25519_pubkey(32)).
# Signatures are produced at release time with the matching secret key,
# which is never stored in this repo. Releases carry "<exe>.minisig".
MINISIGN_PUBLIC_KEY = "RWRXjvz5OskgsoopRt8WU71CxYrJJOJTP9LErGliIy7XtQD/lYFeGhV0"

_USER_AGENT = "VoidPurge-AutoUpdater"


def parse_semver(v_str: str) -> Tuple[int, ...]:
    """Parse version string into tuple of integers."""
    clean = v_str.strip().lstrip("vV")
    parts = []
    for part in clean.split("."):
        try:
            parts.append(int(part))
        except ValueError:
            break
    return tuple(parts)


def check_for_updates() -> Optional[Dict[str, Any]]:
    """
    Check Codeberg Releases for a newer version of VoidPurge.
    Returns release info dict if an update is available, else None.
    """
    try:
        req = urllib.request.Request(
            API_URL,
            headers={
                "User-Agent": _USER_AGENT,
                "Accept": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status != 200:
                return None
            data = json.loads(resp.read().decode("utf-8"))

        latest_tag = data.get("tag_name", "")
        if not latest_tag:
            return None

        current = parse_semver(CURRENT_VERSION)
        latest = parse_semver(latest_tag)

        if latest > current:
            # Find the .exe asset and its .minisig signature asset.
            exe_url = None
            exe_name = None
            minisig_url = None
            for asset in data.get("assets", []):
                a_name = asset.get("name", "")
                if a_name.lower().endswith(".exe"):
                    exe_url = asset.get("browser_download_url")
                    exe_name = a_name
            if exe_name:
                want = (exe_name + ".minisig").lower()
                for asset in data.get("assets", []):
                    if asset.get("name", "").lower() == want:
                        minisig_url = asset.get("browser_download_url")
                        break

            return {
                "current_version": CURRENT_VERSION,
                "latest_version": latest_tag,
                "release_name": data.get("name", latest_tag),
                "html_url": data.get("html_url", f"https://codeberg.org/{REPO}/releases"),
                "body": data.get("body", "Bug fixes and improvements."),
                "download_url": exe_url,
                "exe_name": exe_name,
                "minisig_url": minisig_url,
            }
    except Exception as e:
        print(f"Update check error: {e}")
    return None


# ---------------------------------------------------------------------------
# Minisign (Ed25519) signature verification — FAIL CLOSED.
#
# Accepted .minisig layouts:
#   * Our release tooling:  "untrusted comment: ..."\n base64(b"Ed"||keynum||sig)
#   * Real minisign binary:  same, but the 2-byte algorithm field may be b"ED"
#     (prehashed mode: signature is over BLAKE2b-512(file bytes)) instead of
#     b"Ed" (pure Ed25519 over the raw file bytes). Extra comment lines are
#     tolerated but carry no security weight here.
# Any parse failure, key-number mismatch, or bad signature -> False.
# ---------------------------------------------------------------------------

def _parse_minisign_pubkey(pubkey_str: str) -> Tuple[bytes, bytes]:
    """Return (key_number, ed25519_pubkey) from a minisign public key string.

    Handles our tool's format (base64 of b"Ed"+keynum+pubkey) and the classic
    minisign format ("RW" + base64(keynum+pubkey)).
    """
    s = (pubkey_str or "").strip()
    # Our release tooling: base64(b"Ed" + keynum(8) + pubkey(32)).
    try:
        raw = base64.b64decode(s)
        if len(raw) == 42 and raw[0:2] == b"Ed":
            return raw[2:10], raw[10:42]
    except Exception:
        pass
    # Classic minisign: literal "RW" prefix, then base64(keynum(8)+pubkey(32)).
    if s.startswith("RW"):
        raw = base64.b64decode(s[2:])
        if len(raw) == 40:
            return raw[0:8], raw[8:40]
    raise ValueError("bad minisign public key format")


def _parse_minisig(sig_text: str) -> Tuple[bytes, bytes, bytes]:
    """Return (algo, key_number, signature) from a .minisig file's content."""
    data_lines = [
        ln.strip() for ln in (sig_text or "").splitlines()
        if ln.strip() and not ln.strip().lower().startswith("untrusted comment")
        and not ln.strip().lower().startswith("trusted comment")
    ]
    if not data_lines:
        raise ValueError("empty signature file")
    raw = base64.b64decode(data_lines[0])
    if len(raw) == 74:
        return raw[0:2], raw[2:10], raw[10:74]
    if len(raw) == 64:
        # Bare detached signature (no algorithm/keynum envelope).
        return b"Ed", b"", raw
    raise ValueError(f"bad signature length: {len(raw)}")


def verify_minisign_signature(file_path: Path, sig_text: str,
                              pubkey_str: str = MINISIGN_PUBLIC_KEY) -> bool:
    """Verify a downloaded file against a minisign signature. Fail closed.

    Returns True only if every check passes: pubkey parses, signature parses,
    key number matches (when present), and the Ed25519 signature verifies.
    """
    try:
        from nacl.signing import VerifyKey  # lazy: ships in bundle; absent -> no update
    except ImportError:
        print("UPDATE REJECTED: signature verification library unavailable.")
        return False
    try:
        keynum, pubkey = _parse_minisign_pubkey(pubkey_str)
        algo, sig_keynum, sig = _parse_minisig(sig_text)
        if sig_keynum and sig_keynum != keynum:
            print("UPDATE REJECTED: signature key number does not match embedded key.")
            return False
        data = Path(file_path).read_bytes()
        if algo == b"ED":
            # Prehashed mode: signature covers BLAKE2b-512(file bytes).
            message = hashlib.blake2b(data, digest_size=64).digest()
        elif algo == b"Ed":
            message = data
        else:
            print(f"UPDATE REJECTED: unknown signature algorithm {algo!r}.")
            return False
        VerifyKey(pubkey).verify(sig + message)  # raises on bad signature
        return True
    except Exception as e:
        print(f"UPDATE REJECTED: signature verification failed ({e}).")
        return False


def _download_text(url: str) -> Optional[str]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
        with urllib.request.urlopen(req, timeout=15) as resp:
            if resp.status != 200:
                return None
            return resp.read().decode("utf-8", errors="replace")
    except Exception as e:
        print(f"Signature download error: {e}")
        return None


def _cleanup(*paths: Path) -> None:
    for p in paths:
        try:
            Path(p).unlink()
        except Exception:
            pass


def download_and_apply_update(download_url: str, progress_callback=None,
                              minisig_url: Optional[str] = None,
                              exe_name: Optional[str] = None) -> bool:
    """
    Download the updated executable, verify its minisign Ed25519 signature,
    and spawn a batch script to replace the running executable seamlessly.

    FAIL CLOSED: a missing/unparseable/invalid signature aborts the update and
    the downloaded file is deleted. There is no bypass flag.
    """
    new_exe = None
    try:
        if not download_url:
            print("UPDATE REJECTED: no download URL for this release.")
            return False

        current_exe = Path(sys.executable).resolve()
        temp_dir = Path(os.environ.get("TEMP", "."))
        new_exe = temp_dir / "VoidPurge_Update.exe"
        new_sig = temp_dir / "VoidPurge_Update.exe.minisig"

        # Download updated binary with progress
        def _reporthook(blocknum, blocksize, totalsize):
            if progress_callback and totalsize > 0:
                percent = min(100, int((blocknum * blocksize / totalsize) * 100))
                progress_callback(percent)

        urllib.request.urlretrieve(download_url, str(new_exe), reporthook=_reporthook)

        if not new_exe.exists() or new_exe.stat().st_size < 1000000:
            print("UPDATE REJECTED: downloaded file missing or suspiciously small.")
            _cleanup(new_exe)
            return False

        # --- Minisign signature verification (fail closed) ---
        if not minisig_url:
            print("UPDATE REJECTED: release has no .minisig signature asset. "
                  "Aborting self-replace to protect against a compromised release pipeline.")
            _cleanup(new_exe)
            return False

        sig_text = _download_text(minisig_url)
        if not sig_text:
            print("UPDATE REJECTED: could not download the .minisig signature.")
            _cleanup(new_exe)
            return False
        try:
            new_sig.write_text(sig_text)
        except Exception:
            pass

        if not verify_minisign_signature(new_exe, sig_text, MINISIGN_PUBLIC_KEY):
            _cleanup(new_exe, new_sig)
            return False
        print(f"Update signature verified: {exe_name or 'VoidPurge.exe'}")
        _cleanup(new_sig)
        # --- end verification ---

        # Create self-replacing updater batch script
        updater_bat = temp_dir / "voidpurge_updater.bat"
        pid = os.getpid()
        bat_content = f"""@echo off
timeout /t 2 /nobreak > nul
:retry
taskkill /F /PID {pid} > nul 2>&1
timeout /t 1 /nobreak > nul
move /Y "{new_exe}" "{current_exe}" > nul 2>&1
if errorlevel 1 (
    timeout /t 1 /nobreak > nul
    goto retry
)
start "" "{current_exe}"
del "%~f0"
"""
        with open(updater_bat, "w") as f:
            f.write(bat_content)

        # Launch the updater script and terminate current process
        subprocess.Popen(
            ["cmd.exe", "/c", str(updater_bat)],
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        sys.exit(0)
    except SystemExit:
        raise
    except Exception as e:
        print(f"Failed to apply update: {e}")
        if new_exe is not None:
            _cleanup(new_exe)
        return False
