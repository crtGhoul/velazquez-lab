import os
import shutil
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Tuple

from .utils import format_bytes, is_protected_path


def _safe_exists(p: Path) -> bool:
    try:
        return p.exists()
    except (PermissionError, OSError):
        return False


def _safe_protected(p: Path) -> bool:
    try:
        return is_protected_path(p)
    except (PermissionError, OSError):
        return True


def get_cache_targets() -> List[Dict[str, Any]]:
    """Define known junk, temporary, and cache directories — comprehensive edition."""
    user_home = Path.home()
    local_appdata = Path(os.environ.get("LOCALAPPDATA", str(user_home / "AppData" / "Local")))
    roaming_appdata = Path(os.environ.get("APPDATA", str(user_home / "AppData" / "Roaming")))
    system_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))
    program_data = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))

    targets = [
        # ── System Temp ────────────────────────────────────────────────────
        {
            "name": "User Temp Folder",
            "category": "System Temp",
            "path": Path(os.environ.get("TEMP", str(local_appdata / "Temp"))),
            "description": "Per-user application and installer temporary cache files.",
        },
        {
            "name": "Windows System Temp",
            "category": "System Temp",
            "path": system_root / "Temp",
            "description": "Operating system and background service temp files.",
        },
        # ── Windows Update & Delivery Optimization ─────────────────────────
        {
            "name": "Windows Update Download Cache",
            "category": "Windows Update",
            "path": system_root / "SoftwareDistribution" / "Download",
            "description": "Downloaded Windows Update packages (safe when Windows Update is not running).",
        },
        {
            "name": "Windows Delivery Optimization Cache",
            "category": "Windows Update",
            "path": system_root / "SoftwareDistribution" / "DeliveryOptimization",
            "description": "P2P peer update transfer cache files.",
        },
        {
            "name": "Windows Installer Patch Cache",
            "category": "Windows Update",
            "path": system_root / "Installer" / "$PatchCache$",
            "description": "Cached MSI patch files (can reclaim significant space).",
        },
        # ── Crash Dumps ────────────────────────────────────────────────────
        {
            "name": "Windows Error Reporting (WER) Dumps",
            "category": "Crash Dumps",
            "path": program_data / "Microsoft" / "Windows" / "WER",
            "description": "App crash logs, minidumps, and queued error reports.",
        },
        {
            "name": "User WER Dumps",
            "category": "Crash Dumps",
            "path": local_appdata / "Microsoft" / "Windows" / "WER",
            "description": "Per-user crash dumps.",
        },
        # ── Windows Performance & Log Overhead ──────────────────────────────
        {
            "name": "Windows Prefetch",
            "category": "Windows Cache",
            "path": system_root / "Prefetch",
            "description": "Prefetch data for faster app startup (Windows rebuilds it automatically).",
        },
        {
            "name": "Thumbnail Cache",
            "category": "Windows Cache",
            "path": local_appdata / "Microsoft" / "Windows" / "Explorer",
            "description": "Explorer thumbnail image cache (thumbcache_*.db files).",
        },
        {
            "name": "Icon Cache",
            "category": "Windows Cache",
            "path": local_appdata / "Microsoft" / "Windows" / "Explorer",
            "description": "Explorer icon cache (Windows rebuilds on restart).",
        },
        {
            "name": "Windows Font Cache",
            "category": "Windows Cache",
            "path": system_root / "ServiceProfiles" / "LocalService" / "AppData" / "Local" / "FontCache",
            "description": "Font cache files rebuilt on Windows startup.",
        },
        # ── Graphics Cache ─────────────────────────────────────────────────
        {
            "name": "DirectX Shader Cache",
            "category": "Graphics Cache",
            "path": local_appdata / "D3DSCache",
            "description": "Precompiled DirectX graphics shader cache files.",
        },
        {
            "name": "NVIDIA DXCache / ShaderCache",
            "category": "Graphics Cache",
            "path": local_appdata / "NVIDIA" / "DXCache",
            "description": "NVIDIA GPU driver DirectX compiled shaders.",
        },
        {
            "name": "AMD Shader Cache",
            "category": "Graphics Cache",
            "path": local_appdata / "AMD" / "DX9Cache",
            "description": "AMD GPU driver shader cache.",
        },
        # ── Browser Caches ─────────────────────────────────────────────────
        {
            "name": "Google Chrome Cache",
            "category": "Browser Cache",
            "path": local_appdata / "Google" / "Chrome" / "User Data" / "Default" / "Cache",
            "description": "Chrome browser disk cache (web page resources).",
        },
        {
            "name": "Google Chrome Code Cache",
            "category": "Browser Cache",
            "path": local_appdata / "Google" / "Chrome" / "User Data" / "Default" / "Code Cache",
            "description": "Chrome V8 JavaScript compiled code cache.",
        },
        {
            "name": "Microsoft Edge Cache",
            "category": "Browser Cache",
            "path": local_appdata / "Microsoft" / "Edge" / "User Data" / "Default" / "Cache",
            "description": "Edge browser disk cache.",
        },
        {
            "name": "Microsoft Edge Code Cache",
            "category": "Browser Cache",
            "path": local_appdata / "Microsoft" / "Edge" / "User Data" / "Default" / "Code Cache",
            "description": "Edge V8 JavaScript compiled code cache.",
        },
        {
            "name": "Firefox Cache",
            "category": "Browser Cache",
            "path": local_appdata / "Mozilla" / "Firefox" / "Profiles",
            "description": "Firefox browser cache (cache2 subfolder inside each profile).",
        },
        {
            "name": "Brave Cache",
            "category": "Browser Cache",
            "path": local_appdata / "BraveSoftware" / "Brave-Browser" / "User Data" / "Default" / "Cache",
            "description": "Brave browser disk cache.",
        },
        {
            "name": "Opera Cache",
            "category": "Browser Cache",
            "path": roaming_appdata / "Opera Software" / "Opera Stable" / "Cache",
            "description": "Opera browser disk cache.",
        },
        # ── Developer Caches ───────────────────────────────────────────────
        {
            "name": "pip (Python) Cache",
            "category": "Developer Caches",
            "path": local_appdata / "pip" / "cache",
            "description": "Cached Python wheels and package download archives.",
        },
        {
            "name": "npm (Node.js) Cache",
            "category": "Developer Caches",
            "path": roaming_appdata / "npm-cache",
            "description": "Cached Node packages and tarballs.",
        },
        {
            "name": "NuGet Package Cache",
            "category": "Developer Caches",
            "path": user_home / ".nuget" / "packages",
            "description": "Cached NuGet packages for .NET development.",
        },
        {
            "name": "Yarn Cache",
            "category": "Developer Caches",
            "path": local_appdata / "Yarn" / "Cache",
            "description": "Yarn package manager download cache.",
        },
        {
            "name": "Gradle Cache",
            "category": "Developer Caches",
            "path": user_home / ".gradle" / "caches",
            "description": "Gradle build system cache.",
        },
        # ── System & Misc ──────────────────────────────────────────────────
        {
            "name": "Windows Memory Dump",
            "category": "Crash Dumps",
            "path": system_root,
            "description": "MEMORY.DMP — full OS crash dump (only if present; often gigabytes).",
            "files_only": ["MEMORY.DMP", "memory.dmp"],
        },
        {
            "name": "Steam Download Cache",
            "category": "Gaming Cache",
            "path": Path(r"C:\Program Files (x86)\Steam\steamapps\downloading"),
            "description": "In-progress Steam game downloads (paused/incomplete downloads).",
        },
        {
            "name": "Steam Package Cache",
            "category": "Gaming Cache",
            "path": Path(r"C:\Program Files (x86)\Steam\package"),
            "description": "Steam update package archive cache.",
        },
        {
            "name": "Epic Games Cache",
            "category": "Gaming Cache",
            "path": program_data / "Epic" / "EpicGamesLauncher" / "Data" / "Manifests",
            "description": "Epic Games Launcher manifest cache.",
        },
        {
            "name": "Microsoft Teams Cache",
            "category": "App Cache",
            "path": roaming_appdata / "Microsoft" / "Teams" / "Cache",
            "description": "Microsoft Teams web content cache.",
        },
        {
            "name": "Discord Cache",
            "category": "App Cache",
            "path": roaming_appdata / "discord" / "Cache",
            "description": "Discord application cache.",
        },
        {
            "name": "Slack Cache",
            "category": "App Cache",
            "path": roaming_appdata / "Slack" / "Cache",
            "description": "Slack application cache.",
        },
    ]

    return targets


def scan_caches() -> List[Dict[str, Any]]:
    """Scan all configured cache targets and compute sizes."""
    targets = get_cache_targets()
    results = []

    for t in targets:
        p: Path = t["path"]
        size_bytes = 0
        file_count = 0
        files_only = t.get("files_only")
        p_exists = _safe_exists(p)

        if p_exists and not _safe_protected(p):
            try:
                if files_only:
                    # Only scan for specific filenames (e.g. MEMORY.DMP)
                    for fname in files_only:
                        fp = p / fname
                        if _safe_exists(fp):
                            try:
                                size_bytes += fp.stat().st_size
                                file_count += 1
                            except Exception:
                                pass
                else:
                    for root_dir, _, files in os.walk(p):
                        for f in files:
                            try:
                                fp = os.path.join(root_dir, f)
                                size_bytes += os.path.getsize(fp)
                                file_count += 1
                            except Exception:
                                continue
            except Exception:
                pass

        results.append({
            "name": t["name"],
            "category": t["category"],
            "path": str(p),
            "description": t["description"],
            "size_bytes": size_bytes,
            "size_formatted": format_bytes(size_bytes),
            "file_count": file_count,
            "exists": p_exists,
            "files_only": t.get("files_only"),
        })

    return results


def purge_cache(target_path_str: str, files_only: List[str] = None) -> Tuple[int, int]:
    """Purge files inside target cache directory without deleting the root folder itself."""
    p = Path(target_path_str)
    if not _safe_exists(p) or _safe_protected(p):
        return 0, 0

    reclaimed_bytes = 0
    items_deleted = 0

    try:
        if files_only:
            # Only delete specific files (e.g. MEMORY.DMP)
            for fname in files_only:
                fp = p / fname
                if fp.exists():
                    try:
                        reclaimed_bytes += fp.stat().st_size
                        fp.unlink()
                        items_deleted += 1
                    except Exception:
                        pass
            return reclaimed_bytes, items_deleted

        for entry in os.scandir(p):
            try:
                if entry.is_file(follow_symlinks=False):
                    f_size = entry.stat().st_size
                    os.unlink(entry.path)
                    reclaimed_bytes += f_size
                    items_deleted += 1
                elif entry.is_dir(follow_symlinks=False):
                    dir_path = Path(entry.path)
                    for root_dir, _, files in os.walk(dir_path):
                        for f in files:
                            try:
                                reclaimed_bytes += os.path.getsize(os.path.join(root_dir, f))
                            except Exception:
                                pass
                    shutil.rmtree(entry.path, ignore_errors=True)
                    items_deleted += 1
            except Exception:
                continue
    except Exception:
        pass

    return reclaimed_bytes, items_deleted


def flush_dns_cache() -> Tuple[bool, str]:
    """Flush the Windows DNS resolver cache via ipconfig."""
    try:
        proc = subprocess.run(
            ["ipconfig", "/flushdns"],
            capture_output=True, text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            timeout=15,
        )
        if proc.returncode == 0:
            return True, "DNS resolver cache flushed successfully."
        return False, f"Failed to flush DNS cache: {proc.stderr.strip()}"
    except Exception as e:
        return False, f"DNS flush error: {e}"


def clear_event_logs() -> Tuple[int, str]:
    """Clear all Windows Event Logs using wevtutil. Returns (count_cleared, message)."""
    try:
        list_proc = subprocess.run(
            ["wevtutil", "el"],
            capture_output=True, text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            timeout=15,
        )
        logs = [l.strip() for l in list_proc.stdout.splitlines() if l.strip()]
        cleared = 0
        for log in logs:
            try:
                r = subprocess.run(
                    ["wevtutil", "cl", log],
                    capture_output=True, text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                    timeout=10,
                )
                if r.returncode == 0:
                    cleared += 1
            except Exception:
                continue
        return cleared, f"Cleared {cleared} of {len(logs)} Windows Event Logs."
    except Exception as e:
        return 0, f"Event log clear error: {e}"
