import os
import winreg
import subprocess
import json
import re
import shlex
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# System and Driver keywords that should NOT be uninstalled casually
CORE_CRITICAL_KEYWORDS = [
    "visual c++", "directx", "vulkan", "runtime", "net framework",
    ".net", "chipset", "nvidia graphics driver", "amd software",
    "realtek audio", "intel(r) management engine", "wireless driver",
    "bluetooth driver", "windows driver", "synaptics", "touchpad",
    "host controller", "sound driver", "system firmware"
]

# System core / hardware / framework UWP packages that MUST be protected
UWP_CRITICAL_KEYWORDS = [
    "winappruntime", "vclibs", "ui.xaml", "desktopappinstaller",
    "storepurchaseapp", "appinstaller", "sechealthui", "windowsdefender",
    "windowsterminal", "shellcomponents", "applicationcompatibilityenhancements",
    "net.native", "widgetsplatformruntime", "webmediapack", "videoextension",
    "imageextension", "mediaextension", "webpimageextension", "rawimageextension",
    "ink.handwriting", "startexperiencesapp", "brokerplugin", "accountscontrol",
    "asynctextservice", "bioenrollment", "lockapp", "contentdeliverymanager",
    "cbs", "parentalcontrols", "ecapp", "shellexperiencehost"
]

SAFE_RECOMMENDED_BLOAT = [
    # --- Microsoft UWP / Store bloat ---
    "cortana", "xbox gaming overlay", "xbox game bar", "xbox identity provider",
    "xbox app", "solitaire", "candy crush", "candy crush soda saga",
    "bing news", "bing weather", "bing finance", "bing sports",
    "tips", "skype", "feedback hub", "get help", "phone link", "clipchamp",
    "disney+", "spotify", "netflix", "amazon prime video", "hulu", "tiktok",
    "twitter", "facebook", "instagram", "messenger", "linkedin", "whatsapp",
    "microsoft news", "microsoft to do", "microsoft family safety",
    "microsoft people", "microsoft solitaire collection", "microsoft mahjong",
    "microsoft minesweeper", "microsoft sudoku", "mixed reality portal",
    "microsoft 3d viewer", "paint 3d", "movies & tv", "groove music",
    "print 3d", "3d viewer", "mail and calendar", "maps", "weather",
    # --- OEM / PC Manufacturer Junk ---
    "mcafee", "mcafee livesafe", "mcafee total protection",
    "norton", "norton 360", "norton security", "norton antivirus plus",
    "avast", "avast free antivirus", "avast cleanup premium",
    "avast driver updater", "avast secureline vpn",
    "avg antivirus", "avg antivirus free", "avg pc tuneup",
    "cyberlink powerdvd", "cyberlink photodirector", "cyberlink audiodirector",
    "cyberlink colordirector", "cyberlink powermedia player",
    "winzip", "winzip driver updater", "winzip registry optimizer",
    "winzip system utilities suite", "winzip malware protector",
    "driver booster", "driver easy", "driver talent", "drivermax",
    "pc app store", "asus live update", "asus battery health charging",
    "asus armory crate", "msi center", "msi dragon center", "msi app player",
    "hp support assistant", "hp jumpstart", "hp audio switch",
    "hp connection optimizer", "hp wolf security",
    "dell supportassist", "dell update", "dell optimizer", "dell mobile connect",
    "lenovo vantage", "lenovo system update", "lenovo pc experience",
    "acer care center", "acer product registration", "acer quick access",
    "samsung settings", "samsung magician", "samsung update",
    # --- Toolbars, Adware, PUPs ---
    "ask toolbar", "ask.com toolbar", "babylon toolbar", "conduit toolbar",
    "delta toolbar", "sweetpacks toolbar", "search protect",
    "web companion", "lavasoft web companion", "adaware antivirus",
    "superfish", "wajam", "websearch", "crossrider", "trovi", "myway",
    # --- Junk Cleaners / Registry Optimizers ---
    "ccleaner", "advanced systemcare", "advanced system optimizer",
    "iobit uninstaller", "iobit driver booster", "iobit malware fighter",
    "iolo system mechanic", "iolo privacy guardian",
    "glary utilities", "glary disk cleaner",
    "wise registry cleaner", "wise disk cleaner", "wise care 365",
    "registry winner", "registry mechanic", "speedupmypc",
    "uniblue driver scanner", "uniblue registrybooster",
    "pc optimizer pro", "regclean pro",
    # --- Misc Crapware ---
    "real player", "realplayer", "shockwave player", "adobe flash player",
    "java auto updater", "java update scheduler",
    "quicktime", "yandex browser", "maxthon", "uc browser",
    "comodo dragon", "comodo ice dragon",
]

# Publisher-level crapware detection
CRAPWARE_PUBLISHERS = [
    "iolo technologies", "iobit", "glarysoft", "uniblue", "wisecleaner",
    "systweak", "avanquest", "piriform", "lavasoft",
    "comodo", "conduit", "babylon", "ask.com", "opencandy",
    "wajam", "trovi", "myway", "sweetlabs", "superfish",
    "slimware utilities", "reimage",
]

def assess_app_safety(app_name: str, publisher: str, is_uwp: bool = False) -> Tuple[str, str]:
    """
    Returns (safety_tier, reason)
    Tiers:
      - 'CRITICAL_SYSTEM' (Red: Keep - Core OS driver/runtime)
      - 'CRAPWARE'        (Purple: Strongly recommended removal - adware/PUP/OEM junk)
      - 'SAFE_BLOAT'      (Green: Safe to remove - Store bloat/unneeded bundle)
      - 'USER_APP'        (Yellow/Neutral: Safe if user doesn't use it anymore)
    """
    name_low = app_name.lower()
    pub_low = publisher.lower()

    # 1. Protect OS-critical Win32 drivers and system runtimes
    for kw in CORE_CRITICAL_KEYWORDS:
        if kw in name_low:
            return "CRITICAL_SYSTEM", "System Runtime / Hardware Driver (Recommended to KEEP)"

    # 2. Protect Windows core UWP frameworks, extensions, and system components
    if is_uwp and any(kw in name_low for kw in UWP_CRITICAL_KEYWORDS):
        return "CRITICAL_SYSTEM", "Windows Core Component / Codec / Runtime (Protected)"

    if "microsoft" in pub_low and any(w in name_low for w in ["edge update", "edge webview2", "defender"]):
        return "CRITICAL_SYSTEM", "Windows Core Component (Keep)"

    # 3. Publisher-level crapware detection (strongest non-name signal)
    for pub_kw in CRAPWARE_PUBLISHERS:
        if pub_kw in pub_low:
            return "CRAPWARE", f"Known crapware/PUP publisher: {publisher} — Strongly recommended removal"

    # 4. Name-based bloat / crapware detection (Only ACTUAL bloat packages)
    for kw in SAFE_RECOMMENDED_BLOAT:
        if kw in name_low:
            if is_uwp:
                return "SAFE_BLOAT", "Pre-installed Windows Store Bloat (Safe to remove)"
            return "CRAPWARE", f"Known OEM bloat / PUP / adware: '{app_name}' — Strongly recommended removal"

    # 5. Generic UWP apps are standard user apps (NOT auto-bloat!)
    if is_uwp:
        return "USER_APP", "Windows Store App (Safe to remove if unused)"

    return "USER_APP", "User Installed Application (Safe to remove if you don't need it)"

REG_UNINSTALL_LOCATIONS = [
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", "Win32 (64-bit)"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall", "Win32 (32-bit)"),
    (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", "Win32 (User)"),
]

def _read_registry_values(root, subkey_path: str) -> Dict[str, Any]:
    values = {}
    try:
        with winreg.OpenKey(root, subkey_path, 0, winreg.KEY_READ) as key:
            subkeys_count, values_count, _ = winreg.QueryInfoKey(key)
            for i in range(values_count):
                try:
                    val_name, val_data, _ = winreg.EnumValue(key, i)
                    values[val_name] = val_data
                except OSError:
                    continue
    except OSError:
        pass
    return values

def _already_has_quiet_flags(cmd_lower: str) -> bool:
    """True if the command already carries a silent/unattended switch."""
    patterns = [
        r"(?:^|\s)/(?:s|silent|verysilent|qn|qb|quiet|passive)(?=\s|$|/)",
        r"(?:^|\s)--?(?:silent|quiet)(?=\s|$)",
        r"(?:^|\s)-s(?=\s|$)",
    ]
    return any(re.search(p, cmd_lower, re.IGNORECASE) for p in patterns)


def detect_installer_type(cmd: str) -> str:
    """Identify the installer technology behind an uninstall command string.

    Returns one of: 'msi', 'inno', 'nsis', 'installshield', 'adobe', 'steam',
    or 'unknown' when nothing matches (never guess).
    """
    lower = (cmd or "").lower()

    if "msiexec" in lower:
        return "msi"
    if "unins000.exe" in lower or "unins001.exe" in lower:
        return "inno"
    if "isuninst.exe" in lower or "isunist.exe" in lower:
        return "installshield"
    if "setup.exe" in lower and ("-f1" in lower or "/s-" in lower or "installshield" in lower):
        return "installshield"
    if "adobe" in lower and ("adobearm" in lower or "creative cloud" in lower or "acrobat" in lower):
        return "adobe"
    if "steam.exe" in lower:
        return "steam"

    # First executable token's basename decides NSIS (Inno markers already excluded above).
    m = re.search(r"([a-z0-9_\-\.]+\.exe)", lower)
    exe = m.group(1) if m else ""
    if exe in ("uninstall.exe", "uninst.exe"):
        return "nsis"
    return "unknown"


def build_quiet_command(cmd: str) -> str:
    """Build a silent variant of an uninstall command using per-installer recipes.

    QuietUninstallString (when the registry provides one) is always preferred
    over this â€” callers should only use this as a fallback. Unknown installer
    types are returned UNCHANGED: guessing flags is worse than prompting.
    """
    cleaned = (cmd or "").strip()
    if not cleaned:
        return ""
    lower = cleaned.lower()

    # Already silent: keep as-is.
    if _already_has_quiet_flags(lower):
        return cleaned

    itype = detect_installer_type(cleaned)

    if itype == "msi":
        # /i (install) -> /x (uninstall); product code usually follows directly
        # as /I{GUID}, so allow {/quote/whitespace/end after the switch.
        if re.search(r'(?i)(^|[\s"])/i(?=[\{"\s]|$)', cleaned):
            cleaned = re.sub(r'(?i)(^|[\s"])/i(?=[\{"\s]|$)', r"\1/x", cleaned)
        if "/qn" not in lower:
            cleaned += " /qn"
        if "/norestart" not in lower:
            cleaned += " /norestart"
        return cleaned

    if itype == "inno":
        return f"{cleaned} /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-"

    if itype == "nsis":
        return f"{cleaned} /S"

    if itype == "installshield":
        # /s is silent only with a recorded response file; the caller-facing
        # note about that lives in execute_uninstall().
        return f"{cleaned} /s"

    # adobe / steam / unknown: no verified silent form â€” return the original
    # command unchanged rather than guessing flags.
    return cleaned


def _inject_silent_flags(uninstall_str: str) -> str:
    """Deprecated alias for build_quiet_command(). Kept for backward compatibility."""
    return build_quiet_command(uninstall_str)

def get_installed_programs(include_uwp: bool = True, show_system_components: bool = False) -> List[Dict[str, Any]]:
    """Scan and retrieve all installed Win32, Registry, and UWP / Store apps."""
    programs: List[Dict[str, Any]] = []
    seen_identifiers = set()

    # 1. Scan Registry Hives
    for root, hive_path, source_desc in REG_UNINSTALL_LOCATIONS:
        try:
            with winreg.OpenKey(root, hive_path, 0, winreg.KEY_READ) as parent_key:
                num_subkeys, _, _ = winreg.QueryInfoKey(parent_key)
                for i in range(num_subkeys):
                    try:
                        subkey_name = winreg.EnumKey(parent_key, i)
                        full_subkey = f"{hive_path}\\{subkey_name}"
                        data = _read_registry_values(root, full_subkey)

                        display_name = data.get("DisplayName", "").strip()
                        if not display_name:
                            continue

                        # Check if SystemComponent is flagged (often hidden drivers/dependencies)
                        is_sys_comp = data.get("SystemComponent") == 1
                        if is_sys_comp and not show_system_components:
                            continue

                        # Size calculation (EstimatedSize is in KB in Windows registry)
                        est_size_kb = data.get("EstimatedSize", 0)
                        size_bytes = est_size_kb * 1024 if isinstance(est_size_kb, (int, float)) else 0

                        uninstall_cmd = str(data.get("UninstallString", "")).strip()
                        quiet_cmd = str(data.get("QuietUninstallString", "")).strip()
                        if not quiet_cmd and uninstall_cmd:
                            quiet_cmd = build_quiet_command(uninstall_cmd)

                        key_id = f"{display_name.lower()}_{data.get('Publisher', '').lower()}"
                        if key_id in seen_identifiers:
                            continue
                        seen_identifiers.add(key_id)

                        if is_sys_comp:
                            s_tier, s_desc = "CRITICAL_SYSTEM", "Windows System Component (Protected Dependency)"
                        else:
                            s_tier, s_desc = assess_app_safety(display_name, data.get("Publisher", ""), is_uwp=False)
                        programs.append({
                            "name": display_name,
                            "publisher": data.get("Publisher", "Unknown"),
                            "version": data.get("DisplayVersion", ""),
                            "install_date": str(data.get("InstallDate", "")),
                            "size_bytes": size_bytes,
                            "install_location": data.get("InstallLocation", ""),
                            "uninstall_string": uninstall_cmd,
                            "quiet_uninstall_string": quiet_cmd,
                            "registry_key": f"{'HKLM' if root == winreg.HKEY_LOCAL_MACHINE else 'HKCU'}\\{full_subkey}",
                            "source": "Win32",
                            "source_detail": source_desc,
                            "is_uwp": False,
                            "safety_tier": s_tier,
                            "safety_desc": s_desc,
                        })
                    except OSError:
                        continue
        except OSError:
            continue

    # 2. Scan UWP / Windows Store Apps via PowerShell
    if include_uwp:
        try:
            filter_clause = "" if show_system_components else " | Where-Object { -not $_.IsFramework -and $_.NonRemovable -ne $true }"
            ps_cmd = (
                f"$p = Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue; "
                f"if (-not $p) {{ $p = Get-AppxPackage }}; "
                f"$p{filter_clause} | "
                f"Select-Object Name, PackageFullName, PublisherId, InstallLocation | "
                f"ConvertTo-Json -Compress"
            )
            proc = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_cmd],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                timeout=12,
            )
            if proc.returncode == 0 and proc.stdout.strip():
                try:
                    loaded = json.loads(proc.stdout)
                    items = loaded if isinstance(loaded, list) else [loaded]
                    for item in items:
                        pkg_name = item.get("Name", "").strip()
                        pkg_full_name = item.get("PackageFullName", "").strip()
                        loc = item.get("InstallLocation", "")

                        if not pkg_name or not pkg_full_name:
                            continue

                        # NOTE (perf): package sizes used to be computed by walking
                        # every install dir â€” that made the whole scan take
                        # 10-30s. Sizes now stay 0 ("â€”") until measured on demand.
                        uwp_size = 0

                        s_tier, s_desc = assess_app_safety(pkg_name, "Microsoft Store / UWP", is_uwp=True)
                        programs.append({
                            "name": pkg_name,
                            "package_full_name": pkg_full_name,
                            "publisher": "Microsoft Store / UWP",
                            "version": pkg_full_name.split("_")[1] if "_" in pkg_full_name else "",
                            "install_date": "",
                            "size_bytes": uwp_size,
                            "install_location": loc,
                            "uninstall_string": f'powershell -NoProfile -Command "Remove-AppxPackage -Package {pkg_full_name}"',
                            "quiet_uninstall_string": f'powershell -NoProfile -Command "Remove-AppxPackage -Package {pkg_full_name}"',
                            "registry_key": "",
                            "source": "UWP",
                            "source_detail": "Windows Store App",
                            "is_uwp": True,
                            "safety_tier": s_tier,
                            "safety_desc": s_desc,
                        })
                except Exception:
                    pass
        except Exception:
            pass

    # Sort alphabetically by App Name
    programs.sort(key=lambda x: x["name"].lower())
    return programs

def execute_uninstall(prog_info: Dict[str, Any], silent: bool = False) -> Tuple[bool, str]:
    """Execute standard or silent uninstaller and await exit."""
    from .utils import terminate_app_processes, stop_and_delete_service

    app_name = prog_info.get("name", "")
    # Kill any active process / service for this app first so uninstaller doesn't get blocked
    if app_name and len(app_name) >= 3:
        terminate_app_processes(app_name)
        stop_and_delete_service(app_name)

    cmd = prog_info.get("quiet_uninstall_string") if silent else prog_info.get("uninstall_string")
    if not cmd:
        cmd = prog_info.get("uninstall_string")

    if not cmd:
        return False, "No valid uninstaller command found."

    # InstallShield /s is only fully silent with a recorded response file (.iss).
    is_note = ""
    if silent and detect_installer_type(cmd) == "installshield":
        is_note = (" Note: InstallShield's /s switch needs a recorded response file "
                   "(.iss) for a fully silent uninstall; it may still show UI otherwise.")

    try:
        if prog_info.get("is_uwp"):
            pkg_full = prog_info.get("package_full_name") or prog_info.get("name", "")
            pkg_name = prog_info.get("name", "")

            # 3-Stage Deprovision & Removal Script (AllUsers + CurrentUser + Deprovisioning)
            ps_script = (
                f"$ErrorActionPreference = 'SilentlyContinue'; "
                f"$pkg = '{pkg_full}'; $name = '{pkg_name}'; "
                f"Remove-AppxPackage -Package $pkg -AllUsers -ErrorAction SilentlyContinue; "
                f"Remove-AppxPackage -Package $pkg -ErrorAction SilentlyContinue; "
                f"Get-AppxProvisionedPackage -Online | Where-Object {{ $_.DisplayName -eq $name -or $_.PackageName -like ('*' + $name + '*') }} | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue; "
                f"$rem = Get-AppxPackage -Name $name -ErrorAction SilentlyContinue; "
                f"if ($rem) {{ Write-Output 'STILL_EXISTS' }} else {{ Write-Output 'SUCCESS' }}"
            )
            res = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                timeout=45,
            )
            out = res.stdout.strip()
            if "SUCCESS" in out:
                return True, f"Successfully removed Store package {prog_info['name']}."
            else:
                return False, f"Could not remove {prog_info['name']}: Windows protected system package."
        else:
            # Win32 uninstaller execution
            process = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            process.wait(timeout=300)

            # Post-uninstall kill check
            if app_name and len(app_name) >= 3:
                terminate_app_processes(app_name)

            return True, f"Completed uninstaller process for {prog_info['name']}.{is_note}"
    except subprocess.TimeoutExpired:
        return False, f"Timeout expired while executing uninstaller for {prog_info['name']}.{is_note}"
    except Exception as e:
        return False, f"Failed execution: {str(e)}"



# ─── Startup Manager ────────────────────────────────────────────────────────

STARTUP_CRITICAL_DRIVERS = [
    "rtkauduservice", "securityhealth", "realtek", "vanguard", "vgtray",
    "nvidia", "amd software", "amdrsserv", "amd driver", "radeon", "intel",
    "touchpad", "synaptics", "realtek audio", "sound driver", "tailscale", "wireless", "bluetooth"
]

STARTUP_BLOAT_KEYWORDS = [
    "logitech download assistant", "logilda", "microsoftedgeautolaunch",
    "edge", "af_counter", "af_uuid", "onedrive", "cortana", "telemetry",
    "update assistant", "browser helper", "ccleaner", "skype", "teams",
    "updater", "crashpad", "errorreporting"
]


def assess_startup_safety(name: str, command: str) -> Tuple[str, str]:
    """Classify a startup entry into CRITICAL_DRIVER, STARTUP_BLOAT, or USER_APP."""
    nl = (name or "").lower()
    cl = (command or "").lower()

    for kw in STARTUP_CRITICAL_DRIVERS:
        if kw in nl or kw in cl:
            return "CRITICAL_DRIVER", "Hardware Driver / Windows Security (Keep Enabled)"

    for kw in STARTUP_BLOAT_KEYWORDS:
        if kw in nl or kw in cl:
            return "STARTUP_BLOAT", "Startup Bloatware / Background Telemetry (Safe to Disable)"

    return "USER_APP", "User Application (Disable to accelerate Windows boot)"


STARTUP_REG_LOCATIONS = [
    (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",     "HKCU Run"),
    (winreg.HKEY_CURRENT_USER,  r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU RunOnce"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",     "HKLM Run"),
    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run", "HKLM Run (32-bit)"),
]


def get_startup_entries(show_system_tasks: bool = False) -> List[Dict[str, Any]]:
    """Return all startup entries from Startup Folders, Registry Run keys, and Task Scheduler."""
    entries: List[Dict[str, Any]] = []
    seen = set()

    # 1. Startup Folders
    appdata = Path(os.environ.get("APPDATA", ""))
    programdata = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))
    folders = [
        (appdata / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup", "Startup Folder (User)"),
        (programdata / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup", "Startup Folder (Common)"),
    ]
    for fpath, src in folders:
        if fpath.exists():
            try:
                for item in fpath.iterdir():
                    if item.name.lower() != "desktop.ini":
                        uid = f"file::{item.name.lower()}"
                        if uid not in seen:
                            seen.add(uid)
                            s_tier, s_desc = assess_startup_safety(item.name, str(item))
                            entries.append({
                                "name": item.name,
                                "command": str(item),
                                "source": src,
                                "file_path": str(item),
                                "registry_path": "",
                                "registry_root": "",
                                "task_name": "",
                                "safety_tier": s_tier,
                                "safety_desc": s_desc,
                                "enabled": True,
                            })
            except Exception:
                pass

    # 2. Registry Run keys
    for root, path, source in STARTUP_REG_LOCATIONS:
        try:
            with winreg.OpenKey(root, path, 0, winreg.KEY_READ) as key:
                _, val_count, _ = winreg.QueryInfoKey(key)
                for i in range(val_count):
                    try:
                        name, data, _ = winreg.EnumValue(key, i)
                        uid = f"reg::{source}::{name.lower()}"
                        if uid in seen:
                            continue
                        seen.add(uid)
                        s_tier, s_desc = assess_startup_safety(name, str(data))
                        entries.append({
                            "name": name,
                            "command": str(data),
                            "source": source,
                            "file_path": "",
                            "registry_path": path,
                            "registry_root": "HKCU" if root == winreg.HKEY_CURRENT_USER else "HKLM",
                            "task_name": "",
                            "safety_tier": s_tier,
                            "safety_desc": s_desc,
                            "enabled": True,
                        })
                    except OSError:
                        continue
        except OSError:
            continue

    # 3. Task Scheduler logon/boot triggers
    try:
        if show_system_tasks:
            ps = (
                "Get-ScheduledTask | "
                "Where-Object { $_.Triggers | Where-Object { $_.CimClass.CimClassName -like '*Logon*' -or $_.CimClass.CimClassName -like '*Boot*' } } | "
                "Select-Object TaskName, TaskPath, @{Name='State';Expression={$_.State.ToString()}} | "
                "ConvertTo-Json -Compress"
            )
        else:
            ps = (
                r'Get-ScheduledTask | '
                r'Where-Object { $_.TaskPath -notlike "\Microsoft\Windows\*" -and ($_.Triggers | Where-Object { $_.CimClass.CimClassName -like "*Logon*" -or $_.CimClass.CimClassName -like "*Boot*" }) } | '
                r"Select-Object TaskName, TaskPath, @{Name='State';Expression={$_.State.ToString()}} | "
                r"ConvertTo-Json -Compress"
            )
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
            capture_output=True, text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            timeout=10,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            tasks = json.loads(proc.stdout)
            if isinstance(tasks, dict):
                tasks = [tasks]
            for t in tasks:
                task_name = t.get("TaskName", "")
                task_path = t.get("TaskPath", "")
                uid = f"task::{task_name.lower()}"
                if uid in seen:
                    continue
                seen.add(uid)
                state = t.get("State", "Unknown")
                s_tier, s_desc = assess_startup_safety(task_name, task_path)
                entries.append({
                    "name": task_name,
                    "command": f"Task Scheduler: {task_path}\\{task_name}",
                    "source": "Task Scheduler",
                    "file_path": "",
                    "registry_path": "",
                    "registry_root": "",
                    "task_name": task_name,
                    "safety_tier": s_tier,
                    "safety_desc": s_desc,
                    "enabled": state == "Ready",
                })
    except Exception:
        pass

    tier_order = {"STARTUP_BLOAT": 0, "USER_APP": 1, "CRITICAL_DRIVER": 2}
    entries.sort(key=lambda x: (tier_order.get(x.get("safety_tier", "USER_APP"), 1), x["name"].lower()))
    return entries


def disable_startup_entry(entry: Dict[str, Any]) -> Tuple[bool, str]:
    """Disable or remove a startup entry safely (File shortcut, Task Scheduler, or Registry)."""
    # 1. Startup folder file shortcut
    fpath_str = entry.get("file_path")
    if fpath_str:
        try:
            p = Path(fpath_str)
            if p.exists():
                p.unlink(missing_ok=True)
                return True, f"Removed startup shortcut: {p.name}"
            return False, f"Startup shortcut not found: {fpath_str}"
        except Exception as e:
            return False, f"Failed to remove shortcut: {e}"

    # 2. Task Scheduler
    if entry.get("source") == "Task Scheduler":
        task_name = entry.get("task_name") or entry["name"]
        try:
            proc = subprocess.run(
                ["schtasks", "/Change", "/TN", task_name, "/DISABLE"],
                capture_output=True, text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                timeout=15,
            )
            if proc.returncode == 0:
                return True, f"Disabled scheduled task: {task_name}"
            return False, f"Failed to disable task: {proc.stderr.strip()}"
        except Exception as e:
            return False, str(e)

    # 3. Registry Run keys
    root_map = {"HKCU": winreg.HKEY_CURRENT_USER, "HKLM": winreg.HKEY_LOCAL_MACHINE}
    root = root_map.get(entry.get("registry_root", ""), None)
    if root is None:
        return False, "Unknown registry root."
    try:
        with winreg.OpenKey(root, entry["registry_path"], 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, entry["name"])
        return True, f"Removed startup entry: {entry['name']} from {entry['source']}"
    except Exception as e:
        return False, f"Failed: {e}"


def add_startup_entry(name: str, target_path: str) -> Tuple[bool, str]:
    """Add an application or shortcut to Windows startup (Startup Folder or Registry)."""
    import shutil
    clean_name = name.strip()
    clean_path = target_path.strip().strip('"')
    if not clean_name or not clean_path:
        return False, "Application name or file path cannot be empty."

    p = Path(clean_path)
    if not p.exists():
        return False, f"Selected file does not exist: {clean_path}"

    appdata = Path(os.environ.get("APPDATA", ""))
    startup_dir = appdata / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
    startup_dir.mkdir(parents=True, exist_ok=True)

    # 1. If it's a shortcut (.lnk), copy it directly to user Startup folder
    if p.suffix.lower() == ".lnk":
        dest_filename = p.name if p.name.lower().endswith(".lnk") else f"{clean_name}.lnk"
        dest = startup_dir / dest_filename
        try:
            shutil.copy2(p, dest)
            return True, f"Placed '{clean_name}' in Startup Folder: {dest.name}"
        except Exception as e:
            return False, f"Failed to copy shortcut: {e}"

    # 2. If it's an executable or script, write to HKCU Run key
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_SET_VALUE
        ) as key:
            winreg.SetValueEx(key, clean_name, 0, winreg.REG_SZ, f'"{clean_path}"')
        return True, f"Successfully added '{clean_name}' to Windows Startup (Registry)."
    except Exception as e:
        return False, f"Failed to add startup entry: {e}"
