import os
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from typing import List, Dict, Any, Optional, Callable

import customtkinter as ctk

from .utils import (
    is_admin,
    elevate_admin,
    format_bytes,
    BACKUP_DIR,
    LOGS_DIR,
)
import urllib.parse
import webbrowser

from .uninstaller import (
    get_installed_programs,
    execute_uninstall,
    get_startup_entries,
    disable_startup_entry,
    add_startup_entry,
)
from .scrubber import scan_leftovers, delete_leftovers
from .shredder import find_locking_processes, force_unlock_and_shred
from .space_cleaner import (
    scan_caches,
    purge_cache,
    flush_dns_cache,
    clear_event_logs,
)

# --- Devin ticket (Agent D): teammate modules land in parallel; import defensively ---
try:
    from .shredder import force_delete_with_ladder
    HAS_LADDER = True
except ImportError:
    force_delete_with_ladder = None
    HAS_LADDER = False

try:
    from .handles import (
        find_locking_processes_detailed,
        close_handles_on_path,
        enable_debug_privilege,
    )
    HAS_HANDLES = True
except ImportError:
    find_locking_processes_detailed = None
    close_handles_on_path = None
    enable_debug_privilege = None
    HAS_HANDLES = False

try:
    from .purgebin import (
        stage as purgebin_stage,
        restore as purgebin_restore,
        list_items as purgebin_list_items,
        empty as purgebin_empty,
        PURGE_BIN_DIR,
    )
    HAS_PURGEBIN = True
except ImportError:
    purgebin_stage = None
    purgebin_restore = None
    purgebin_list_items = None
    purgebin_empty = None
    PURGE_BIN_DIR = None
    HAS_PURGEBIN = False

try:
    from .wipe import SSD_WARNING
    HAS_WIPE = True
except ImportError:
    SSD_WARNING = ""
    HAS_WIPE = False

# Leftover items below this confidence score are left unchecked by default
LOW_CONFIDENCE_THRESHOLD = 60

# Cyber Dark Theme Palette
COLOR_BG = "#0b0b0e"
COLOR_SIDEBAR = "#121217"
COLOR_CARD = "#16161d"
COLOR_CARD_BORDER = "#23232e"
COLOR_TEXT_PRIMARY = "#f3f4f6"
COLOR_TEXT_SECONDARY = "#9ca3af"
COLOR_ACCENT_CRIMSON = "#e11d48"
COLOR_ACCENT_CRIMSON_HOVER = "#be123c"
COLOR_ACCENT_EMERALD = "#10b981"
COLOR_ACCENT_EMERALD_HOVER = "#059669"
COLOR_ACCENT_BLUE = "#3b82f6"
COLOR_ACCENT_BLUE_HOVER = "#2563eb"

class VoidPurgeApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Windows taskbar grouping AppUserModelID
        try:
            import ctypes
            myappid = "antigravity.voidpurge.uninstaller.1.0"
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        except Exception:
            pass

        self.title("VoidPurge - Advanced Windows Uninstaller & System Scrubber")
        self.geometry("1180x760")
        self.minsize(980, 640)
        self.configure(fg_color=COLOR_BG)

        # Set Window and Taskbar Icon
        self._setup_window_icon()

        # State storage
        self.all_programs: List[Dict[str, Any]] = []
        self.filtered_programs: List[Dict[str, Any]] = []
        self.prog_checkbox_vars: Dict[int, ctk.BooleanVar] = {}
        self._search_after_id: Optional[str] = None
        self.sort_column: str = "name"
        self.sort_descending: bool = False
        self._render_batch_job: Optional[str] = None
        self._render_gen = None
        self.current_leftovers: Dict[str, List[Dict[str, Any]]] = {"files": [], "registry": []}
        self._sorted_leftover_items: List[Dict[str, Any]] = []
        self.scrub_checkbox_vars: List[ctk.BooleanVar] = []
        self.cache_items: List[Dict[str, Any]] = []
        self.cache_checkbox_vars: List[ctk.BooleanVar] = []

        # Build UI Structure
        self._build_layout()

        # Start loading apps asynchronously
        self.log_message("VoidPurge initialized. Checking privileges: Administrator mode ACTIVE.")
        self.refresh_programs()

        # Check for GitHub updates in background
        self._check_updates_background()

        # Update startup dashboard stat in background
        self._refresh_startup_stats_background()

    def _build_layout(self):
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0) # Console
        self.grid_columnconfigure(0, weight=0) # Sidebar
        self.grid_columnconfigure(1, weight=1) # Main View

        # 1. Left Sidebar
        self.sidebar_frame = ctk.CTkFrame(self, width=220, fg_color=COLOR_SIDEBAR, corner_radius=0)
        self.sidebar_frame.grid(row=0, column=0, sticky="nsew")
        self.sidebar_frame.grid_rowconfigure(13, weight=1)

        # App Brand Title with Logo Image
        brand_frame = ctk.CTkFrame(self.sidebar_frame, fg_color="transparent")
        brand_frame.grid(row=0, column=0, padx=16, pady=(20, 4), sticky="w")

        # Try to load brand logo image
        try:
            base_dir = getattr(sys, '_MEIPASS', os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
            png_path = os.path.join(base_dir, "icon.png")
            if os.path.exists(png_path):
                from PIL import Image
                logo_pil = Image.open(png_path).resize((32, 32), Image.Resampling.LANCZOS)
                self.sidebar_logo_img = ctk.CTkImage(light_image=logo_pil, dark_image=logo_pil, size=(32, 32))
                self.logo_icon_label = ctk.CTkLabel(brand_frame, text="", image=self.sidebar_logo_img)
                self.logo_icon_label.pack(side="left", padx=(0, 8))
        except Exception:
            pass

        self.logo_label = ctk.CTkLabel(
            brand_frame,
            text="VOIDPURGE",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COLOR_ACCENT_CRIMSON,
        )
        self.logo_label.pack(side="left")

        self.sub_label = ctk.CTkLabel(
            self.sidebar_frame,
            text="High-Precision System Scrubber",
            font=ctk.CTkFont(size=11),
            text_color=COLOR_TEXT_SECONDARY,
        )
        self.sub_label.grid(row=1, column=0, padx=16, pady=(0, 20), sticky="w")

        # Sidebar Navigation Buttons
        self.nav_btns: Dict[str, ctk.CTkButton] = {}

        def _nav_section_label(row: int, text: str):
            lbl = ctk.CTkLabel(
                self.sidebar_frame,
                text=text,
                font=ctk.CTkFont(size=10, weight="bold"),
                text_color=COLOR_TEXT_SECONDARY,
            )
            lbl.grid(row=row, column=0, padx=16, pady=(8, 2), sticky="w")

        def _nav_button(row: int, tab_id: str, tab_label: str):
            btn = ctk.CTkButton(
                self.sidebar_frame,
                text=tab_label,
                font=ctk.CTkFont(size=13, weight="bold"),
                anchor="w",
                fg_color="transparent",
                text_color=COLOR_TEXT_PRIMARY,
                hover_color=COLOR_CARD,
                height=40,
                corner_radius=8,
                command=lambda t=tab_id: self.switch_tab(t),
            )
            btn.grid(row=row, column=0, padx=14, pady=3, sticky="ew")
            self.nav_btns[tab_id] = btn

        _nav_section_label(2, "MAIN")
        _nav_button(3, "home", "🏠 Dashboard")
        _nav_button(4, "uninstaller", "📦 Apps & Bloatware")
        _nav_button(5, "startup", "🚀 Startup Manager")

        _nav_section_label(6, "CLEANERS")
        _nav_button(7, "cache", "💾 Space & Cache Purge")
        _nav_button(8, "scrubber", "🧹 Leftover Scrubber")

        _nav_section_label(9, "ADVANCED")
        _nav_button(10, "shredder", "⚡ Force-Delete (Shred)")
        _nav_button(11, "purgebin", "🗑️ Purge Bin (Undo)")
        _nav_button(12, "reboot", "🔁 Reboot Queue")

        # Bottom Sidebar Quick Actions
        self.update_btn = ctk.CTkButton(
            self.sidebar_frame,
            text="🔄 Check for Updates",
            font=ctk.CTkFont(size=11),
            fg_color=COLOR_CARD,
            hover_color=COLOR_CARD_BORDER,
            text_color=COLOR_ACCENT_EMERALD,
            height=32,
            command=self._manual_check_updates,
        )
        self.update_btn.grid(row=14, column=0, padx=14, pady=(10, 4), sticky="ew")

        self.backup_btn = ctk.CTkButton(
            self.sidebar_frame,
            text="📁 Open .reg Backups",
            font=ctk.CTkFont(size=11),
            fg_color=COLOR_CARD,
            hover_color=COLOR_CARD_BORDER,
            text_color=COLOR_TEXT_SECONDARY,
            height=32,
            command=self._open_backups_folder,
        )
        self.backup_btn.grid(row=15, column=0, padx=14, pady=(4, 20), sticky="ew")

        # 2. Main Content Area
        self.content_container = ctk.CTkFrame(self, fg_color=COLOR_BG, corner_radius=0)
        self.content_container.grid(row=0, column=1, sticky="nsew", padx=16, pady=(16, 8))
        self.content_container.grid_rowconfigure(0, weight=1)
        self.content_container.grid_columnconfigure(0, weight=1)

        # Tab Frames — built lazily on first visit so startup stays fast.
        # (home + uninstaller are built eagerly: the program scan touches
        # the uninstaller tab's widgets.)
        self._tab_builders: Dict[str, Callable[[], Any]] = {
            "home": self._create_home_view,
            "uninstaller": self._create_uninstaller_view,
            "scrubber": self._create_scrubber_view,
            "shredder": self._create_shredder_view,
            "cache": self._create_cache_view,
            "purgebin": self._create_purgebin_view,
            "reboot": self._create_reboot_queue_view,
            "startup": self._create_startup_manager_view,
        }
        self.tab_frames: Dict[str, Any] = {}
        self._ensure_tab("home")
        self._ensure_tab("uninstaller")

        # 3. Bottom Execution Console
        self.console_frame = ctk.CTkFrame(self, height=140, fg_color=COLOR_SIDEBAR, corner_radius=0)
        self.console_frame.grid(row=1, column=0, columnspan=2, sticky="nsew")
        self.console_frame.grid_columnconfigure(1, weight=1)

        self.console_title = ctk.CTkLabel(
            self.console_frame,
            text="EXECUTION LOG",
            font=ctk.CTkFont(size=10, weight="bold"),
            text_color=COLOR_TEXT_SECONDARY,
        )
        self.console_title.grid(row=0, column=0, padx=16, pady=(6, 2), sticky="w")

        self.console_text = ctk.CTkTextbox(
            self.console_frame,
            height=90,
            fg_color="#08080a",
            text_color="#10b981",
            font=ctk.CTkFont(family="Consolas", size=11),
            corner_radius=6,
        )
        self.console_text.grid(row=1, column=0, columnspan=2, padx=16, pady=(0, 10), sticky="nsew")
        self.console_text.configure(state="disabled")

        # Display Initial Tab
        self.switch_tab("home")

    def _setup_window_icon(self):
        """Set window icon and taskbar presence from icon.ico or bundled PyInstaller path."""
        try:
            # Check PyInstaller _MEIPASS or local base directory
            base_dir = getattr(sys, '_MEIPASS', os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
            ico_path = os.path.join(base_dir, "icon.ico")
            if os.path.exists(ico_path):
                self.iconbitmap(default=ico_path)
            
            # Also set photo icon using tk.PhotoImage / PIL for Titlebar canvas
            png_path = os.path.join(base_dir, "icon.png")
            if os.path.exists(png_path):
                from PIL import ImageTk, Image
                img = Image.open(png_path)
                self.app_icon_photo = ImageTk.PhotoImage(img)
                self.wm_iconphoto(True, self.app_icon_photo)
        except Exception as e:
            print(f"Icon setup notice: {e}")

    def log_message(self, message: str):
        """Append an entry to the live bottom execution console."""
        def _append():
            self.console_text.configure(state="normal")
            self.console_text.insert("end", f"> {message}\n")
            self.console_text.see("end")
            self.console_text.configure(state="disabled")
        self.after(0, _append)

    def _ensure_tab(self, tab_id: str):
        """Build a tab's view on first visit (lazy) and return it."""
        if tab_id not in self.tab_frames:
            self.tab_frames[tab_id] = self._tab_builders[tab_id]()
        return self.tab_frames[tab_id]

    def switch_tab(self, tab_id: str):
        self._ensure_tab(tab_id)
        for name in self._tab_builders:
            frame = self.tab_frames.get(name)
            if name == tab_id:
                frame.grid(row=0, column=0, sticky="nsew")
                self.nav_btns[name].configure(fg_color=COLOR_CARD, text_color=COLOR_ACCENT_CRIMSON)
            elif frame is not None:
                frame.grid_forget()
                self.nav_btns[name].configure(fg_color="transparent", text_color=COLOR_TEXT_PRIMARY)
        # Refresh live panels whenever they are shown
        if tab_id == "purgebin":
            self._refresh_purgebin()
        elif tab_id == "reboot":
            self._refresh_reboot_queue()

    def _open_backups_folder(self):
        try:
            os.startfile(str(BACKUP_DIR))
        except Exception as e:
            self.log_message(f"Error opening backups: {e}")

    def _check_updates_background(self):
        """Asynchronously check for updates silently in the background on startup."""
        from .updater import check_for_updates
        def _task():
            update_info = check_for_updates()
            if update_info:
                self.after(0, lambda: self._show_update_modal(update_info))
        threading.Thread(target=_task, daemon=True).start()

    def _manual_check_updates(self):
        """Manually check for updates when user clicks sidebar button."""
        from .updater import check_for_updates, CURRENT_VERSION
        self.log_message("Checking for updates on GitHub...")
        def _task():
            update_info = check_for_updates()
            if update_info:
                self.after(0, lambda: self._show_update_modal(update_info))
            else:
                self.log_message(f"VoidPurge is up to date (Version {CURRENT_VERSION}).")
                self.after(0, lambda: messagebox.showinfo("VoidPurge", f"VoidPurge v{CURRENT_VERSION} is the latest version!"))
        threading.Thread(target=_task, daemon=True).start()

    def _show_update_modal(self, update_info: Dict[str, Any]):
        """Display an update dialog with changelog and one-click auto-install."""
        latest_ver = update_info.get("latest_version")
        curr_ver = update_info.get("current_version")
        body = update_info.get("body", "")
        download_url = update_info.get("download_url")

        msg = (
            f"A new version of VoidPurge is available!\n\n"
            f"Current: v{curr_ver}\n"
            f"Latest:  {latest_ver}\n\n"
            f"What's New:\n{body[:300]}\n\n"
            f"Would you like to auto-update now?"
        )
        if not messagebox.askyesno("Update Available", msg):
            return

        if not download_url:
            import webbrowser
            webbrowser.open(update_info.get("html_url", "https://codeberg.org/crtGhoul/VoidPurge/releases"))
            return

        # Auto-download and seamless replace (minisign Ed25519-verified, fail closed)
        from .updater import download_and_apply_update
        minisig_url = update_info.get("minisig_url")
        exe_name = update_info.get("exe_name")
        if not minisig_url:
            self.log_message("No .minisig signature published for this release — refusing auto-update. "
                             "Opening releases page so you can verify manually.")
            import webbrowser
            webbrowser.open(update_info.get("html_url"))
            return
        self.log_message(f"Downloading update {latest_ver}...")
        def _apply():
            def _prog(p):
                self.log_message(f"Downloading update... {p}%")
            success = download_and_apply_update(
                download_url, progress_callback=_prog,
                minisig_url=minisig_url, exe_name=exe_name)
            if not success:
                self.log_message("Auto-update failed or signature invalid. Opening releases page in browser.")
                import webbrowser
                webbrowser.open(update_info.get("html_url"))
        threading.Thread(target=_apply, daemon=True).start()

    # =========================================================================
    # HOME: THREE BIG PRIMARY ACTIONS
    # =========================================================================
    def _create_home_view(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self.content_container, fg_color="transparent")
        frame.grid_columnconfigure(0, weight=1)

        # Header Title
        title = ctk.CTkLabel(
            frame,
            text="⚡ Windows Mission Control",
            font=ctk.CTkFont(size=26, weight="bold"),
            text_color=COLOR_TEXT_PRIMARY,
        )
        title.pack(pady=(18, 4))

        subtitle = ctk.CTkLabel(
            frame,
            text="One-click Windows debloater, high-precision leftover cleaner, and system optimizer.",
            font=ctk.CTkFont(size=13),
            text_color=COLOR_TEXT_SECONDARY,
            justify="center",
        )
        subtitle.pack(pady=(0, 18))

        # ── 1. Live Stat Cards Banner ──────────────────────────────────────
        stats_frame = ctk.CTkFrame(frame, fg_color="transparent")
        stats_frame.pack(fill="x", padx=20, pady=(0, 16))
        stats_frame.grid_columnconfigure((0, 1, 2), weight=1)

        # Card 1: Debloat Status & 1-Click Action
        card1 = ctk.CTkFrame(stats_frame, fg_color=COLOR_CARD, border_color=COLOR_CARD_BORDER, border_width=1, corner_radius=12)
        card1.grid(row=0, column=0, padx=6, pady=4, sticky="nsew")

        ctk.CTkLabel(card1, text="WINDOWS BLOATWARE", font=ctk.CTkFont(size=10, weight="bold"), text_color=COLOR_TEXT_SECONDARY).pack(pady=(12, 2))
        self.home_bloat_stat = ctk.CTkLabel(card1, text="Scanning...", font=ctk.CTkFont(size=20, weight="bold"), text_color=COLOR_ACCENT_EMERALD)
        self.home_bloat_stat.pack(pady=2)

        self.home_debloat_btn = ctk.CTkButton(
            card1,
            text="🚀 1-Click Delete All Bloat",
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color="#059669",
            hover_color="#047857",
            height=32,
            corner_radius=8,
            command=self._purge_all_bloat_flow,
        )
        self.home_debloat_btn.pack(pady=(6, 14), padx=14, fill="x")

        # Card 2: Space & Cache Purge
        card2 = ctk.CTkFrame(stats_frame, fg_color=COLOR_CARD, border_color=COLOR_CARD_BORDER, border_width=1, corner_radius=12)
        card2.grid(row=0, column=1, padx=6, pady=4, sticky="nsew")

        ctk.CTkLabel(card2, text="RECOVERABLE JUNK", font=ctk.CTkFont(size=10, weight="bold"), text_color=COLOR_TEXT_SECONDARY).pack(pady=(12, 2))
        self.home_cache_stat = ctk.CTkLabel(card2, text="2+ GB Caches", font=ctk.CTkFont(size=20, weight="bold"), text_color=COLOR_ACCENT_BLUE)
        self.home_cache_stat.pack(pady=2)

        cache_btn = ctk.CTkButton(
            card2,
            text="🧹 Sweep System Caches",
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            text_color=COLOR_TEXT_PRIMARY,
            height=32,
            corner_radius=8,
            command=lambda: self.switch_tab("cache"),
        )
        cache_btn.pack(pady=(6, 14), padx=14, fill="x")

        # Card 3: Startup Acceleration
        card3 = ctk.CTkFrame(stats_frame, fg_color=COLOR_CARD, border_color=COLOR_CARD_BORDER, border_width=1, corner_radius=12)
        card3.grid(row=0, column=2, padx=6, pady=4, sticky="nsew")

        ctk.CTkLabel(card3, text="STARTUP APPS", font=ctk.CTkFont(size=10, weight="bold"), text_color=COLOR_TEXT_SECONDARY).pack(pady=(12, 2))
        self.home_startup_stat = ctk.CTkLabel(card3, text="Startup Tasks", font=ctk.CTkFont(size=20, weight="bold"), text_color="#f59e0b")
        self.home_startup_stat.pack(pady=2)

        startup_btn = ctk.CTkButton(
            card3,
            text="⚡ Speed Up Boot",
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            text_color=COLOR_TEXT_PRIMARY,
            height=32,
            corner_radius=8,
            command=lambda: self.switch_tab("startup"),
        )
        startup_btn.pack(pady=(6, 14), padx=14, fill="x")

        # ── 2. Primary Action Cards ─────────────────────────────────────────
        actions = [
            (
                "📦  Apps & Deep Uninstaller",
                "Browse, search, sort, and batch-uninstall all Win32 desktop and Microsoft Store applications.",
                lambda: self.switch_tab("uninstaller"),
            ),
            (
                "🧹  Scrub Leftover Junk & Registry Keys",
                "Hunt down orphaned folders, dead AppData remnants, and stale registry keys with automatic .reg backup.",
                lambda: self.switch_tab("scrubber"),
            ),
            (
                "⚡  God-Mode Force-Delete (File & Folder Shredder)",
                "Kill stubborn locks, strip NTFS restrictions, and force-delete files (quarantined to Purge Bin first).",
                self._home_force_delete,
            ),
        ]

        for btn_text, desc, cmd in actions:
            card = ctk.CTkFrame(frame, fg_color=COLOR_CARD, border_color=COLOR_CARD_BORDER, border_width=1, corner_radius=10)
            card.pack(fill="x", padx=20, pady=6)
            card.grid_columnconfigure(0, weight=1)

            btn = ctk.CTkButton(
                card,
                text=btn_text,
                font=ctk.CTkFont(size=16, weight="bold"),
                height=48,
                fg_color=COLOR_SIDEBAR,
                hover_color=COLOR_CARD_BORDER,
                anchor="w",
                command=cmd,
            )
            btn.grid(row=0, column=0, padx=14, pady=(10, 2), sticky="ew")

            d_lbl = ctk.CTkLabel(
                card,
                text=desc,
                font=ctk.CTkFont(size=11),
                text_color=COLOR_TEXT_SECONDARY,
                anchor="w",
                justify="left",
            )
            d_lbl.grid(row=1, column=0, padx=18, pady=(0, 10), sticky="w")

        return frame

    def _home_force_delete(self):
        """One-click flow: jump to the force-delete view and open the file picker."""
        self.switch_tab("shredder")
        self._pick_file_to_shred()

    # =========================================================================
    # TAB 1: DEEP UNINSTALLER
    # =========================================================================
    def _create_uninstaller_view(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self.content_container, fg_color="transparent")
        frame.grid_rowconfigure(2, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        # Top Bar: Search and Filters
        top_bar = ctk.CTkFrame(frame, fg_color=COLOR_CARD, corner_radius=10)
        top_bar.grid(row=0, column=0, sticky="ew", pady=(0, 10), padx=2, ipady=6)
        top_bar.grid_columnconfigure(0, weight=1)

        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", self._on_search_typed)

        self.search_input = ctk.CTkEntry(
            top_bar,
            placeholder_text="🔍 Search installed applications or publishers...",
            textvariable=self.search_var,
            height=38,
            fg_color="#0e0e14",
            border_color=COLOR_CARD_BORDER,
        )
        self.search_input.grid(row=0, column=0, padx=12, pady=8, sticky="ew")

        # Filter Pills
        filters_bar = ctk.CTkFrame(top_bar, fg_color="transparent")
        filters_bar.grid(row=0, column=1, padx=10, sticky="e")

        self.filter_state = "All"
        self.filter_buttons = {}
        for f_name in ["All", "Win32 Desktop", "Windows Store", "Large (>500MB)", "Bloat / PUPs"]:
            b = ctk.CTkButton(
                filters_bar,
                text=f_name,
                font=ctk.CTkFont(size=11),
                height=30,
                fg_color=COLOR_ACCENT_CRIMSON if f_name == "All" else COLOR_SIDEBAR,
                hover_color=COLOR_CARD_BORDER,
                command=lambda fn=f_name: self._set_program_filter(fn),
            )
            b.pack(side="left", padx=4)
            self.filter_buttons[f_name] = b

        # Action Buttons Header
        actions_bar = ctk.CTkFrame(frame, fg_color="transparent")
        actions_bar.grid(row=1, column=0, sticky="ew", pady=(0, 8))

        # ⚡ 1-Click Delete All Bloat Button (Prominent)
        self.purge_all_bloat_btn = ctk.CTkButton(
            actions_bar,
            text="⚡ Delete All Bloat",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color="#059669",
            hover_color="#047857",
            text_color="#ffffff",
            command=self._purge_all_bloat_flow,
        )
        self.purge_all_bloat_btn.pack(side="left", padx=(2, 6))

        self.select_all_btn = ctk.CTkButton(
            actions_bar,
            text="Select All",
            font=ctk.CTkFont(size=12),
            height=32,
            width=85,
            fg_color=COLOR_CARD,
            hover_color=COLOR_CARD_BORDER,
            command=self._toggle_select_all,
        )
        self.select_all_btn.pack(side="left", padx=2)

        # Toggle to show hidden/system components (makes sure EVERYTHING appears)
        self.show_system_var = ctk.BooleanVar(value=False)
        self.show_system_chk = ctk.CTkCheckBox(
            actions_bar,
            text="Show System & Hidden Apps",
            variable=self.show_system_var,
            font=ctk.CTkFont(size=11),
            fg_color=COLOR_ACCENT_BLUE,
            command=self.refresh_programs,
        )
        self.show_system_chk.pack(side="left", padx=6)

        self.status_count_label = ctk.CTkLabel(
            actions_bar,
            text="Loading programs...",
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY,
        )
        self.status_count_label.pack(side="left", padx=6)

        # Action Buttons - Simple, plain English
        self.export_report_btn = ctk.CTkButton(
            actions_bar,
            text="📄 Audit Report",
            font=ctk.CTkFont(size=11),
            height=32,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._export_apps_safety_report,
        )
        self.export_report_btn.pack(side="right", padx=3)

        self.silent_uninstall_btn = ctk.CTkButton(
            actions_bar,
            text="🔥 Permanently Delete & Wipe",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color="#991b1b",
            hover_color="#7f1d1d",
            command=lambda: self._trigger_batch_uninstall(silent=True),
        )
        self.silent_uninstall_btn.pack(side="right", padx=4)

        self.uninstall_btn = ctk.CTkButton(
            actions_bar,
            text="🗑️ Standard Uninstall",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color=COLOR_ACCENT_CRIMSON,
            hover_color=COLOR_ACCENT_CRIMSON_HOVER,
            command=lambda: self._trigger_batch_uninstall(silent=False),
        )
        self.uninstall_btn.pack(side="right", padx=4)

        # Table Container
        self.prog_scroll_frame = ctk.CTkScrollableFrame(
            frame,
            fg_color=COLOR_CARD,
            border_color=COLOR_CARD_BORDER,
            border_width=1,
            corner_radius=10,
        )
        self.prog_scroll_frame.grid(row=2, column=0, sticky="nsew", padx=2)
        self.prog_scroll_frame.grid_columnconfigure(1, weight=3) # Name
        self.prog_scroll_frame.grid_columnconfigure(2, weight=2) # Publisher
        self.prog_scroll_frame.grid_columnconfigure(3, weight=1) # Size
        self.prog_scroll_frame.grid_columnconfigure(4, weight=1) # Source

        return frame

    def refresh_programs(self):
        show_sys = getattr(self, "show_system_var", None)
        show_sys_val = show_sys.get() if show_sys else False
        self.status_count_label.configure(text="Scanning Registry & UWP Packages...")
        def _task():
            progs = get_installed_programs(include_uwp=True, show_system_components=show_sys_val)
            self.all_programs = progs
            self.after(0, lambda: self._apply_program_list())
        threading.Thread(target=_task, daemon=True).start()

    def _set_program_filter(self, filter_name: str):
        self.filter_state = filter_name
        for name, btn in self.filter_buttons.items():
            btn.configure(fg_color=COLOR_ACCENT_CRIMSON if name == filter_name else COLOR_SIDEBAR)
        self._filter_programs()

    def _on_search_typed(self, *args):
        """Debounce search-as-you-type so the table rebuilds once per pause."""
        if self._search_after_id:
            try:
                self.after_cancel(self._search_after_id)
            except Exception:
                pass
        self._search_after_id = self.after(250, self._filter_programs)

    def _filter_programs(self, *args):
        query = self.search_var.get().lower().strip()
        filtered = []

        for p in self.all_programs:
            name_match = query in p["name"].lower() or query in p["publisher"].lower()
            if not name_match:
                continue

            if self.filter_state == "Win32 Desktop" and p.get("is_uwp"):
                continue
            elif self.filter_state == "Windows Store" and not p.get("is_uwp"):
                continue
            elif self.filter_state == "Large (>500MB)" and p.get("size_bytes", 0) < 500 * 1024 * 1024:
                continue
            elif self.filter_state == "Bloat / PUPs" and p.get("safety_tier") not in ("SAFE_BLOAT", "CRAPWARE"):
                continue

            filtered.append(p)

        self.filtered_programs = filtered
        self._render_program_table()

    def _apply_program_list(self):
        self.filtered_programs = list(self.all_programs)
        self._sort_current_programs()
        self._render_program_table()

        # Update live Bloatware badges
        bloat_count = sum(1 for p in self.all_programs if p.get("safety_tier") in ("SAFE_BLOAT", "CRAPWARE"))
        if hasattr(self, "purge_all_bloat_btn"):
            self.purge_all_bloat_btn.configure(text=f"⚡ Delete All Bloat ({bloat_count})")
        if hasattr(self, "home_bloat_stat"):
            self.home_bloat_stat.configure(text=f"{bloat_count} Bloat Items")

        self.log_message(f"Detected {len(self.all_programs)} installed Win32 & UWP applications ({bloat_count} safe bloat).")

    def _sort_current_programs(self):
        col = self.sort_column
        def key_func(p):
            val = p.get(col, "")
            if isinstance(val, (int, float)):
                return val
            return str(val).lower()
        self.filtered_programs.sort(key=key_func, reverse=self.sort_descending)

    def _sort_by_column(self, col_key: str):
        if self.sort_column == col_key:
            self.sort_descending = not self.sort_descending
        else:
            self.sort_column = col_key
            self.sort_descending = False
        self._sort_current_programs()
        self._render_program_table()

    def _render_program_table(self):
        # Cancel any active asynchronous chunk-rendering stream
        if self._render_batch_job:
            try:
                self.after_cancel(self._render_batch_job)
            except Exception:
                pass
            self._render_batch_job = None

        # Clear existing items
        for widget in self.prog_scroll_frame.winfo_children():
            widget.destroy()

        self.prog_checkbox_vars.clear()
        self.status_count_label.configure(text=f"Showing {len(self.filtered_programs)} apps")

        # Table Header with Interactive Sort Buttons
        headers = [
            ("", 0, None),
            ("Application Name", 1, "name"),
            ("Publisher", 2, "publisher"),
            ("Estimated Size", 3, "size_bytes"),
            ("Type", 4, "source"),
            ("Safety Status", 5, "safety_tier"),
        ]
        for text, col, sort_key in headers:
            if sort_key:
                indicator = ""
                if self.sort_column == sort_key:
                    indicator = "  ▼" if self.sort_descending else "  ▲"
                h_btn = ctk.CTkButton(
                    self.prog_scroll_frame,
                    text=f"{text}{indicator}",
                    font=ctk.CTkFont(size=11, weight="bold"),
                    text_color=COLOR_ACCENT_CRIMSON if self.sort_column == sort_key else COLOR_TEXT_SECONDARY,
                    fg_color="transparent",
                    hover_color=COLOR_SIDEBAR,
                    anchor="w",
                    height=26,
                    command=lambda k=sort_key: self._sort_by_column(k),
                )
                h_btn.grid(row=0, column=col, padx=4, pady=(4, 6), sticky="w")
            else:
                h_lbl = ctk.CTkLabel(
                    self.prog_scroll_frame,
                    text=text,
                    font=ctk.CTkFont(size=11, weight="bold"),
                    text_color=COLOR_TEXT_SECONDARY,
                )
                h_lbl.grid(row=0, column=col, padx=8, pady=(4, 6), sticky="w")

        # Generator for chunked row rendering (ultra-smooth, 0 lag!)
        def row_stream():
            for idx, prog in enumerate(self.filtered_programs, start=1):
                yield idx, prog

        self._render_gen = row_stream()
        self._render_next_chunk(chunk_size=35)

    def _render_next_chunk(self, chunk_size: int = 35):
        if not self._render_gen:
            return

        rendered_in_chunk = 0
        try:
            while rendered_in_chunk < chunk_size:
                idx, prog = next(self._render_gen)
                rendered_in_chunk += 1
                row_bg = COLOR_SIDEBAR if idx % 2 == 0 else "transparent"
                row_frame = ctk.CTkFrame(self.prog_scroll_frame, fg_color=row_bg, corner_radius=4, height=36)
                row_frame.grid(row=idx, column=0, columnspan=6, sticky="ew", pady=1)
                row_frame.grid_columnconfigure(1, weight=3)
                row_frame.grid_columnconfigure(2, weight=2)
                row_frame.grid_columnconfigure(3, weight=1)
                row_frame.grid_columnconfigure(4, weight=1)
                row_frame.grid_columnconfigure(5, weight=2)

                var = ctk.BooleanVar(value=False)
                self.prog_checkbox_vars[idx - 1] = var

                chk = ctk.CTkCheckBox(row_frame, text="", variable=var, width=24, checkmark_color="#ffffff", fg_color=COLOR_ACCENT_CRIMSON)
                chk.grid(row=0, column=0, padx=(10, 4), pady=4, sticky="w")

                name_lbl = ctk.CTkLabel(
                    row_frame,
                    text=prog["name"][:50],
                    font=ctk.CTkFont(size=12, weight="bold"),
                    text_color=COLOR_TEXT_PRIMARY,
                )
                name_lbl.grid(row=0, column=1, padx=6, pady=4, sticky="w")

                pub_lbl = ctk.CTkLabel(
                    row_frame,
                    text=prog["publisher"][:30],
                    font=ctk.CTkFont(size=11),
                    text_color=COLOR_TEXT_SECONDARY,
                )
                pub_lbl.grid(row=0, column=2, padx=6, pady=4, sticky="w")

                size_str = format_bytes(prog["size_bytes"]) if prog["size_bytes"] > 0 else "—"
                size_lbl = ctk.CTkLabel(
                    row_frame,
                    text=size_str,
                    font=ctk.CTkFont(size=11),
                    text_color=COLOR_ACCENT_EMERALD if prog["size_bytes"] > 0 else COLOR_TEXT_SECONDARY,
                )
                size_lbl.grid(row=0, column=3, padx=6, pady=4, sticky="w")

                type_color = COLOR_ACCENT_BLUE if prog.get("is_uwp") else COLOR_TEXT_SECONDARY
                type_lbl = ctk.CTkLabel(
                    row_frame,
                    text=prog.get("source", "Win32"),
                    font=ctk.CTkFont(size=10, weight="bold"),
                    text_color=type_color,
                )
                type_lbl.grid(row=0, column=4, padx=6, pady=4, sticky="w")

                # Safety Assessment Pill
                s_tier = prog.get("safety_tier", "USER_APP")
                if s_tier == "CRITICAL_SYSTEM":
                    badge_text = "🛡️ KEEP (System/Driver)"
                    badge_color = "#f43f5e" # Rose red
                elif s_tier == "CRAPWARE":
                    badge_text = "🚨 REMOVE (Bloat/PUP)"
                    badge_color = "#a855f7" # Purple
                elif s_tier == "SAFE_BLOAT":
                    badge_text = "✨ SAFE TO REMOVE (Bloat)"
                    badge_color = "#10b981" # Emerald
                else:
                    badge_text = "⚠️ SAFE IF UNUSED (User App)"
                    badge_color = "#f59e0b" # Amber

                safe_lbl = ctk.CTkLabel(
                    row_frame,
                    text=badge_text,
                    font=ctk.CTkFont(size=10, weight="bold"),
                    text_color=badge_color,
                )
                safe_lbl.grid(row=0, column=5, padx=8, pady=4, sticky="w")

                # Right-Click Context Menu Bindings on row widgets
                for w in (row_frame, name_lbl, pub_lbl, size_lbl, type_lbl, safe_lbl):
                    w.bind("<Button-3>", lambda e, p=prog: self._show_app_context_menu(e, p))

        except StopIteration:
            self._render_gen = None
            return

        # Schedule next chunk with small pause so UI remains ultra-responsive
        self._render_batch_job = self.after(3, lambda: self._render_next_chunk(chunk_size))

    def _show_app_context_menu(self, event, prog: Dict[str, Any]):
        menu = tk.Menu(
            self,
            tearoff=0,
            bg=COLOR_CARD,
            fg=COLOR_TEXT_PRIMARY,
            activebackground=COLOR_ACCENT_CRIMSON,
            activeforeground="#ffffff",
            bd=1,
            relief="solid",
        )
        menu.add_command(label=f"🗑️ Standard Uninstall: {prog['name'][:20]}", command=lambda: self._single_uninstall(prog, silent=False))
        menu.add_command(label="🔥 Permanently Delete & Wipe (Skip Wizard)", command=lambda: self._single_uninstall(prog, silent=True))
        menu.add_separator()
        menu.add_command(label="🧹 Deep Scrub Remnants & Leftovers", command=lambda: self._open_scrubber_for_app(prog["name"], prog.get("publisher", "")))

        install_loc = prog.get("install_location")
        if install_loc and os.path.exists(install_loc):
            menu.add_command(label="📁 Open Install Folder", command=lambda: os.startfile(install_loc))

        reg_key = prog.get("registry_key")
        if reg_key:
            menu.add_command(label="📋 Copy Registry Key", command=lambda: self._copy_to_clipboard(reg_key))

        menu.add_command(
            label="🌐 Search on Web",
            command=lambda: webbrowser.open(f"https://www.google.com/search?q={urllib.parse.quote(prog['name'])}")
        )
        menu.post(event.x_root, event.y_root)

    def _copy_to_clipboard(self, text: str):
        self.clipboard_clear()
        self.clipboard_append(text)
        self.log_message(f"Copied to clipboard: {text}")

    def _single_uninstall(self, prog: Dict[str, Any], silent: bool = False):
        action_word = "permanently delete and wipe" if silent else "uninstall"
        confirm_msg = (
            f"Are you sure you want to {action_word} '{prog['name']}'?\n\n"
            f"VoidPurge will automatically remove the app, terminate its active processes, "
            f"and search for leftover remnant files and registry keys."
        )
        if not messagebox.askyesno("Confirm Action", confirm_msg):
            return

        def _task():
            self.log_message(f"Initiating {'permanent wipe' if silent else 'standard uninstall'}: {prog['name']}")
            success, msg = execute_uninstall(prog, silent=silent)
            self.log_message(f"Status [{prog['name']}]: {msg}")
            self.after(0, self.refresh_programs)

        threading.Thread(target=_task, daemon=True).start()


    def _purge_all_bloat_flow(self):
        """1-Click debloater flow: prompts user to review and permanently delete all detected bloat packages."""
        bloat_items = [p for p in self.all_programs if p.get("safety_tier") in ("SAFE_BLOAT", "CRAPWARE")]
        if not bloat_items:
            messagebox.showinfo(
                "VoidPurge Debloat",
                "Your system is clean! No preloaded bloatware or crapware packages were detected on this PC.",
            )
            return

        sample_lines = "\n".join([f"  • {p['name']}" for p in bloat_items[:8]])
        extra = len(bloat_items) - 8
        extra_txt = f"\n  ...and {extra} more packages" if extra > 0 else ""

        msg = (
            f"⚡ 1-CLICK WINDOWS DEBLOAT\n\n"
            f"VoidPurge identified {len(bloat_items)} preloaded bloatware & crapware packages:\n\n"
            f"{sample_lines}{extra_txt}\n\n"
            f"Safety Guarantee:\n"
            f"  ✔ Windows drivers, Steam/games, and personal files will NOT be touched.\n"
            f"  ✔ Registry modifications are backed up automatically to .reg files.\n\n"
            f"Proceed to permanently wipe all {len(bloat_items)} bloatware packages?"
        )
        if not messagebox.askyesno("Confirm 1-Click Debloat", msg):
            return

        self.switch_tab("uninstaller")

        def _worker():
            total = len(bloat_items)
            self.log_message(f"══════════ STARTING 1-CLICK DEBLOAT ({total} PACKAGES) ══════════")
            success_count = 0
            protected_count = 0
            for i, prog in enumerate(bloat_items, start=1):
                self.log_message(f"[Debloat {i}/{total}] Permanently wiping: {prog['name']}")
                success, res_msg = execute_uninstall(prog, silent=True)
                self.log_message(f"  → Status: {res_msg}")
                if success:
                    success_count += 1
                else:
                    protected_count += 1

            self.log_message(f"══════════ 1-CLICK DEBLOAT FINISHED ({success_count} purged, {protected_count} protected) ══════════")
            self.after(0, self.refresh_programs)
            summary = f"Debloat Operation Completed!\n\n• Successfully purged: {success_count} bloatware package(s)"
            if protected_count > 0:
                summary += f"\n• Windows Protected: {protected_count} package(s) (vital system dependencies kept safe)"
            self.after(0, lambda s=summary: messagebox.showinfo("Debloat Complete", s))

        threading.Thread(target=_worker, daemon=True).start()

    def _toggle_select_all(self):
        if not self.prog_checkbox_vars:
            return
        current_state = all(var.get() for var in self.prog_checkbox_vars.values())
        new_state = not current_state
        for var in self.prog_checkbox_vars.values():
            var.set(new_state)
        self.select_all_btn.configure(text="Deselect All" if new_state else "Select All")

    def _trigger_batch_uninstall(self, silent: bool = False):
        selected_progs = [
            self.filtered_programs[idx]
            for idx, var in self.prog_checkbox_vars.items()
            if var.get()
        ]

        if not selected_progs:
            messagebox.showinfo("VoidPurge", "Please select at least one application to uninstall.")
            return

        action_title = "Permanently Delete & Wipe" if silent else "Uninstall Selected"
        confirm_msg = (
            f"Are you sure you want to {action_title.lower()} {len(selected_progs)} application(s)?\n\n"
            + "\n".join([f"• {p['name']}" for p in selected_progs[:6]])
            + (f"\n...and {len(selected_progs) - 6} more" if len(selected_progs) > 6 else "")
            + "\n\nVoidPurge will remove these applications and sweep orphaned leftovers automatically."
        )
        if not messagebox.askyesno(f"Confirm {action_title}", confirm_msg):
            return

        def _worker():
            total = len(selected_progs)
            success_count = 0
            for i, prog in enumerate(selected_progs, start=1):
                self.log_message(f"[{i}/{total}] Initiating uninstallation: {prog['name']}")
                success, msg = execute_uninstall(prog, silent=silent)
                self.log_message(f"[{i}/{total}] Status [{prog['name']}]: {msg}")
                if success:
                    success_count += 1

            self.log_message(f"Batch uninstallation completed ({success_count} of {total} removed).")
            self.after(0, self.refresh_programs)

        threading.Thread(target=_worker, daemon=True).start()

    def _force_scrub_broken_selected(self):
        selected_progs = [
            self.filtered_programs[idx]
            for idx, var in self.prog_checkbox_vars.items()
            if var.get()
        ]
        if not selected_progs:
            messagebox.showinfo("VoidPurge", "Select a broken application to scrub.")
            return
        first = selected_progs[0]
        self._open_scrubber_for_app(first["name"], first.get("publisher", ""))

    def _export_apps_safety_report(self):
        """Export installed programs list with safety recommendations to an interactive HTML report and CSV."""
        if not self.all_programs:
            messagebox.showinfo("VoidPurge", "Program list is still loading or empty.")
            return

        out_path = filedialog.asksaveasfilename(
            defaultextension=".html",
            filetypes=[("Interactive HTML Report", "*.html"), ("CSV Spreadsheet", "*.csv")],
            initialfile="VoidPurge_Installed_Apps_Audit.html",
            title="Save Apps Safety Audit Report",
        )
        if not out_path:
            return

        try:
            if out_path.lower().endswith(".csv"):
                import csv
                with open(out_path, mode="w", newline="", encoding="utf-8-sig") as f:
                    writer = csv.writer(f)
                    writer.writerow(["App Name", "Publisher", "Estimated Size", "Type", "Safety Tier", "Recommendation / Notes", "Install Date"])
                    for p in self.all_programs:
                        writer.writerow([
                            p["name"],
                            p["publisher"],
                            format_bytes(p["size_bytes"]) if p["size_bytes"] > 0 else "N/A",
                            p.get("source", "Win32"),
                            p.get("safety_tier", "USER_APP"),
                            p.get("safety_desc", ""),
                            p.get("install_date", ""),
                        ])
            else:
                # Generate clean Cyber Dark HTML Report
                rows_html = []
                for p in self.all_programs:
                    tier = p.get("safety_tier", "USER_APP")
                    if tier == "CRITICAL_SYSTEM":
                        badge = '<span style="background:#4c0519; color:#fda4af; padding:4px 8px; border-radius:4px; font-weight:bold;">🛡️ DO NOT DELETE (System/Driver)</span>'
                    elif tier == "SAFE_BLOAT":
                        badge = '<span style="background:#064e3b; color:#6ee7b7; padding:4px 8px; border-radius:4px; font-weight:bold;">✨ SAFE TO REMOVE (Bloatware)</span>'
                    else:
                        badge = '<span style="background:#451a03; color:#fcd34d; padding:4px 8px; border-radius:4px; font-weight:bold;">⚠️ SAFE IF UNUSED (User App)</span>'

                    size_str = format_bytes(p["size_bytes"]) if p["size_bytes"] > 0 else "—"
                    rows_html.append(f"""
                    <tr>
                        <td style="font-weight:600; color:#f3f4f6;">{p['name']}</td>
                        <td style="color:#9ca3af;">{p['publisher']}</td>
                        <td style="color:#10b981;">{size_str}</td>
                        <td style="color:#38bdf8;">{p.get('source', 'Win32')}</td>
                        <td>{badge}</td>
                        <td style="color:#d1d5db; font-size:12px;">{p.get('safety_desc', '')}</td>
                    </tr>
                    """)

                html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>VoidPurge - Windows Installed Apps Safety Audit</title>
<style>
  body {{ background-color: #0b0b0e; color: #e5e7eb; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; margin: 0; padding: 24px; }}
  .header {{ border-bottom: 2px solid #e11d48; padding-bottom: 16px; margin-bottom: 24px; }}
  h1 {{ color: #e11d48; margin: 0 0 6px 0; font-size: 26px; }}
  p {{ color: #9ca3af; margin: 0; font-size: 14px; }}
  .stats {{ display: flex; gap: 16px; margin-top: 16px; }}
  .card {{ background: #16161d; border: 1px solid #23232e; padding: 12px 18px; border-radius: 8px; min-width: 140px; }}
  .card-val {{ font-size: 22px; font-weight: bold; color: #10b981; }}
  .card-lbl {{ font-size: 11px; color: #9ca3af; text-transform: uppercase; }}
  table {{ width: 100%; border-collapse: collapse; margin-top: 24px; background: #121217; border-radius: 8px; overflow: hidden; }}
  th, td {{ padding: 12px 16px; text-align: left; border-bottom: 1px solid #1e1e28; font-size: 13px; }}
  th {{ background: #16161d; color: #9ca3af; font-weight: 600; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; }}
  tr:hover {{ background: #181822; }}
</style>
</head>
<body>
  <div class="header">
    <h1>⚡ VOIDPURGE - Application Safety & Removal Audit</h1>
    <p>Audit generated automatically on Windows. Inspect which applications and runtimes are safe to remove.</p>
    <div class="stats">
      <div class="card"><div class="card-val">{len(self.all_programs)}</div><div class="card-lbl">Total Applications</div></div>
      <div class="card"><div class="card-val">{sum(1 for p in self.all_programs if p.get('safety_tier') == 'SAFE_BLOAT')}</div><div class="card-lbl">Safe Bloatware</div></div>
      <div class="card"><div class="card-val">{sum(1 for p in self.all_programs if p.get('safety_tier') == 'USER_APP')}</div><div class="card-lbl">User Applications</div></div>
      <div class="card"><div class="card-val">{sum(1 for p in self.all_programs if p.get('safety_tier') == 'CRITICAL_SYSTEM')}</div><div class="card-lbl">Core Runtimes (Keep)</div></div>
    </div>
  </div>
  <table>
    <thead>
      <tr>
        <th>Application Name</th>
        <th>Publisher</th>
        <th>Size</th>
        <th>Type</th>
        <th>Safety Assessment</th>
        <th>Guidance / Reason</th>
      </tr>
    </thead>
    <tbody>
      {''.join(rows_html)}
    </tbody>
  </table>
</body>
</html>"""
                with open(out_path, mode="w", encoding="utf-8") as f:
                    f.write(html_content)

            self.log_message(f"Saved safety audit report: {out_path}")
            if messagebox.askyesno("Report Exported", f"Successfully exported apps safety audit report to:\n{out_path}\n\nWould you like to open it now?"):
                os.startfile(out_path)
        except Exception as e:
            messagebox.showerror("Export Error", f"Failed to export report: {e}")

    # =========================================================================
    # TAB 2: LEFTOVER & ORPHAN SCRUBBER
    # =========================================================================
    def _create_scrubber_view(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self.content_container, fg_color="transparent")
        frame.grid_rowconfigure(2, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        # Scrubber Header Bar
        hdr = ctk.CTkFrame(frame, fg_color=COLOR_CARD, corner_radius=10)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 10), padx=2, ipady=6)
        hdr.grid_columnconfigure(0, weight=1)

        self.scrub_input_var = ctk.StringVar()
        self.scrub_entry = ctk.CTkEntry(
            hdr,
            placeholder_text="Enter Program Name or Publisher to hunt for orphaned remnants...",
            textvariable=self.scrub_input_var,
            height=38,
            fg_color="#0e0e14",
            border_color=COLOR_CARD_BORDER,
        )
        self.scrub_entry.grid(row=0, column=0, padx=12, pady=8, sticky="ew")

        scan_btn = ctk.CTkButton(
            hdr,
            text="🔍 Deep Scan Leftovers",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=38,
            fg_color=COLOR_ACCENT_CRIMSON,
            hover_color=COLOR_ACCENT_CRIMSON_HOVER,
            command=self._start_leftover_scan,
        )
        scan_btn.grid(row=0, column=1, padx=(0, 12), pady=8)

        # Action Bar
        act_bar = ctk.CTkFrame(frame, fg_color="transparent")
        act_bar.grid(row=1, column=0, sticky="ew", pady=(0, 8))

        self.scrub_recycle_var = ctk.BooleanVar(value=True)
        self.scrub_recycle_chk = ctk.CTkCheckBox(
            act_bar,
            text="Send files to Recycle Bin (Dry-Run / Safe)",
            variable=self.scrub_recycle_var,
            fg_color=COLOR_ACCENT_EMERALD,
        )
        self.scrub_recycle_chk.pack(side="left", padx=4)

        self.scrub_force_var = ctk.BooleanVar(value=False)
        self.scrub_force_chk = ctk.CTkCheckBox(
            act_bar,
            text="Force (include low-confidence <40% matches)",
            variable=self.scrub_force_var,
            fg_color=COLOR_ACCENT_CRIMSON,
        )
        self.scrub_force_chk.pack(side="left", padx=4)

        self.scrub_summary_lbl = ctk.CTkLabel(
            act_bar,
            text="No active scan.",
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY,
        )
        self.scrub_summary_lbl.pack(side="left", padx=16)

        self.nuke_btn = ctk.CTkButton(
            act_bar,
            text="🔥 Backup .reg & Nuke Selected",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color=COLOR_ACCENT_CRIMSON,
            hover_color=COLOR_ACCENT_CRIMSON_HOVER,
            command=self._nuke_selected_leftovers,
        )
        self.nuke_btn.pack(side="right", padx=4)

        # Leftovers List
        self.scrub_scroll = ctk.CTkScrollableFrame(
            frame,
            fg_color=COLOR_CARD,
            border_color=COLOR_CARD_BORDER,
            border_width=1,
            corner_radius=10,
        )
        self.scrub_scroll.grid(row=2, column=0, sticky="nsew", padx=2)
        self.scrub_scroll.grid_columnconfigure(1, weight=1)

        return frame

    def _monitor_new_install(self):
        """Revo-style install monitor: snapshot -> user installs -> diff -> exact leftovers."""
        from tkinter import simpledialog
        app_name = simpledialog.askstring(
            "Monitor Install",
            "App name (labels the results):",
            parent=self,
        )
        if not app_name or not app_name.strip():
            return
        app_name = app_name.strip()
        self.log_message(f"Taking pre-install snapshot for '{app_name}'...")
        self.status_count_label.configure(text=f"Snapshotting system before '{app_name}' install...")

        def _task():
            from .monitor import take_snapshot
            before = take_snapshot()
            self.after(0, lambda: self._monitor_snapshot_done(app_name, before))

        threading.Thread(target=_task, daemon=True).start()

    def _monitor_snapshot_done(self, app_name: str, before):
        self.status_count_label.configure(text=f"Showing {len(self.filtered_programs)} apps")
        if not messagebox.askyesno(
            "Monitor Install — Snapshot Taken",
            f"Snapshot taken.\n\nNow install '{app_name}' (run its installer),\n"
            "then click YES.\n\nClick NO to cancel.",
        ):
            self.log_message("Install monitor cancelled by user.")
            return
        self.log_message(f"Diffing system state for '{app_name}'...")

        def _task():
            from .monitor import take_snapshot, diff_snapshots
            after = take_snapshot()
            results = diff_snapshots(before, after)
            self.after(0, lambda: self._monitor_show_results(app_name, results))

        threading.Thread(target=_task, daemon=True).start()

    def _monitor_show_results(self, app_name: str, results):
        files = results.get("files", [])
        regs = results.get("registry", [])
        n = len(files) + len(regs)
        self.scrub_input_var.set(app_name)
        self.current_leftovers = results
        self.switch_tab("scrubber")
        self._render_leftovers()
        self.log_message(f"Install monitor: '{app_name}' created {n} tracked change(s).")
        if n == 0:
            messagebox.showinfo(
                "Monitor Install",
                f"No changes detected for '{app_name}'.\n"
                "The installer may need admin rights, or nothing was installed.",
            )
        else:
            messagebox.showinfo(
                "Monitor Install — Complete",
                f"Tracked {n} change(s) made by '{app_name}'.\n\n"
                "Review the list and Nuke to remove every trace — "
                "this is an exact reversal of the install.",
            )

    def _open_scrubber_for_app(self, app_name: str, publisher: str = ""):
        self.switch_tab("scrubber")
        self.scrub_input_var.set(app_name)
        self._start_leftover_scan(publisher)

    def _start_leftover_scan(self, publisher: str = ""):
        target = self.scrub_input_var.get().strip()
        if not target:
            messagebox.showinfo("VoidPurge", "Please enter an application or publisher name to scan.")
            return

        self.scrub_summary_lbl.configure(text=f"Scanning AppData, ProgramData, and Registry for '{target}'...")
        self.log_message(f"Initiated deep leftover sweep for: '{target}'")

        def _task():
            results = scan_leftovers(target, publisher)
            self.current_leftovers = results
            self.after(0, self._render_leftovers)

        threading.Thread(target=_task, daemon=True).start()

    def _render_leftovers(self):
        for widget in self.scrub_scroll.winfo_children():
            widget.destroy()

        self.scrub_checkbox_vars.clear()
        files = self.current_leftovers.get("files", [])
        regs = self.current_leftovers.get("registry", [])

        def _confidence(item: Dict[str, Any]) -> int:
            try:
                return int(item.get("confidence") or 0)
            except (TypeError, ValueError):
                return 0

        all_items = files + regs
        has_confidence = any("confidence" in item for item in all_items)
        # Highest-confidence matches first
        all_items.sort(key=_confidence, reverse=True)
        self._sorted_leftover_items = all_items

        total_items = len(all_items)
        total_bytes = sum(f.get("size_bytes", 0) for f in files)

        self.scrub_summary_lbl.configure(
            text=f"Found {len(files)} files/folders ({format_bytes(total_bytes)}) and {len(regs)} Registry keys."
        )

        if total_items == 0:
            lbl = ctk.CTkLabel(
                self.scrub_scroll,
                text="No leftover files or registry keys detected. System is clean!",
                font=ctk.CTkFont(size=13),
                text_color=COLOR_ACCENT_EMERALD,
            )
            lbl.pack(pady=40)
            return

        self.scrub_scroll.grid_columnconfigure(1, weight=1)

        for idx, item in enumerate(all_items):
            row = ctk.CTkFrame(self.scrub_scroll, fg_color=COLOR_SIDEBAR, corner_radius=6)
            row.pack(fill="x", pady=2, padx=4)
            row.grid_columnconfigure(1, weight=1)

            conf = _confidence(item)
            # Low-confidence guesses stay unchecked so the user opts in explicitly
            default_checked = (conf >= LOW_CONFIDENCE_THRESHOLD) if has_confidence else True
            var = ctk.BooleanVar(value=default_checked)
            self.scrub_checkbox_vars.append(var)

            chk = ctk.CTkCheckBox(row, text="", variable=var, width=24, fg_color=COLOR_ACCENT_CRIMSON)
            chk.grid(row=0, column=0, padx=(10, 6), pady=8, sticky="w")

            _TAG_LABELS = {
                "registry": "[REGISTRY]",
                "registry_value": "[REG VALUE]",
                "folder": "[FOLDER]",
                "file": "[FILE]",
                "shortcut": "[SHORTCUT]",
                "task": "[TASK]",
                "service": "[SERVICE]",
            }
            tag = _TAG_LABELS.get(item["type"], "[FILE]")
            tag_color = COLOR_ACCENT_BLUE if item["type"] in ("registry", "registry_value") else COLOR_ACCENT_CRIMSON

            info_text = f"{tag} {item['path']}"
            lbl = ctk.CTkLabel(
                row,
                text=info_text,
                font=ctk.CTkFont(size=11),
                text_color=tag_color,
                anchor="w",
            )
            lbl.grid(row=0, column=1, padx=4, sticky="w")

            if has_confidence:
                reasons = item.get("reasons") or []
                reason_txt = str(reasons[0]) if reasons else "match"
                conf_txt = f"{conf} — {reason_txt}"
                conf_color = COLOR_ACCENT_EMERALD if conf >= LOW_CONFIDENCE_THRESHOLD else "#f59e0b"
            else:
                conf_txt, conf_color = "", COLOR_TEXT_SECONDARY

            conf_lbl = ctk.CTkLabel(
                row,
                text=conf_txt,
                font=ctk.CTkFont(size=11, weight="bold"),
                text_color=conf_color,
            )
            conf_lbl.grid(row=0, column=2, padx=8, sticky="e")

            size_lbl = ctk.CTkLabel(
                row,
                text=item["size_formatted"],
                font=ctk.CTkFont(size=11, weight="bold"),
                text_color=COLOR_TEXT_SECONDARY,
            )
            size_lbl.grid(row=0, column=3, padx=12, sticky="e")

    def _nuke_selected_leftovers(self):
        # Use the same sorted order as the rendered list so checkboxes stay aligned
        all_items = self._sorted_leftover_items or (
            self.current_leftovers.get("files", []) + self.current_leftovers.get("registry", [])
        )
        selected = [
            all_items[i]
            for i, var in enumerate(self.scrub_checkbox_vars)
            if var.get()
        ]

        if not selected:
            messagebox.showinfo("VoidPurge", "No items selected to scrub.")
            return

        if not messagebox.askyesno(
            "Confirm Cleanup",
            f"Nuke {len(selected)} selected remnants?\n(Automatic .reg backups will be saved in ./backups/)",
        ):
            return

        use_rb = self.scrub_recycle_var.get()
        force = self.scrub_force_var.get()
        app_hint = self.scrub_input_var.get().strip()

        def _worker():
            self.log_message(f"Starting leftover cleanup for '{app_hint}'. Recycle Bin: {use_rb}")
            del_f, del_r, errs = delete_leftovers(selected, use_recycle_bin=use_rb, app_hint=app_hint, force=force)
            self.log_message(f"Cleaned {del_f} file(s) and {del_r} registry key(s).")
            for e in errs:
                self.log_message(f"Warning: {e}")
            # Verification pass: rescan and prove nothing remains.
            remaining: List[Dict[str, Any]] = []
            if app_hint:
                try:
                    verify = scan_leftovers(app_hint, "")
                    remaining = verify.get("files", []) + verify.get("registry", [])
                    self.current_leftovers = verify
                except Exception as e:
                    self.log_message(f"Verification rescan failed: {e}")
            deleted_total = del_f + del_r
            self.after(0, self._render_leftovers)
            self.after(0, lambda: self._show_wipe_verdict(app_hint, deleted_total, len(remaining)))

        threading.Thread(target=_worker, daemon=True).start()

    def _show_wipe_verdict(self, app_hint: str, deleted: int, remaining: int):
        """Tell the user plainly whether the wipe is 100% complete."""
        if remaining == 0:
            self.log_message(f"Verified: '{app_hint}' is 100% wiped — 0 traces remain.")
            messagebox.showinfo(
                "VoidPurge — Verified ✅",
                f"'{app_hint}' is 100% wiped.\n\n"
                f"{deleted} item(s) deleted, 0 traces remain.",
            )
        else:
            self.log_message(
                f"Verify: '{app_hint}' — {deleted} deleted, {remaining} trace(s) still remain.")
            messagebox.showwarning(
                "VoidPurge — Not fully wiped ⚠️",
                f"'{app_hint}': {deleted} item(s) deleted, "
                f"but {remaining} trace(s) still remain.\n\n"
                "They're listed below — select them and Nuke again, "
                "or re-run with force mode for stubborn items.",
            )

    # =========================================================================
    # TAB 3: GOD-MODE FORCE SHREDDER (LOCKHUNTER ENGINE)
    # =========================================================================
    def _create_shredder_view(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self.content_container, fg_color="transparent")
        frame.grid_rowconfigure(4, weight=1)
        frame.grid_rowconfigure(6, weight=2)
        frame.grid_columnconfigure(0, weight=1)

        # Path Selector Card
        card = ctk.CTkFrame(frame, fg_color=COLOR_CARD, corner_radius=10)
        card.grid(row=0, column=0, sticky="ew", pady=(0, 10), padx=2, ipady=8)
        card.grid_columnconfigure(0, weight=1)

        c_title = ctk.CTkLabel(
            card,
            text="LockHunter Engine - Force File & Folder Shredder",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLOR_TEXT_PRIMARY,
        )
        c_title.grid(row=0, column=0, columnspan=3, padx=14, pady=(6, 10), sticky="w")

        self.shred_path_var = ctk.StringVar()
        self.shred_path_entry = ctk.CTkEntry(
            card,
            placeholder_text="Paste or browse path to stubborn, locked, or 'Access Denied' file/folder...",
            textvariable=self.shred_path_var,
            height=38,
            fg_color="#0e0e14",
            border_color=COLOR_CARD_BORDER,
        )
        self.shred_path_entry.grid(row=1, column=0, padx=(14, 8), pady=4, sticky="ew")

        pick_file_btn = ctk.CTkButton(
            card,
            text="📄 File",
            width=70,
            height=38,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._pick_file_to_shred,
        )
        pick_file_btn.grid(row=1, column=1, padx=4, pady=4)

        pick_dir_btn = ctk.CTkButton(
            card,
            text="📁 Folder",
            width=70,
            height=38,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._pick_dir_to_shred,
        )
        pick_dir_btn.grid(row=1, column=2, padx=(4, 14), pady=4)

        # Deletion Options Card
        opt_card = ctk.CTkFrame(frame, fg_color=COLOR_CARD, corner_radius=10)
        opt_card.grid(row=1, column=0, sticky="ew", pady=(0, 10), padx=2, ipady=8)
        opt_card.grid_columnconfigure(0, weight=1)

        opt_title = ctk.CTkLabel(
            opt_card,
            text="How should it be deleted?",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLOR_TEXT_PRIMARY,
        )
        opt_title.grid(row=0, column=0, padx=14, pady=(6, 4), sticky="w")

        self.shred_mode_var = ctk.StringVar(value="purgebin")
        rb_purge = ctk.CTkRadioButton(
            opt_card,
            text="Move to Purge Bin (undoable) — recommended",
            variable=self.shred_mode_var,
            value="purgebin",
            font=ctk.CTkFont(size=12),
            fg_color=COLOR_ACCENT_EMERALD,
        )
        rb_purge.grid(row=1, column=0, padx=14, pady=2, sticky="w")

        rb_perm = ctk.CTkRadioButton(
            opt_card,
            text="Delete permanently (no undo)",
            variable=self.shred_mode_var,
            value="permanent",
            font=ctk.CTkFont(size=12),
            fg_color=COLOR_ACCENT_CRIMSON,
        )
        rb_perm.grid(row=2, column=0, padx=14, pady=2, sticky="w")

        self.secure_wipe_var = ctk.BooleanVar(value=False)
        self.secure_wipe_chk = ctk.CTkCheckBox(
            opt_card,
            text="Shred securely (overwrite data so it can't be recovered)",
            variable=self.secure_wipe_var,
            font=ctk.CTkFont(size=12),
            fg_color=COLOR_ACCENT_CRIMSON,
            command=self._toggle_secure_wipe_warning,
        )
        self.secure_wipe_chk.grid(row=3, column=0, padx=14, pady=(6, 2), sticky="w")

        self.ssd_warning_lbl = ctk.CTkLabel(
            opt_card,
            text="",
            font=ctk.CTkFont(size=11),
            text_color="#f59e0b",
            wraplength=900,
            justify="left",
        )
        self.ssd_warning_lbl.grid(row=4, column=0, padx=14, pady=(2, 6), sticky="w")

        # Action Buttons
        act_row = ctk.CTkFrame(frame, fg_color="transparent")
        act_row.grid(row=2, column=0, sticky="ew", pady=(0, 10))

        self.force_shred_btn = ctk.CTkButton(
            act_row,
            text="💥 Force Delete",
            font=ctk.CTkFont(size=13, weight="bold"),
            height=36,
            fg_color=COLOR_ACCENT_CRIMSON,
            hover_color=COLOR_ACCENT_CRIMSON_HOVER,
            command=self._execute_force_delete,
        )
        self.force_shred_btn.pack(side="right", padx=4)

        self.scan_locks_btn = ctk.CTkButton(
            act_row,
            text="🔍 Scan Locking Processes",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=36,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._scan_path_locks,
        )
        self.scan_locks_btn.pack(side="right", padx=6)

        # Locks Display Area
        locks_hdr = ctk.CTkLabel(
            frame,
            text="ACTIVE LOCKING PROCESSES / INSPECTION RESULTS",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=COLOR_TEXT_SECONDARY,
        )
        locks_hdr.grid(row=3, column=0, sticky="w", padx=4, pady=(4, 4))

        self.locks_scroll = ctk.CTkScrollableFrame(
            frame,
            fg_color=COLOR_CARD,
            border_color=COLOR_CARD_BORDER,
            border_width=1,
            corner_radius=10,
        )
        self.locks_scroll.grid(row=4, column=0, sticky="nsew", padx=2)
        self.locks_scroll.grid_columnconfigure(0, weight=1)

        # Escalation Ladder Pane
        ladder_hdr = ctk.CTkLabel(
            frame,
            text="ESCALATION LADDER — LIVE STEPS",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=COLOR_TEXT_SECONDARY,
        )
        ladder_hdr.grid(row=5, column=0, sticky="w", padx=4, pady=(4, 4))

        self.ladder_text = ctk.CTkTextbox(
            frame,
            fg_color="#08080a",
            text_color="#fbbf24",
            font=ctk.CTkFont(family="Consolas", size=11),
            border_color=COLOR_CARD_BORDER,
            border_width=1,
            corner_radius=10,
        )
        self.ladder_text.grid(row=6, column=0, sticky="nsew", padx=2, pady=(0, 2))
        self.ladder_text.configure(state="disabled")

        return frame

    def _pick_file_to_shred(self):
        f = filedialog.askopenfilename()
        if f:
            self.shred_path_var.set(f)
            self._scan_path_locks()

    def _pick_dir_to_shred(self):
        d = filedialog.askdirectory()
        if d:
            self.shred_path_var.set(d)
            self._scan_path_locks()

    def _normalize_lock_entries(self, locks) -> List[Dict[str, Any]]:
        """Defensively normalize lock entries from either the basic or detailed scanner."""
        norm = []
        for lock in locks or []:
            try:
                if isinstance(lock, dict):
                    norm.append({
                        "pid": lock.get("pid", "?"),
                        "name": str(lock.get("name") or lock.get("process_name") or "Unknown"),
                        "exe": str(lock.get("exe") or lock.get("path") or ""),
                        "is_protected": bool(lock.get("is_protected", False)),
                        "extra": str(lock.get("detail") or lock.get("handle_type") or ""),
                    })
                else:
                    norm.append({"pid": "?", "name": str(lock), "exe": "", "is_protected": False, "extra": ""})
            except Exception:
                continue
        return norm

    def _scan_path_locks(self):
        target = self.shred_path_var.get().strip()
        if not target:
            messagebox.showinfo("VoidPurge", "Select or paste a target path first.")
            return

        for w in self.locks_scroll.winfo_children():
            w.destroy()

        locks = None
        if HAS_HANDLES:
            try:
                enable_debug_privilege()
                detailed = find_locking_processes_detailed(target)
                norm = self._normalize_lock_entries(detailed)
                # Only trust the detailed result if it came back in a sane shape
                if norm or not detailed:
                    locks = norm
                    self.log_message(f"Detailed handle scan: {len(norm)} lock(s) on '{target}'")
            except Exception as e:
                self.log_message(f"Detailed handle scan unavailable ({e}); using basic scan.")

        if locks is None:
            locks = self._normalize_lock_entries(find_locking_processes(target))

        if not locks:
            lbl = ctk.CTkLabel(
                self.locks_scroll,
                text=f"No active handle locks detected on '{target}'. It can be cleanly deleted.",
                text_color=COLOR_ACCENT_EMERALD,
                font=ctk.CTkFont(size=12),
            )
            lbl.pack(pady=20)
            return

        self.log_message(f"Detected {len(locks)} locking processes on '{target}'")
        for lock in locks:
            row = ctk.CTkFrame(self.locks_scroll, fg_color=COLOR_SIDEBAR, corner_radius=6)
            row.pack(fill="x", pady=2, padx=4)

            p_color = COLOR_ACCENT_CRIMSON if lock["is_protected"] else COLOR_TEXT_PRIMARY
            status = " [PROTECTED SYSTEM PROCESS - CANNOT TERMINATE]" if lock["is_protected"] else ""
            extra = f" [{lock['extra']}]" if lock.get("extra") else ""

            lbl = ctk.CTkLabel(
                row,
                text=f"PID {lock['pid']} - {lock['name']} ({lock['exe']}){extra}{status}",
                font=ctk.CTkFont(size=11),
                text_color=p_color,
            )
            lbl.pack(side="left", padx=10, pady=8)

    def _ladder_log(self, step: str):
        """Append one escalation-ladder step to the visible ladder pane (thread-safe)."""
        def _append():
            self.ladder_text.configure(state="normal")
            self.ladder_text.insert("end", f"{step}\n")
            self.ladder_text.see("end")
            self.ladder_text.configure(state="disabled")
        self.after(0, _append)

    def _toggle_secure_wipe_warning(self):
        if self.secure_wipe_var.get():
            warning = SSD_WARNING if HAS_WIPE else "Secure-wipe engine is not available in this build — files will be deleted without overwriting."
            self.ssd_warning_lbl.configure(text=f"⚠️ {warning}")
        else:
            self.ssd_warning_lbl.configure(text="")

    def _execute_force_delete(self):
        target = self.shred_path_var.get().strip()
        if not target:
            messagebox.showinfo("VoidPurge", "Please provide a file or folder path.")
            return

        mode = self.shred_mode_var.get()
        secure = self.secure_wipe_var.get()

        if mode == "purgebin":
            if HAS_PURGEBIN:
                action_name = "move to the Purge Bin (undoable)"
            else:
                action_name = "send to the Recycle Bin (Purge Bin module missing — fallback)"
        else:
            action_name = "PERMANENTLY DESTROY" + (" with secure overwrite" if secure else "")

        if not messagebox.askyesno(
            "Confirm Force Delete",
            f"Are you sure you want to {action_name}:\n{target}\n\nLocks will be killed and NTFS ACLs stripped.",
        ):
            return

        # Clear the ladder pane for this run
        self.ladder_text.configure(state="normal")
        self.ladder_text.delete("1.0", "end")
        self.ladder_text.configure(state="disabled")

        def _worker():
            if mode == "purgebin":
                self._purgebin_stage_flow(target)
            else:
                self._permanent_delete_flow(target, secure)

        threading.Thread(target=_worker, daemon=True).start()

    def _purgebin_stage_flow(self, target: str):
        self._ladder_log(f"→ Staging for Purge Bin: {target}")
        self.log_message(f"Moving to Purge Bin: {target}")
        if HAS_PURGEBIN:
            try:
                res = purgebin_stage(target)
                if isinstance(res, (tuple, list)) and len(res) >= 2:
                    ok, msg = bool(res[0]), str(res[1])
                else:
                    ok, msg = bool(res), str(res)
            except Exception as e:
                ok, msg = False, f"Purge Bin staging failed: {e}"
            self._ladder_log(f"→ {msg}")
            self.log_message(f"Purge Bin: {msg}")
            if ok:
                self.after(0, lambda: messagebox.showinfo("Purge Bin", msg))
            else:
                self.after(0, lambda: messagebox.showerror("Purge Bin", msg))
            self.after(0, self._refresh_purgebin)
        else:
            # Fallback: old engine, Recycle Bin as the undoable path
            success, msg = force_unlock_and_shred(target, use_recycle_bin=True)
            self._ladder_log(f"→ {msg}")
            self.log_message(msg)
            self.after(0, lambda: messagebox.showinfo("Force Delete Result", msg))
        self.after(0, self._scan_path_locks)

    def _permanent_delete_flow(self, target: str, secure: bool):
        self.log_message(f"Executing force delete on: {target} (secure_wipe={secure})")
        if HAS_LADDER:
            try:
                try:
                    success, steps, message = force_delete_with_ladder(target, use_recycle_bin=False, secure_wipe=secure)
                except TypeError:
                    # Older ladder signature without the secure_wipe flag
                    success, steps, message = force_delete_with_ladder(target, use_recycle_bin=False)
            except Exception as e:
                self._ladder_log(f"→ Ladder engine failed: {e}")
                self.log_message(f"Ladder engine failed: {e}")
                self.after(0, lambda: messagebox.showerror("Force Delete", f"Ladder engine failed: {e}"))
                return
            # Display the ladder steps sequentially as they happen
            for step in steps or []:
                self._ladder_log(str(step))
                time.sleep(0.15)
            self.log_message(message)
            if success:
                self.after(0, lambda: messagebox.showinfo("Force Delete Result", message))
            else:
                self.after(0, lambda: messagebox.showerror("Force Delete Result", message))
        else:
            if secure:
                self._ladder_log("→ Secure wipe requested, but the new engine is unavailable — deleting without overwrite.")
                self.log_message("Secure wipe unavailable in fallback mode; deleting without overwrite.")
            success, msg = force_unlock_and_shred(target, use_recycle_bin=False)
            self._ladder_log(f"→ {msg}")
            self.log_message(msg)
            self.after(0, lambda: messagebox.showinfo("Force Delete Result", msg))
        self.after(0, self._scan_path_locks)

    # =========================================================================
    # TAB 4: SPACE & CACHE PURGE
    # =========================================================================
    def _create_cache_view(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self.content_container, fg_color="transparent")
        frame.grid_rowconfigure(2, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        # Header Info Card
        hdr = ctk.CTkFrame(frame, fg_color=COLOR_CARD, corner_radius=10)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 10), padx=2, ipady=6)
        hdr.grid_columnconfigure(0, weight=1)

        title = ctk.CTkLabel(
            hdr,
            text="Fast Junk & Dev Cache Sweeper",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLOR_TEXT_PRIMARY,
        )
        title.grid(row=0, column=0, padx=14, pady=(6, 2), sticky="w")

        desc = ctk.CTkLabel(
            hdr,
            text="Recover gigabytes from temporary files, shader caches, crash dumps, and dev package managers.",
            font=ctk.CTkFont(size=11),
            text_color=COLOR_TEXT_SECONDARY,
        )
        desc.grid(row=1, column=0, padx=14, pady=(0, 8), sticky="w")

        # Action Buttons
        act_bar = ctk.CTkFrame(frame, fg_color="transparent")
        act_bar.grid(row=1, column=0, sticky="ew", pady=(0, 8))

        self.cache_total_lbl = ctk.CTkLabel(
            act_bar,
            text="Recoverable: 0 B",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLOR_ACCENT_EMERALD,
        )
        self.cache_total_lbl.pack(side="left", padx=4)

        self.purge_selected_btn = ctk.CTkButton(
            act_bar,
            text="🧹 Purge Selected Caches",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color=COLOR_ACCENT_EMERALD,
            hover_color=COLOR_ACCENT_EMERALD_HOVER,
            command=self._purge_selected_caches,
        )
        self.purge_selected_btn.pack(side="right", padx=4)

        self.rescan_cache_btn = ctk.CTkButton(
            act_bar,
            text="🔄 Scan Caches",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._scan_all_caches,
        )
        self.rescan_cache_btn.pack(side="right", padx=6)

        self.flush_dns_btn = ctk.CTkButton(
            act_bar,
            text="🌐 Flush DNS",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color=COLOR_ACCENT_BLUE,
            hover_color=COLOR_ACCENT_BLUE_HOVER,
            command=self._flush_dns,
        )
        self.flush_dns_btn.pack(side="right", padx=4)

        self.clear_logs_btn = ctk.CTkButton(
            act_bar,
            text="📋 Clear Event Logs",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._clear_event_logs,
        )
        self.clear_logs_btn.pack(side="right", padx=4)

        # Cache List
        self.cache_scroll = ctk.CTkScrollableFrame(
            frame,
            fg_color=COLOR_CARD,
            border_color=COLOR_CARD_BORDER,
            border_width=1,
            corner_radius=10,
        )
        self.cache_scroll.grid(row=2, column=0, sticky="nsew", padx=2)
        self.cache_scroll.grid_columnconfigure(1, weight=1)

        # Trigger initial scan
        self.after(500, self._scan_all_caches)
        return frame

    def _scan_all_caches(self):
        self.cache_total_lbl.configure(text="Scanning caches across disk...")
        def _task():
            items = scan_caches()
            self.cache_items = items
            self.after(0, self._render_caches)
        threading.Thread(target=_task, daemon=True).start()

    def _render_caches(self):
        for w in self.cache_scroll.winfo_children():
            w.destroy()

        self.cache_checkbox_vars.clear()
        total_reclaimable = sum(item["size_bytes"] for item in self.cache_items)
        self.cache_total_lbl.configure(text=f"Total Recoverable: {format_bytes(total_reclaimable)}")

        for idx, item in enumerate(self.cache_items):
            row = ctk.CTkFrame(self.cache_scroll, fg_color=COLOR_SIDEBAR, corner_radius=6)
            row.pack(fill="x", pady=3, padx=4)
            row.grid_columnconfigure(1, weight=1)

            var = ctk.BooleanVar(value=item["size_bytes"] > 0)
            self.cache_checkbox_vars.append(var)

            chk = ctk.CTkCheckBox(row, text="", variable=var, width=24, fg_color=COLOR_ACCENT_EMERALD)
            chk.grid(row=0, column=0, rowspan=2, padx=(10, 6), pady=8, sticky="w")

            name_lbl = ctk.CTkLabel(
                row,
                text=f"{item['name']} ({item['category']})",
                font=ctk.CTkFont(size=12, weight="bold"),
                text_color=COLOR_TEXT_PRIMARY,
            )
            name_lbl.grid(row=0, column=1, padx=4, pady=(6, 0), sticky="w")

            desc_lbl = ctk.CTkLabel(
                row,
                text=f"{item['description']} • {item['path']}",
                font=ctk.CTkFont(size=10),
                text_color=COLOR_TEXT_SECONDARY,
            )
            desc_lbl.grid(row=1, column=1, padx=4, pady=(0, 6), sticky="w")

            size_lbl = ctk.CTkLabel(
                row,
                text=f"{item['size_formatted']} ({item['file_count']} files)",
                font=ctk.CTkFont(size=12, weight="bold"),
                text_color=COLOR_ACCENT_EMERALD if item["size_bytes"] > 0 else COLOR_TEXT_SECONDARY,
            )
            size_lbl.grid(row=0, column=2, rowspan=2, padx=14, sticky="e")

    def _purge_selected_caches(self):
        selected = [
            self.cache_items[i]
            for i, var in enumerate(self.cache_checkbox_vars)
            if var.get() and self.cache_items[i]["size_bytes"] > 0
        ]

        if not selected:
            messagebox.showinfo("VoidPurge", "No cache targets with files selected.")
            return

        if not messagebox.askyesno(
            "Confirm Cache Purge",
            f"Purge contents of {len(selected)} selected cache directories?",
        ):
            return

        def _worker():
            total_cleaned = 0
            for item in selected:
                self.log_message(f"Purging cache: {item['name']}")
                reclaimed, count = purge_cache(item["path"], files_only=item.get("files_only"))
                total_cleaned += reclaimed
                self.log_message(f"Cleaned {format_bytes(reclaimed)} ({count} items) from {item['name']}")

            self.log_message(f"Total space recovered: {format_bytes(total_cleaned)}")
            self.after(0, self._scan_all_caches)

        threading.Thread(target=_worker, daemon=True).start()

    # =========================================================================
    # PURGE BIN (undoable deletions)
    # =========================================================================
    def _create_purgebin_view(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self.content_container, fg_color="transparent")
        frame.grid_rowconfigure(2, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        hdr = ctk.CTkFrame(frame, fg_color=COLOR_CARD, corner_radius=10)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 10), padx=2, ipady=6)
        hdr.grid_columnconfigure(0, weight=1)

        title = ctk.CTkLabel(
            hdr,
            text="Purge Bin — undoable deletions",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLOR_TEXT_PRIMARY,
        )
        title.grid(row=0, column=0, padx=14, pady=(6, 2), sticky="w")

        desc = ctk.CTkLabel(
            hdr,
            text="Files and folders moved here can be restored to their original location. Emptying the bin deletes them permanently.",
            font=ctk.CTkFont(size=11),
            text_color=COLOR_TEXT_SECONDARY,
        )
        desc.grid(row=1, column=0, padx=14, pady=(0, 8), sticky="w")

        act_bar = ctk.CTkFrame(frame, fg_color="transparent")
        act_bar.grid(row=1, column=0, sticky="ew", pady=(0, 8))

        self.purgebin_count_lbl = ctk.CTkLabel(
            act_bar,
            text="",
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY,
        )
        self.purgebin_count_lbl.pack(side="left", padx=4)

        self.purgebin_empty_btn = ctk.CTkButton(
            act_bar,
            text="🗑️ Empty Now (permanent)",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color=COLOR_ACCENT_CRIMSON,
            hover_color=COLOR_ACCENT_CRIMSON_HOVER,
            command=self._purgebin_empty,
        )
        self.purgebin_empty_btn.pack(side="right", padx=4)

        self.purgebin_refresh_btn = ctk.CTkButton(
            act_bar,
            text="🔄 Refresh",
            font=ctk.CTkFont(size=12),
            height=32,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._refresh_purgebin,
        )
        self.purgebin_refresh_btn.pack(side="right", padx=6)

        self.purgebin_scroll = ctk.CTkScrollableFrame(
            frame,
            fg_color=COLOR_CARD,
            border_color=COLOR_CARD_BORDER,
            border_width=1,
            corner_radius=10,
        )
        self.purgebin_scroll.grid(row=2, column=0, sticky="nsew", padx=2)
        self.purgebin_scroll.grid_columnconfigure(0, weight=1)

        return frame

    def _purgebin_item_fields(self, item: Dict[str, Any]):
        """Defensively extract (item_id, original_path, size_text, date_text) from a purge-bin item."""
        item_id = item.get("id", item.get("item_id", ""))
        orig = item.get("original_path") or item.get("source_path") or item.get("path") or "?"
        if "size_formatted" in item:
            size_txt = str(item["size_formatted"])
        elif "size_bytes" in item:
            try:
                size_txt = format_bytes(float(item["size_bytes"]))
            except (TypeError, ValueError):
                size_txt = "—"
        elif "size" in item:
            # purgebin module reports raw bytes under "size"
            try:
                size_txt = format_bytes(float(item["size"]))
            except (TypeError, ValueError):
                size_txt = str(item["size"])
        else:
            size_txt = "—"
        date_txt = str(item.get("staged_at") or item.get("date") or item.get("timestamp") or "—")
        return item_id, orig, size_txt, date_txt

    def _refresh_purgebin(self):
        for w in self.purgebin_scroll.winfo_children():
            w.destroy()

        if not HAS_PURGEBIN:
            lbl = ctk.CTkLabel(
                self.purgebin_scroll,
                text="Purge Bin module is not available in this build.",
                font=ctk.CTkFont(size=13),
                text_color=COLOR_TEXT_SECONDARY,
            )
            lbl.pack(pady=40)
            self.purgebin_count_lbl.configure(text="")
            return

        try:
            items = purgebin_list_items() or []
        except Exception as e:
            self.log_message(f"Purge Bin list failed: {e}")
            items = []

        self.purgebin_count_lbl.configure(text=f"{len(items)} item(s) staged")

        if not items:
            lbl = ctk.CTkLabel(
                self.purgebin_scroll,
                text="Purge Bin is empty.\nForce-deleted files land here when you choose 'Move to Purge Bin'.",
                font=ctk.CTkFont(size=13),
                text_color=COLOR_ACCENT_EMERALD,
                justify="center",
            )
            lbl.pack(pady=40)
            return

        for item in items:
            item_id, orig, size_txt, date_txt = self._purgebin_item_fields(item)

            row = ctk.CTkFrame(self.purgebin_scroll, fg_color=COLOR_SIDEBAR, corner_radius=6)
            row.pack(fill="x", pady=2, padx=4)
            row.grid_columnconfigure(0, weight=1)

            info = ctk.CTkLabel(
                row,
                text=f"{orig}\n{size_txt}  •  staged {date_txt}",
                font=ctk.CTkFont(size=11),
                text_color=COLOR_TEXT_PRIMARY,
                anchor="w",
                justify="left",
            )
            info.grid(row=0, column=0, padx=10, pady=8, sticky="w")

            rb = ctk.CTkButton(
                row,
                text="↩ Restore",
                font=ctk.CTkFont(size=11, weight="bold"),
                height=30,
                width=90,
                fg_color=COLOR_ACCENT_EMERALD,
                hover_color=COLOR_ACCENT_EMERALD_HOVER,
                command=lambda i=item_id: self._purgebin_restore(i),
            )
            rb.grid(row=0, column=1, padx=10, pady=8, sticky="e")

    def _purgebin_restore(self, item_id):
        if not item_id:
            messagebox.showinfo("Purge Bin", "Could not identify this item.")
            return

        def _worker():
            try:
                res = purgebin_restore(item_id)
            except Exception as e:
                self.log_message(f"Purge Bin restore failed: {e}")
                self.after(0, lambda: messagebox.showerror("Purge Bin", f"Restore failed: {e}"))
                return
            if isinstance(res, (tuple, list)) and len(res) >= 2:
                ok, msg = bool(res[0]), str(res[1])
            else:
                ok, msg = bool(res), ("Restored." if res else "Restore failed.")
            self.log_message(f"Purge Bin restore: {msg}")
            if ok:
                self.after(0, lambda: messagebox.showinfo("Purge Bin", msg))
            else:
                self.after(0, lambda: messagebox.showerror("Purge Bin", msg))
            self.after(0, self._refresh_purgebin)

        threading.Thread(target=_worker, daemon=True).start()

    def _purgebin_empty(self):
        if not HAS_PURGEBIN:
            return
        if not messagebox.askyesno(
            "Empty Purge Bin",
            "Permanently delete everything in the Purge Bin?\nThis cannot be undone.",
        ):
            return

        def _worker():
            try:
                count = purgebin_empty() or 0
            except Exception as e:
                self.log_message(f"Purge Bin empty failed: {e}")
                self.after(0, lambda: messagebox.showerror("Purge Bin", f"Empty failed: {e}"))
                return
            self.log_message(f"Purge Bin emptied: {count} item(s) permanently deleted.")
            self.after(0, self._refresh_purgebin)

        threading.Thread(target=_worker, daemon=True).start()

    # =========================================================================
    # REBOOT QUEUE (PendingFileRenameOperations)
    # =========================================================================
    def _create_reboot_queue_view(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self.content_container, fg_color="transparent")
        frame.grid_rowconfigure(3, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        hdr = ctk.CTkFrame(frame, fg_color=COLOR_CARD, corner_radius=10)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 10), padx=2, ipady=6)
        hdr.grid_columnconfigure(0, weight=1)

        title = ctk.CTkLabel(
            hdr,
            text="Reboot Queue — pending file operations",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLOR_TEXT_PRIMARY,
        )
        title.grid(row=0, column=0, padx=14, pady=(6, 2), sticky="w")

        desc = ctk.CTkLabel(
            hdr,
            text="Windows applies these moves/deletes at the next boot (used when a file is locked).\nCancelling an entry removes it from the queue.",
            font=ctk.CTkFont(size=11),
            text_color=COLOR_TEXT_SECONDARY,
            justify="left",
        )
        desc.grid(row=1, column=0, padx=14, pady=(0, 8), sticky="w")

        act_bar = ctk.CTkFrame(frame, fg_color="transparent")
        act_bar.grid(row=1, column=0, sticky="ew", pady=(0, 8))

        self.reboot_status_lbl = ctk.CTkLabel(
            act_bar,
            text="",
            font=ctk.CTkFont(size=12),
            text_color=COLOR_TEXT_SECONDARY,
        )
        self.reboot_status_lbl.pack(side="left", padx=4)

        refresh_btn = ctk.CTkButton(
            act_bar,
            text="🔄 Refresh",
            font=ctk.CTkFont(size=12),
            height=32,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._refresh_reboot_queue,
        )
        refresh_btn.pack(side="right", padx=4)

        self.reboot_note_lbl = ctk.CTkLabel(
            frame,
            text="",
            font=ctk.CTkFont(size=11),
            text_color="#f59e0b",
            wraplength=900,
            justify="left",
        )
        self.reboot_note_lbl.grid(row=2, column=0, sticky="w", padx=4, pady=(0, 6))

        self.reboot_scroll = ctk.CTkScrollableFrame(
            frame,
            fg_color=COLOR_CARD,
            border_color=COLOR_CARD_BORDER,
            border_width=1,
            corner_radius=10,
        )
        self.reboot_scroll.grid(row=3, column=0, sticky="nsew", padx=2)
        self.reboot_scroll.grid_columnconfigure(0, weight=1)

        return frame

    def _read_pending_renames(self):
        """Read PendingFileRenameOperations. Returns (entries, note); entries = [(src, dst)]."""
        try:
            import winreg
        except ImportError:
            return [], "Reboot queue is only available on Windows."
        try:
            with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SYSTEM\CurrentControlSet\Control\Session Manager",
                0,
                winreg.KEY_READ,
            ) as key:
                values, _ = winreg.QueryValueEx(key, "PendingFileRenameOperations")
        except PermissionError:
            return [], "Access denied — restart VoidPurge as Administrator to view the reboot queue."
        except FileNotFoundError:
            return [], None
        except OSError as e:
            return [], f"Could not read the reboot queue: {e}"

        entries = []
        vals = list(values) if values else []
        for i in range(0, len(vals) - 1, 2):
            entries.append((vals[i], vals[i + 1]))
        return entries, None

    @staticmethod
    def _clean_rename_path(p) -> str:
        s = str(p or "")
        if s.lower().startswith("\\??\\"):
            s = s[4:]
        return s

    def _refresh_reboot_queue(self):
        for w in self.reboot_scroll.winfo_children():
            w.destroy()

        entries, note = self._read_pending_renames()
        self.reboot_note_lbl.configure(text=note or "")
        self.reboot_status_lbl.configure(text=f"{len(entries)} pending operation(s)")

        if not entries:
            lbl = ctk.CTkLabel(
                self.reboot_scroll,
                text="No pending file operations. The queue is empty." if not note else "No entries listed.",
                font=ctk.CTkFont(size=13),
                text_color=COLOR_ACCENT_EMERALD if not note else COLOR_TEXT_SECONDARY,
            )
            lbl.pack(pady=40)
            return

        for idx, (src, dst) in enumerate(entries):
            src_c = self._clean_rename_path(src)
            dst_c = self._clean_rename_path(dst)
            action = "DELETE at next boot" if not dst_c else f"→ move to {dst_c} at next boot"

            row = ctk.CTkFrame(self.reboot_scroll, fg_color=COLOR_SIDEBAR, corner_radius=6)
            row.pack(fill="x", pady=2, padx=4)
            row.grid_columnconfigure(0, weight=1)

            info = ctk.CTkLabel(
                row,
                text=f"{src_c}\n{action}",
                font=ctk.CTkFont(size=11),
                text_color=COLOR_TEXT_PRIMARY,
                anchor="w",
                justify="left",
            )
            info.grid(row=0, column=0, padx=10, pady=8, sticky="w")

            cancel_btn = ctk.CTkButton(
                row,
                text="Cancel",
                font=ctk.CTkFont(size=11, weight="bold"),
                height=30,
                width=80,
                fg_color=COLOR_SIDEBAR,
                hover_color=COLOR_CARD_BORDER,
                command=lambda i=idx, s=src_c: self._cancel_pending_entry(i, s),
            )
            cancel_btn.grid(row=0, column=1, padx=10, pady=8, sticky="e")

    def _cancel_pending_entry(self, index: int, display_src: str):
        # Re-read first so a stale index can't cancel the wrong entry
        entries, note = self._read_pending_renames()
        if note or index >= len(entries) or self._clean_rename_path(entries[index][0]) != display_src:
            messagebox.showinfo("Reboot Queue", "The queue changed — refreshing.")
            self._refresh_reboot_queue()
            return

        if not messagebox.askyesno(
            "Cancel Reboot Operation",
            f"Remove this pending operation from the reboot queue?\n{display_src}\n\nIt will NOT be applied at the next boot.",
        ):
            return

        try:
            import winreg
        except ImportError:
            messagebox.showerror("Reboot Queue", "Not available on this platform.")
            return

        try:
            with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SYSTEM\CurrentControlSet\Control\Session Manager",
                0,
                winreg.KEY_READ | winreg.KEY_SET_VALUE,
            ) as key:
                values, _ = winreg.QueryValueEx(key, "PendingFileRenameOperations")
                vals = list(values) if values else []
                new_vals = [v for j, v in enumerate(vals) if j // 2 != index]
                winreg.SetValueEx(key, "PendingFileRenameOperations", 0, winreg.REG_MULTI_SZ, new_vals)
        except PermissionError:
            messagebox.showerror(
                "Reboot Queue",
                "Access denied — restart VoidPurge as Administrator to modify the reboot queue.",
            )
            return
        except OSError as e:
            messagebox.showerror("Reboot Queue", f"Failed to update the reboot queue: {e}")
            return

        self.log_message(f"Cancelled pending reboot operation: {display_src}")
        self._refresh_reboot_queue()


    # =========================================================================
    # CACHE TAB EXTRAS: DNS Flush + Event Log Clear
    # =========================================================================
    def _flush_dns(self):
        def _task():
            self.log_message("Flushing DNS resolver cache...")
            success, msg = flush_dns_cache()
            self.log_message(msg)
            if success:
                self.after(0, lambda: messagebox.showinfo("VoidPurge", msg))
        threading.Thread(target=_task, daemon=True).start()

    def _clear_event_logs(self):
        if not messagebox.askyesno(
            "Clear Event Logs",
            "Clear ALL Windows Event Logs?\n\nThis removes Application, System, Security, and all other logs.\nThis action cannot be undone.",
        ):
            return
        def _task():
            self.log_message("Clearing Windows Event Logs...")
            count, msg = clear_event_logs()
            self.log_message(msg)
            self.after(0, lambda: messagebox.showinfo("VoidPurge", msg))
        threading.Thread(target=_task, daemon=True).start()

    # =========================================================================
    # STARTUP MANAGER TAB & SYSTEM ACCELERATOR
    # =========================================================================
    def _refresh_startup_stats_background(self):
        """Background check on startup to update the home dashboard stat card."""
        def _task():
            try:
                entries = get_startup_entries(show_system_tasks=False)
                bloat_count = sum(1 for e in entries if e.get("safety_tier") == "STARTUP_BLOAT")
                total = len(entries)
                def _update():
                    if hasattr(self, "home_startup_stat"):
                        if bloat_count > 0:
                            self.home_startup_stat.configure(
                                text=f"{bloat_count} Bloat Items",
                                text_color="#ef4444",
                            )
                        else:
                            self.home_startup_stat.configure(
                                text=f"Clean ({total} Apps)",
                                text_color="#10b981",
                            )
                self.after(0, _update)
            except Exception:
                pass
        threading.Thread(target=_task, daemon=True).start()

    def _create_startup_manager_view(self) -> ctk.CTkFrame:
        frame = ctk.CTkFrame(self.content_container, fg_color="transparent")
        frame.grid_rowconfigure(3, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        # 1. Header
        hdr = ctk.CTkFrame(frame, fg_color=COLOR_CARD, corner_radius=10)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 8), padx=2, ipady=6)
        hdr.grid_columnconfigure(0, weight=1)

        title = ctk.CTkLabel(
            hdr,
            text="🚀 Startup & Boot Optimizer",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLOR_TEXT_PRIMARY,
        )
        title.grid(row=0, column=0, padx=14, pady=(6, 2), sticky="w")

        desc = ctk.CTkLabel(
            hdr,
            text="Disable unnecessary startup bloatware, updaters, and background tasks to accelerate Windows boot speed while keeping hardware drivers and Windows Security 100% safe.",
            font=ctk.CTkFont(size=11),
            text_color=COLOR_TEXT_SECONDARY,
        )
        desc.grid(row=1, column=0, padx=14, pady=(0, 8), sticky="w")

        # 2. Primary Action Bar
        act_bar = ctk.CTkFrame(frame, fg_color="transparent")
        act_bar.grid(row=1, column=0, sticky="ew", pady=(0, 6))

        self.startup_count_lbl = ctk.CTkLabel(
            act_bar,
            text="Loading startup entries...",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=COLOR_TEXT_SECONDARY,
        )
        self.startup_count_lbl.pack(side="left", padx=4)

        refresh_startup_btn = ctk.CTkButton(
            act_bar,
            text="🔄 Refresh",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._load_startup_entries,
        )
        refresh_startup_btn.pack(side="right", padx=4)

        self.disable_startup_btn = ctk.CTkButton(
            act_bar,
            text="🚫 Disable Selected",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._disable_selected_startup,
        )
        self.disable_startup_btn.pack(side="right", padx=4)

        self.disable_non_essential_btn = ctk.CTkButton(
            act_bar,
            text="⚡ Disable Non-Essential (Keep Drivers Safe)",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color="#d97706",
            hover_color="#b45309",
            command=self._disable_non_essential_startup,
        )
        self.disable_non_essential_btn.pack(side="right", padx=4)

        self.disable_bloat_btn = ctk.CTkButton(
            act_bar,
            text="🚨 1-Click Disable Bloat",
            font=ctk.CTkFont(size=12, weight="bold"),
            height=32,
            fg_color="#dc2626",
            hover_color="#b91c1c",
            command=self._disable_startup_bloat,
        )
        self.disable_bloat_btn.pack(side="right", padx=4)

        # 3. Secondary Controls / Filters Bar
        ctrl_bar = ctk.CTkFrame(frame, fg_color="transparent")
        ctrl_bar.grid(row=2, column=0, sticky="ew", pady=(0, 6))

        self.show_system_tasks_var = ctk.BooleanVar(value=False)
        sys_tasks_chk = ctk.CTkCheckBox(
            ctrl_bar,
            text="Show Windows System Tasks",
            variable=self.show_system_tasks_var,
            font=ctk.CTkFont(size=11),
            fg_color=COLOR_ACCENT_CRIMSON,
            command=self._load_startup_entries,
        )
        sys_tasks_chk.pack(side="left", padx=4)

        add_startup_btn = ctk.CTkButton(
            ctrl_bar,
            text="➕ Add App to Startup",
            font=ctk.CTkFont(size=11, weight="bold"),
            height=26,
            fg_color="#2563eb",
            hover_color="#1d4ed8",
            command=self._add_custom_startup_app,
        )
        add_startup_btn.pack(side="left", padx=4)

        open_startup_folder_btn = ctk.CTkButton(
            ctrl_bar,
            text="📂 Open Startup Folder",
            font=ctk.CTkFont(size=11),
            height=26,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=self._open_startup_folder,
        )
        open_startup_folder_btn.pack(side="left", padx=4)

        # Quick selection helpers
        deselect_btn = ctk.CTkButton(
            ctrl_bar,
            text="Deselect All",
            font=ctk.CTkFont(size=11),
            height=26,
            width=80,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=lambda: self._select_startup_filter("none"),
        )
        deselect_btn.pack(side="right", padx=2)

        sel_all_safe_btn = ctk.CTkButton(
            ctrl_bar,
            text="Select Non-Drivers",
            font=ctk.CTkFont(size=11),
            height=26,
            width=120,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=lambda: self._select_startup_filter("non_essential"),
        )
        sel_all_safe_btn.pack(side="right", padx=2)

        sel_bloat_btn = ctk.CTkButton(
            ctrl_bar,
            text="Select Bloat Only",
            font=ctk.CTkFont(size=11, weight="bold"),
            height=26,
            width=110,
            fg_color=COLOR_SIDEBAR,
            hover_color=COLOR_CARD_BORDER,
            command=lambda: self._select_startup_filter("bloat"),
        )
        sel_bloat_btn.pack(side="right", padx=2)

        # 4. Scrollable List
        self.startup_scroll = ctk.CTkScrollableFrame(
            frame,
            fg_color=COLOR_CARD,
            border_color=COLOR_CARD_BORDER,
            border_width=1,
            corner_radius=10,
        )
        self.startup_scroll.grid(row=3, column=0, sticky="nsew", padx=2)
        self.startup_scroll.grid_columnconfigure(0, weight=0)
        self.startup_scroll.grid_columnconfigure(1, weight=2)
        self.startup_scroll.grid_columnconfigure(2, weight=1)
        self.startup_scroll.grid_columnconfigure(3, weight=3)
        self.startup_scroll.grid_columnconfigure(4, weight=1)

        self._startup_entries = []
        self._startup_check_vars = []

        self.after(300, self._load_startup_entries)
        return frame

    def _load_startup_entries(self):
        show_sys = self.show_system_tasks_var.get() if hasattr(self, "show_system_tasks_var") else False
        self.startup_count_lbl.configure(text="Scanning startup apps and scheduled tasks...")
        def _task():
            entries = get_startup_entries(show_system_tasks=show_sys)
            self._startup_entries = entries
            self.after(0, self._render_startup_entries)
        threading.Thread(target=_task, daemon=True).start()

    def _render_startup_entries(self):
        for w in self.startup_scroll.winfo_children():
            w.destroy()
        self._startup_check_vars.clear()

        entries = self._startup_entries
        bloat_count = sum(1 for e in entries if e.get("safety_tier") == "STARTUP_BLOAT")
        driver_count = sum(1 for e in entries if e.get("safety_tier") == "CRITICAL_DRIVER")
        user_count = len(entries) - bloat_count - driver_count

        if hasattr(self, "disable_bloat_btn"):
            self.disable_bloat_btn.configure(text=f"🚨 1-Click Disable Bloat ({bloat_count})")
        if hasattr(self, "home_startup_stat"):
            if bloat_count > 0:
                self.home_startup_stat.configure(text=f"{bloat_count} Bloat Items", text_color="#ef4444")
            else:
                self.home_startup_stat.configure(text=f"Clean ({len(entries)} Apps)", text_color="#10b981")

        self.startup_count_lbl.configure(
            text=f"{len(entries)} Startup Items  •  🚨 {bloat_count} Bloat  •  👤 {user_count} User Apps  •  🛡️ {driver_count} Protected Drivers"
        )

        if not entries:
            empty = ctk.CTkLabel(
                self.startup_scroll,
                text="No startup entries found.",
                font=ctk.CTkFont(size=13),
                text_color=COLOR_TEXT_SECONDARY,
            )
            empty.pack(pady=40)
            return

        # Column headers
        headers = [("", 0), ("Application / Service Name", 1), ("Safety Status", 2), ("Target Command / Path", 3), ("Startup Source", 4)]
        for text, col in headers:
            h = ctk.CTkLabel(
                self.startup_scroll,
                text=text,
                font=ctk.CTkFont(size=11, weight="bold"),
                text_color=COLOR_TEXT_SECONDARY,
            )
            h.grid(row=0, column=col, padx=8, pady=(4, 8), sticky="w")

        for idx, entry in enumerate(entries, start=1):
            row_bg = COLOR_SIDEBAR if idx % 2 == 0 else "transparent"
            row_frame = ctk.CTkFrame(self.startup_scroll, fg_color=row_bg, corner_radius=6, height=38)
            row_frame.grid(row=idx, column=0, columnspan=5, sticky="ew", pady=1)
            row_frame.grid_columnconfigure(0, weight=0)
            row_frame.grid_columnconfigure(1, weight=2)
            row_frame.grid_columnconfigure(2, weight=1)
            row_frame.grid_columnconfigure(3, weight=3)
            row_frame.grid_columnconfigure(4, weight=1)

            tier = entry.get("safety_tier", "USER_APP")

            var = ctk.BooleanVar(value=False)
            self._startup_check_vars.append(var)

            chk = ctk.CTkCheckBox(
                row_frame,
                text="",
                variable=var,
                width=24,
                fg_color=COLOR_ACCENT_CRIMSON,
            )
            chk.grid(row=0, column=0, padx=(10, 4), pady=6, sticky="w")

            name_lbl = ctk.CTkLabel(
                row_frame,
                text=entry["name"][:45],
                font=ctk.CTkFont(size=12, weight="bold"),
                text_color=COLOR_TEXT_PRIMARY,
            )
            name_lbl.grid(row=0, column=1, padx=6, pady=6, sticky="w")

            # Badge
            if tier == "CRITICAL_DRIVER":
                badge_text = "🛡️ KEEP (Driver/Security)"
                b_fg = "#064e3b"
                b_tc = "#34d399"
            elif tier == "STARTUP_BLOAT":
                badge_text = "🚨 DISABLE (Bloatware)"
                b_fg = "#450a0a"
                b_tc = "#f87171"
            else:
                badge_text = "👤 USER APP"
                b_fg = "#1e1b4b"
                b_tc = "#818cf8"

            badge = ctk.CTkLabel(
                row_frame,
                text=badge_text,
                font=ctk.CTkFont(size=10, weight="bold"),
                fg_color=b_fg,
                text_color=b_tc,
                corner_radius=6,
                padx=8,
                pady=2,
            )
            badge.grid(row=0, column=2, padx=6, pady=6, sticky="w")

            cmd_lbl = ctk.CTkLabel(
                row_frame,
                text=entry["command"][:75],
                font=ctk.CTkFont(size=10),
                text_color=COLOR_TEXT_SECONDARY,
            )
            cmd_lbl.grid(row=0, column=3, padx=6, pady=6, sticky="w")

            src_color = COLOR_ACCENT_BLUE if "Task Scheduler" in entry["source"] else COLOR_TEXT_SECONDARY
            src_lbl = ctk.CTkLabel(
                row_frame,
                text=entry["source"],
                font=ctk.CTkFont(size=10, weight="bold"),
                text_color=src_color,
            )
            src_lbl.grid(row=0, column=4, padx=8, pady=6, sticky="w")

    def _select_startup_filter(self, filter_mode: str):
        for i, entry in enumerate(self._startup_entries):
            if i >= len(self._startup_check_vars):
                break
            tier = entry.get("safety_tier", "USER_APP")
            if filter_mode == "bloat":
                self._startup_check_vars[i].set(tier == "STARTUP_BLOAT")
            elif filter_mode == "non_essential":
                self._startup_check_vars[i].set(tier != "CRITICAL_DRIVER")
            elif filter_mode == "all":
                self._startup_check_vars[i].set(True)
            elif filter_mode == "none":
                self._startup_check_vars[i].set(False)

    def _disable_startup_bloat(self):
        bloat_items = [e for e in self._startup_entries if e.get("safety_tier") == "STARTUP_BLOAT"]
        if not bloat_items:
            messagebox.showinfo("VoidPurge", "✨ No startup bloatware detected! Your startup is already clean.")
            return

        confirm = (
            f"Disable all {len(bloat_items)} detected startup bloatware item(s)?\n\n"
            + "\n".join(f"• {e['name']}  [{e['source']}]" for e in bloat_items)
            + "\n\nThese background telemetry updaters and assistant utilities will be safely removed or disabled.\nYour hardware drivers and personal apps will not be affected."
        )
        if not messagebox.askyesno("Disable Startup Bloatware", confirm):
            return

        def _task():
            self.log_message(f"Starting 1-click startup debloat ({len(bloat_items)} items)...")
            disabled_count = 0
            for entry in bloat_items:
                self.log_message(f"Disabling startup bloat: {entry['name']} [{entry['source']}]")
                success, msg = disable_startup_entry(entry)
                self.log_message(f"  → {msg}")
                if success:
                    disabled_count += 1
            self.log_message(f"Startup debloat completed: {disabled_count} bloat item(s) disabled.")
            self.after(0, self._load_startup_entries)

        threading.Thread(target=_task, daemon=True).start()

    def _disable_non_essential_startup(self):
        non_essential = [e for e in self._startup_entries if e.get("safety_tier") != "CRITICAL_DRIVER"]
        if not non_essential:
            messagebox.showinfo("VoidPurge", "All startup entries are protected drivers or Windows security components.")
            return

        confirm = (
            f"Disable {len(non_essential)} non-essential startup app(s) to optimize boot speed?\n\n"
            + "\n".join(f"• {e['name']}  [{e.get('safety_tier', '').replace('_', ' ')}]" for e in non_essential[:8])
            + (f"\n...and {len(non_essential)-8} more" if len(non_essential) > 8 else "")
            + "\n\n🛡️ Hardware drivers (Realtek, Graphics, Intel/AMD) and Windows Security are kept 100% safe."
        )
        if not messagebox.askyesno("Disable Non-Essential Startup", confirm):
            return

        def _task():
            self.log_message(f"Disabling {len(non_essential)} non-essential startup items...")
            count = 0
            for entry in non_essential:
                self.log_message(f"Disabling startup: {entry['name']} [{entry['source']}]")
                success, msg = disable_startup_entry(entry)
                self.log_message(f"  → {msg}")
                if success:
                    count += 1
            self.log_message(f"Startup optimization complete: {count} item(s) disabled.")
            self.after(0, self._load_startup_entries)

        threading.Thread(target=_task, daemon=True).start()

    def _disable_selected_startup(self):
        selected = [
            self._startup_entries[i]
            for i, var in enumerate(self._startup_check_vars)
            if var.get() and i < len(self._startup_entries)
        ]
        if not selected:
            messagebox.showinfo("VoidPurge", "Select at least one startup entry to disable.")
            return

        # Warning if critical drivers are in selection
        drivers_in_sel = [e for e in selected if e.get("safety_tier") == "CRITICAL_DRIVER"]
        warning_extra = ""
        if drivers_in_sel:
            warning_extra = (
                "\n\n⚠️ CAUTION: You have selected protected hardware driver(s) or security tools:\n"
                + "\n".join(f"  • {e['name']}" for e in drivers_in_sel)
                + "\nDisabling these may cause audio, network, or security issues!"
            )

        confirm = (
            f"Disable {len(selected)} startup item(s)?\n\n"
            + "\n".join(f"• {e['name']}" for e in selected[:5])
            + (f"\n...and {len(selected)-5} more" if len(selected) > 5 else "")
            + warning_extra
            + "\n\nRegistry entries will be removed. Task Scheduler tasks will be disabled. Startup folder shortcuts will be removed."
        )
        if not messagebox.askyesno("Confirm Disable", confirm):
            return

        def _task():
            for entry in selected:
                self.log_message(f"Disabling startup: {entry['name']} [{entry['source']}]")
                success, msg = disable_startup_entry(entry)
                self.log_message(f"  → {msg}")
            self.after(0, self._load_startup_entries)

        threading.Thread(target=_task, daemon=True).start()


    def _open_startup_folder(self):
        """Open the Windows Startup user folder in File Explorer."""
        try:
            os.startfile(r"shell:startup")
            self.log_message("Opened Windows Startup folder (shell:startup).")
        except Exception as e:
            messagebox.showerror("VoidPurge", f"Could not open Startup folder: {e}")

    def _add_custom_startup_app(self):
        """Let the user browse for an executable or shortcut to add to Windows Startup."""
        file_path = filedialog.askopenfilename(
            title="Select Application to Run on Windows Startup",
            filetypes=[
                ("Executables & Shortcuts", "*.exe;*.lnk;*.bat;*.cmd"),
                ("All Files", "*.*"),
            ],
        )
        if not file_path:
            return

        p = Path(file_path)
        name = p.stem.replace("_", " ").title()

        confirm = messagebox.askyesno(
            "Add to Windows Startup",
            f"Add '{name}' to Windows Startup?\n\nPath:\n{file_path}\n\nThis application will automatically launch whenever you open your PC."
        )
        if not confirm:
            return

        self.log_message(f"Adding application to Windows Startup: {name} -> {file_path}")
        success, msg = add_startup_entry(name, file_path)
        self.log_message(f"  → {msg}")
        if success:
            messagebox.showinfo(
                "VoidPurge",
                f"✅ Added '{name}' to Windows Startup!\n\n{msg}"
            )
            self._load_startup_entries()
        else:
            messagebox.showerror("VoidPurge", msg)


def launch_app():
    """Main launcher."""
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")

    app = VoidPurgeApp()
    app.mainloop()
