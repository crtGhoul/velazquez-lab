import os
import sys
import ctypes
import subprocess
from pathlib import Path
from typing import List, Set

# Base directory for backups and logs
APP_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "VoidPurge"
BACKUP_DIR = APP_DIR / "backups"
LOGS_DIR = APP_DIR / "logs"

BACKUP_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

# Strict protected system paths (Lowercased strings for normalization)
PROTECTED_PATHS: List[Path] = [
    Path(os.environ.get("SystemRoot", r"C:\Windows")),
    Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32",
    Path(os.environ.get("SystemRoot", r"C:\Windows")) / "SysWOW64",
    Path(os.environ.get("SystemRoot", r"C:\Windows")) / "WinSxS",
    Path(r"C:\Users"),
    Path.home(),
    Path(r"C:\Program Files"),
    Path(r"C:\Program Files (x86)"),
    Path(r"C:\\"),
    Path(r"D:\\"),
]

# Exact root directory paths that must never be wiped entirely
PROTECTED_ROOT_NAMES: Set[str] = {
    "windows", "system32", "syswow64", "winsxs", "users", "boot",
    "recovery", "system volume information", "$recycle.bin"
}

# Critical OS process names that must never be terminated
PROTECTED_PROCESSES: Set[str] = {
    "explorer.exe",
    "svchost.exe",
    "csrss.exe",
    "wininit.exe",
    "winlogon.exe",
    "lsass.exe",
    "services.exe",
    "smss.exe",
    "dwm.exe",
    "taskhostw.exe",
    "sihost.exe",
    "fontdrvhost.exe",
    "ctfmon.exe",
    "conhost.exe",
}

def to_long_path(path) -> str:
    """Return the \\\\?\\ long-path form of a path (bypasses MAX_PATH on Windows).

    Windows-only helper; returns the input unchanged on other platforms.
    Callers should only use the result with Windows APIs.
    """
    s = str(path)
    if os.name != "nt":
        return s
    if s.startswith("\\\\?\\"):
        return s
    try:
        resolved = str(Path(s).resolve())
    except Exception:
        resolved = s
    if resolved.startswith("\\\\"):
        return "\\\\?\\UNC\\" + resolved[2:]
    return "\\\\?\\" + resolved


def is_admin() -> bool:
    """Check if process currently has administrative privileges."""
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False

def elevate_admin() -> None:
    """Prompt UAC elevation to restart the program with Administrator rights."""
    if is_admin():
        return
    if getattr(sys, "frozen", False):
        exe = sys.executable
        params = " ".join([f'"{arg}"' for arg in sys.argv[1:]])
        work_dir = os.path.dirname(exe)
    else:
        exe = sys.executable
        script_path = os.path.abspath(sys.argv[0])
        args = [f'"{script_path}"'] + [f'"{arg}"' for arg in sys.argv[1:]]
        params = " ".join(args)
        work_dir = os.path.dirname(script_path)
    try:
        ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, work_dir, 1)
    except Exception as e:
        print(f"Failed to elevate UAC: {e}")
    sys.exit(0)

def format_bytes(size_bytes: float) -> str:
    """Format bytes into human-readable B, KB, MB, GB."""
    if size_bytes <= 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while size_bytes >= 1024.0 and i < len(units) - 1:
        size_bytes /= 1024.0
        i += 1
    return f"{size_bytes:.2f} {units[i]}"

def is_protected_path(target_path: Path) -> bool:
    """Return True if path is a core OS system path or disk root."""
    try:
        resolved = target_path.resolve()
    except Exception:
        return True

    # Check root drives
    if str(resolved).rstrip("\\/").endswith(":") or resolved.parent == resolved:
        return True

    # Check against root folder names
    if resolved.name.lower() in PROTECTED_ROOT_NAMES:
        return True

    # Check if target is an exact match for protected roots or user home root
    for p in PROTECTED_PATHS:
        try:
            p_res = p.resolve()
            if resolved == p_res:
                return True
            # Special guard: Do not allow deleting entire C:\Users or C:\Windows sub-bases
            if p_res in [Path(r"C:\Windows").resolve(), Path(r"C:\Users").resolve()] and resolved in p_res.parents:
                return True
        except Exception:
            continue

    return False

def is_protected_process(proc_name: str) -> bool:
    """Return True if process is a vital Windows core process."""
    if not proc_name:
        return False
    return proc_name.lower().strip() in PROTECTED_PROCESSES

def ensure_ownership(path: Path) -> None:
    """Take ownership of stubborn NTFS file/directory and grant Full Control to Administrators."""
    try:
        path_str = str(path.resolve())
        # takeown /F <path> /R /D Y
        if path.is_dir():
            subprocess.run(
                ["takeown", "/F", path_str, "/R", "/D", "Y"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            subprocess.run(
                ["icacls", path_str, "/grant", "*S-1-5-32-544:F", "/T", "/C", "/Q"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
        else:
            subprocess.run(
                ["takeown", "/F", path_str, "/D", "Y"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
            subprocess.run(
                ["icacls", path_str, "/grant", "*S-1-5-32-544:F", "/C", "/Q"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )
    except Exception as e:
        print(f"Ownership grant error on {path}: {e}")

def schedule_delayed_deletion(path: Path) -> bool:
    """Register file/dir for deletion on next system reboot via MoveFileExW (Kernel delayed)."""
    try:
        MOVEFILE_DELAY_UNTIL_REBOOT = 0x00000004
        ret = ctypes.windll.kernel32.MoveFileExW(str(path.resolve()), None, MOVEFILE_DELAY_UNTIL_REBOOT)
        return bool(ret)
    except Exception:
        return False

def terminate_app_processes(token: str) -> List[str]:
    """Kill any running processes whose executable or name contains token (ignoring protected processes)."""
    import psutil
    killed = []
    token_low = token.lower().strip()
    if len(token_low) < 3:
        return killed

    for proc in psutil.process_iter(['pid', 'name', 'exe']):
        try:
            p_name = proc.info.get('name') or ""
            p_exe = proc.info.get('exe') or ""
            if is_protected_process(p_name):
                continue
            if token_low in p_name.lower() or token_low in p_exe.lower():
                proc.kill()
                killed.append(f"{p_name} (PID: {proc.info.get('pid')})")
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return killed

def stop_and_delete_service(token: str) -> List[str]:
    """Stop and delete any Windows service whose ServiceName or DisplayName matches token."""
    removed = []
    token_low = token.lower().strip()
    if len(token_low) < 3:
        return removed

    try:
        # Query services using PowerShell
        ps_cmd = f"Get-Service | Where-Object {{ $_.Name -like '*{token_low}*' -or $_.DisplayName -like '*{token_low}*' }} | Select-Object -ExpandProperty Name"
        res = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_cmd],
            capture_output=True,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        if res.returncode == 0 and res.stdout.strip():
            for s_name in res.stdout.strip().splitlines():
                s_name = s_name.strip()
                if not s_name:
                    continue
                # Stop service
                subprocess.run(
                    ["sc", "stop", s_name],
                    capture_output=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                # Delete service
                subprocess.run(
                    ["sc", "delete", s_name],
                    capture_output=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
                )
                removed.append(s_name)
    except Exception:
        pass
    return removed

def restart_explorer() -> None:
    """Safely restart Windows Explorer to clean stale taskbar icons and shell hooks."""
    try:
        subprocess.run(
            ["taskkill", "/F", "/IM", "explorer.exe"],
            capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        subprocess.Popen(
            ["explorer.exe"],
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
    except Exception:
        pass

def backup_registry_key(key_path: str, backup_dir: Path = BACKUP_DIR) -> str:
    """Export a Windows Registry key to a .reg backup file before deletion."""
    try:
        backup_dir.mkdir(parents=True, exist_ok=True)
        # Normalize key naming for filename
        sanitized_name = key_path.replace("\\", "_").replace(":", "_").replace(" ", "_")
        target_file = backup_dir / f"{sanitized_name[:120]}.reg"
        
        # reg export <KeyName> <FileName> [/y]
        res = subprocess.run(
            ["reg", "export", key_path, str(target_file), "/y"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        if res.returncode == 0:
            return str(target_file)
        return ""
    except Exception as e:
        print(f"Registry backup failed for {key_path}: {e}")
        return ""
