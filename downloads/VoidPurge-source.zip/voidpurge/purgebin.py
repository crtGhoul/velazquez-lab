"""Purge Bin: a safety net for deletions.

Instead of deleting immediately, files/dirs are *staged* into a timestamped
folder under %LOCALAPPDATA%\\VoidPurge\\purge-bin with a manifest.json
recording where they came from. Items can be restored or emptied later;
auto_empty() prunes items older than N days.

Protected system paths are ALWAYS refused - this module never weakens the
guards in utils.is_protected_path.
"""
import json
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Tuple

from .utils import APP_DIR, is_protected_path, to_long_path

PURGE_BIN_DIR = APP_DIR / "purge-bin"


def _bin_dir() -> Path:
    PURGE_BIN_DIR.mkdir(parents=True, exist_ok=True)
    return PURGE_BIN_DIR


def _desktop_path() -> Path:
    """User Desktop (fallback restore location). Separate helper for tests."""
    return Path.home() / "Desktop"


def _dir_size(p: Path) -> int:
    total = 0
    try:
        if p.is_file() and not p.is_symlink():
            return p.stat().st_size
        for f in p.rglob("*"):
            try:
                if f.is_file() and not f.is_symlink():
                    total += f.stat().st_size
            except OSError:
                continue
    except OSError:
        pass
    return total


def _unique_item_id(bin_dir: Path, base: str) -> str:
    candidate = base
    n = 2
    while (bin_dir / candidate).exists():
        candidate = f"{base}-{n}"
        n += 1
    return candidate


def stage(path) -> Tuple[bool, str, str]:
    """Move a file/dir into the purge bin. Returns (ok, message, item_id)."""
    p = Path(path).expanduser()
    if is_protected_path(p):
        return False, f"Refused: '{p}' is a protected system path.", ""
    if not p.exists() or p.is_symlink():
        return False, f"'{p}' does not exist (or is a symlink).", ""

    bin_dir = _bin_dir()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    base = f"{stamp}_{p.name}"
    item_id = _unique_item_id(bin_dir, base)
    item_dir = bin_dir / item_id

    size = _dir_size(p)
    original = str(p.resolve())
    try:
        item_dir.mkdir(parents=True, exist_ok=False)
        shutil.move(str(p), to_long_path(str(item_dir / p.name)))
    except Exception as e:
        # Clean up the half-created folder on failure.
        try:
            shutil.rmtree(to_long_path(str(item_dir)), ignore_errors=True)
        except Exception:
            pass
        return False, f"Could not stage '{p.name}': {e}", ""

    manifest = {
        "id": item_id,
        "name": p.name,
        "original_path": original,
        "staged_at": datetime.now().isoformat(timespec="seconds"),
        "size": size,
    }
    try:
        (item_dir / "manifest.json").write_text(
            json.dumps(manifest, indent=2), encoding="utf-8"
        )
    except Exception:
        pass  # item is staged; manifest loss only degrades restore metadata

    return True, f"Staged '{p.name}' in the purge bin (undo available).", item_id


def _read_manifest(item_dir: Path) -> Dict:
    try:
        data = json.loads((item_dir / "manifest.json").read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def restore(item_id: str) -> Tuple[bool, str]:
    """Move a staged item back to its original location.

    If the original parent folder no longer exists, restores to the Desktop
    and says so.
    """
    item_dir = _bin_dir() / item_id
    if not item_dir.is_dir():
        return False, f"No purge-bin item '{item_id}'."

    manifest = _read_manifest(item_dir)
    # The staged payload is the single non-manifest entry in the item folder.
    payloads = [c for c in item_dir.iterdir() if c.name != "manifest.json"]
    if not payloads:
        return False, f"Purge-bin item '{item_id}' is empty; nothing to restore."
    src = payloads[0]

    original = Path(manifest.get("original_path", "")) if manifest else None
    if original and original.name:
        target = original
    else:
        target = _desktop_path() / src.name

    fell_back = False
    if target.parent and not target.parent.exists():
        fell_back = True
        target = _desktop_path() / target.name

    if target.exists():
        return False, f"Cannot restore: '{target}' already exists."

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(to_long_path(str(src)), to_long_path(str(target)))
        shutil.rmtree(to_long_path(str(item_dir)), ignore_errors=True)
    except Exception as e:
        return False, f"Restore failed: {e}"

    if fell_back:
        return True, (
            f"Restored '{src.name}' to Desktop (original folder no longer exists)."
        )
    return True, f"Restored '{src.name}' to '{target}'."


def list_items() -> List[Dict]:
    """List staged items: [{id, original_path, name, size, staged_at}, ...]."""
    bin_dir = _bin_dir()
    items: List[Dict] = []
    for item_dir in sorted(bin_dir.iterdir()):
        if not item_dir.is_dir():
            continue
        m = _read_manifest(item_dir)
        items.append(
            {
                "id": m.get("id", item_dir.name),
                "original_path": m.get("original_path", ""),
                "name": m.get("name", item_dir.name),
                "size": m.get("size", 0),
                "staged_at": m.get("staged_at", ""),
            }
        )
    return items


def empty() -> int:
    """Permanently delete everything in the purge bin. Returns count removed."""
    bin_dir = _bin_dir()
    count = 0
    for item_dir in list(bin_dir.iterdir()):
        if item_dir.is_dir():
            try:
                shutil.rmtree(to_long_path(str(item_dir)), ignore_errors=True)
                count += 1
            except Exception:
                continue
    return count


def auto_empty(max_age_days: int = 30) -> int:
    """Permanently delete items staged more than max_age_days ago. Returns count."""
    cutoff = datetime.now() - timedelta(days=max_age_days)
    bin_dir = _bin_dir()
    count = 0
    for item_dir in list(bin_dir.iterdir()):
        if not item_dir.is_dir():
            continue
        m = _read_manifest(item_dir)
        try:
            staged = datetime.fromisoformat(m.get("staged_at", ""))
        except Exception:
            continue  # keep items with unreadable timestamps
        if staged < cutoff:
            try:
                shutil.rmtree(to_long_path(str(item_dir)), ignore_errors=True)
                count += 1
            except Exception:
                continue
    return count
