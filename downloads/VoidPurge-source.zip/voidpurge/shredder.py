import os
import shutil
import psutil
from pathlib import Path
from typing import List, Dict, Any, Tuple

from .utils import (
    is_protected_path,
    is_protected_process,
    ensure_ownership,
    schedule_delayed_deletion,
)


def _detailed_scan_available() -> bool:
    """True when the surgical handle engine (handles.py) is usable on Windows."""
    if os.name != "nt":
        return False
    try:
        from . import handles as _h
        return bool(getattr(_h, "_HAVE_NT", False))
    except Exception:
        return False


def _psutil_locking_processes(target_res: Path) -> List[Dict[str, Any]]:
    """Legacy fallback scan using psutil open_files/cwd (misses mapped files)."""
    target_str_lower = str(target_res).lower()
    locking = []

    for proc in psutil.process_iter(['pid', 'name', 'exe', 'open_files', 'cwd']):
        try:
            p_info = proc.info
            pid = p_info.get('pid')
            name = p_info.get('name') or "Unknown"

            # Check open file handles
            files = p_info.get('open_files') or []
            matched = False
            for f in files:
                f_path = str(Path(f.path).resolve()).lower()
                if f_path == target_str_lower or f_path.startswith(target_str_lower + "\\"):
                    matched = True
                    break

            # If target is folder, check cwd
            if not matched and target_res.is_dir():
                cwd = p_info.get('cwd')
                if cwd:
                    cwd_lower = str(Path(cwd).resolve()).lower()
                    if cwd_lower == target_str_lower or cwd_lower.startswith(target_str_lower + "\\"):
                        matched = True

            if matched:
                locking.append({
                    "pid": pid,
                    "name": name,
                    "exe": p_info.get('exe') or "",
                    "is_protected": is_protected_process(name),
                    "process_obj": proc,
                })
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    return locking


def find_locking_processes(target_path_str: str) -> List[Dict[str, Any]]:
    """Scan and find any running processes locking the given file or directory.

    On Windows this uses the surgical handle engine (handles.py), which sees
    memory-mapped files, loaded DLLs and directory locks that psutil misses;
    everywhere else (or on any failure) it falls back to the psutil scan.
    """
    if not target_path_str:
        return []

    target = Path(target_path_str).expanduser()
    if not target.exists():
        return []

    if _detailed_scan_available():
        try:
            from .handles import find_locking_processes_detailed
            detailed = find_locking_processes_detailed(str(target))
            out: List[Dict[str, Any]] = []
            for d in detailed:
                proc_obj = None
                try:
                    proc_obj = psutil.Process(d["pid"])
                except Exception:
                    proc_obj = None
                out.append({
                    "pid": d["pid"],
                    "name": d.get("name") or "Unknown",
                    "exe": d.get("exe") or "",
                    "handle_count": d.get("handle_count", 0),
                    "is_protected": bool(d.get("is_protected", False)),
                    "process_obj": proc_obj,
                })
            return out
        except Exception:
            pass

    return _psutil_locking_processes(target.resolve())


def _delete_target(resolved: Path, use_recycle_bin: bool) -> None:
    """Perform the actual delete; raises on failure."""
    if use_recycle_bin:
        from send2trash import send2trash
        send2trash(str(resolved))
    elif resolved.is_dir():
        shutil.rmtree(resolved, ignore_errors=False)
    else:
        resolved.unlink(missing_ok=True)


def _secure_wipe_target(resolved: Path, steps: List[str]) -> None:
    """Securely wipe via wipe.py if present; fall back to normal delete.

    Raises only if both the wipe and the fallback delete fail.
    """
    try:
        from .wipe import secure_wipe as _secure_wipe
    except ImportError:
        steps.append("Secure-wipe module not available; falling back to normal delete")
        _delete_target(resolved, use_recycle_bin=False)
        return
    try:
        ok, wipe_msg = _secure_wipe(str(resolved))
    except Exception as e:
        steps.append(f"Secure wipe errored ({e}); falling back to normal delete")
        _delete_target(resolved, use_recycle_bin=False)
        return
    if ok:
        steps.append(f"Securely wiped the file ({wipe_msg})")
    else:
        steps.append(f"Secure wipe refused/failed ({wipe_msg}); falling back to normal delete")
        _delete_target(resolved, use_recycle_bin=False)


def force_delete_with_ladder(
    target_path_str: str,
    use_recycle_bin: bool = False,
    secure_wipe: bool = False,
) -> Tuple[bool, List[str], str]:
    """Delete a locked file/folder via an escalation ladder.

    Order: detect locks -> close handles surgically (no process kills) ->
    kill remaining non-protected lockers as fallback -> take ownership/fix
    permissions -> delete (or secure wipe) -> MoveFileExW reboot fallback.

    Returns (success, steps, message) where steps are plain-language strings
    describing the ladder actually taken.

    Never deletes protected Windows paths; never touches protected processes.
    """
    steps: List[str] = []

    if not target_path_str:
        return False, steps, "Target path is empty."

    target = Path(target_path_str).expanduser()
    if not target.exists():
        return False, steps, f"Path does not exist: {target}"

    if is_protected_path(target):
        msg = f"SECURITY GUARD TRIGGERED: Blocked deletion of protected Windows path: {target}"
        steps.append(msg)
        return False, steps, msg

    resolved = target.resolve()

    # -- Step 1: detect locks -------------------------------------------
    locks = find_locking_processes(str(resolved))
    if locks:
        names = ", ".join(sorted({str(l.get("name") or "?") for l in locks}))
        steps.append(
            f"Found {len(locks)} process{'es' if len(locks) != 1 else ''} "
            f"locking the file ({names})"
        )
    else:
        steps.append("No processes locking the file")

    # Hard stop: a protected Windows process holds a lock -- refuse.
    for lock in locks:
        if lock.get("is_protected"):
            msg = (
                f"Blocked: Critical Windows process '{lock.get('name')}' "
                f"has an open lock on this resource."
            )
            steps.append(msg)
            return False, steps, msg

    # -- Step 2: close handles surgically (Windows only) ------------------
    if os.name == "nt":
        try:
            from .handles import close_handles_on_path
            closed = close_handles_on_path(str(resolved))
            if closed:
                names = ", ".join(sorted({c["name"] for c in closed}))
                steps.append(
                    f"Closed {len(closed)} file handle{'s' if len(closed) != 1 else ''} "
                    f"without killing any app ({names})"
                )
            else:
                steps.append("No handles needed surgical closing")
        except Exception:
            steps.append("Surgical handle close unavailable; continuing")

    # -- Step 3: kill remaining non-protected lockers (fallback) ----------
    remaining = find_locking_processes(str(resolved))
    killed: List[str] = []
    for lock in remaining:
        if lock.get("is_protected"):
            continue  # never kill protected processes
        try:
            proc = lock.get("process_obj")
            if proc is None:
                proc = psutil.Process(lock["pid"])
            proc.kill()
            killed.append(str(lock.get("name") or lock.get("pid")))
        except Exception:
            pass
    if killed:
        names = ", ".join(sorted(set(killed)))
        steps.append(
            f"Killed {len(killed)} process{'es' if len(killed) != 1 else ''} "
            f"that couldn't release the file ({names})"
        )
    elif remaining:
        steps.append("Some locks could not be released; continuing anyway")

    # -- Step 4: ownership / permissions -----------------------------------
    try:
        ensure_ownership(resolved)
        steps.append("Took ownership and fixed permissions")
    except Exception:
        steps.append("Could not adjust permissions; continuing anyway")

    # -- Step 5: delete -----------------------------------------------------
    try:
        if secure_wipe:
            _secure_wipe_target(resolved, steps)
        else:
            _delete_target(resolved, use_recycle_bin)
            steps.append("Sent to Recycle Bin" if use_recycle_bin else "Deleted the file")

        if resolved.exists():
            raise OSError("Target still exists after delete attempt")
        return True, steps, "Success: " + "; ".join(steps)
    except Exception as e:
        # -- Step 6: MoveFileExW reboot fallback ---------------------------
        try:
            scheduled = schedule_delayed_deletion(resolved)
        except Exception:
            scheduled = False
        if scheduled:
            steps.append(
                "File is held by a kernel driver — scheduled for deletion on next reboot"
            )
            return True, steps, "Success: " + "; ".join(steps)
        steps.append(f"Delete failed: {e}")
        return False, steps, "Failed: " + "; ".join(steps)


def force_unlock_and_shred(target_path_str: str, use_recycle_bin: bool = False) -> Tuple[bool, str]:
    """Force unlock and delete file/folder (kept for backwards compatibility).

    Delegates to force_delete_with_ladder(); the ladder first tries surgical
    handle closing before falling back to killing locking processes.
    """
    ok, _steps, message = force_delete_with_ladder(
        target_path_str, use_recycle_bin=use_recycle_bin, secure_wipe=False
    )
    return ok, message
