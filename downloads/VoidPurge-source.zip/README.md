# ⚡ VoidPurge

> **Advanced Windows Program Uninstaller, Deep Leftover Scrubber, and God-Mode Force File Shredder.**  
> Built with Python 3.12, CustomTkinter, Winreg, Psutil, and native Win32 APIs.

---

## ⚠️ Risks & Requirements

**This tool deletes things — read this first:**
- **Requires Administrator.** VoidPurge auto-prompts for UAC elevation on launch; most features won't work without it.
- **The Force Shredder permanently deletes files.** "Permanent Wipe" mode bypasses the Recycle Bin and overwrites data. The **Purge Bin mode** (default) quarantines deletions for 30 days with one-click restore — keep it on unless you know exactly what you're doing.
- **The Leftover Scrubber is aggressive by design.** It hunts files and registry keys across your whole system. Every registry key is auto-backed up to `%LocalAppData%\VoidPurge\backups\` before deletion, and a confirmation dialog gates every wipe — but **back up your system (restore point) before any major cleanup.**
- **Closing handles can crash apps.** Force-deleting a file an app is using may crash that app and lose unsaved work. VoidPurge shows you which process holds the file before acting.
- **Use at your own risk.** VoidPurge is provided as-is (see License). Never point it at anything you can't afford to lose.

---

## ⚡ Quickstart

1. Download `VoidPurge.exe` from the [latest release](https://github.com/crtGhoul/VoidPurge/releases/latest).
2. **Right-click → Run as administrator.**
3. Pick a tab: **Uninstaller** (remove programs), **Scrubber** (clean leftovers), **Shredder** (force-delete locked files), **Space** (purge caches/temp).
4. Review what it found, confirm, done. Deletions land in the Purge Bin first — restore anytime within 30 days.

---

## 🚀 Key Features

### 1. 📦 Deep Program Uninstaller (Win32 + Store Apps)
- **All 3 Registry Uninstall Hives:** Enumerate 64-bit `HKLM`, 32-bit `WOW6432Node`, and per-user `HKCU`.
- **Windows Store / UWP Bloatware Removal:** PowerShell package scanning (with non-elevated fallback) and one-click removal via `Remove-AppxPackage`.
- **Zero-Lag Asynchronous Streaming:** Chunk-rendered table streaming that keeps the UI butter-smooth and responsive with hundreds of apps.
- **Interactive Sortable Columns:** Click on Application Name, Publisher, Size, Type, or Safety Status to sort ascending or descending (▲ / ▼).
- **Power-User Right-Click Context Menu:** Quick uninstall, silent uninstall, deep remnant scrubber, open install folder, copy registry path, and web search.
- **Silent & Standard Uninstall:** Uses native `QuietUninstallString` or injects silent flags (`/VERYSILENT`, `/qn`, `/S`, `/quiet`).
- **Comprehensive Safety Tiers:**
  - **🛡️ KEEP (System/Driver):** Protected core OS components and hardware drivers.
  - **🚨 REMOVE (Bloat/PUP):** Flagged OEM crapware, toolbars, rogue PC cleaners, and known PUPs.
  - **✨ SAFE TO REMOVE (Bloat):** Pre-installed Store junk and unneeded bundles.
  - **⚠️ SAFE IF UNUSED (User App):** Standard user-installed software.
- **One-Click Bloat Filter:** Filter pill to instantly isolate and batch-remove all detected bloat and PUPs.
- **Audit Export:** One-click export to interactive Cyber Dark **HTML Reports** and **CSV Spreadsheets**.

### 2. 🚀 Startup Manager (Boot Accelerator)
- **Registry Autoruns:** Scans `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, `RunOnce`, and `HKLM` (64-bit and 32-bit WOW6432Node).
- **Task Scheduler Autoruns:** Scans logon and boot-triggered scheduled tasks.
- **One-Click Disable:** Remove unnecessary startup entries to dramatically shorten boot times.

### 3. 🧹 Post-Uninstall Leftover Scrubber ("Deep Clean")
- Scans orphaned files and folders in `%AppData%`, `%LocalAppData%`, `%ProgramData%`, `C:\Program Files`, `C:\Program Files (x86)`, Start Menu, and Desktop.
- Scans `HKCU\Software`, `HKLM\Software`, and Windows Startup keys.
- **Automatic .reg Backups:** Every deleted registry key is automatically backed up to `%LocalAppData%\VoidPurge\backups\`.
- **Background Service & Process Slaying:** Automatically terminates associated Windows background services (`sc stop` & `sc delete`) and running processes.
- **Taskbar / Explorer Refresh:** Refreshes `explorer.exe` to flush stale taskbar and system tray ghost icons.

### 4. 💥 "God-Mode" Force File/Folder Shredder (LockHunter Engine)
- Enumerates **all** system handles on a target via native `NtQuerySystemInformation` (catches memory-mapped files, loaded DLLs, and directory locks) and **closes individual file handles** instead of killing whole processes.
- Strips NTFS ACL restrictions and takes ownership (`takeown /F <path> /R /D Y` & `icacls <path> /grant *S-1-5-32-544:F`).
- **Real secure wipe:** single-pass pseudorandom overwrite by default, DoD 5220.22-M 3-pass and Gutmann 35-pass optional. (Note: no software wipe can guarantee erasure on SSDs — wear-leveling hides old cells. VoidPurge says so in-app.)
- **Kernel-Locked Fallback:** Uses Win32 `MoveFileExW` (`MOVEFILE_DELAY_UNTIL_REBOOT`) for files locked by kernel drivers to delete them on the next reboot — with a visible queue you can inspect and cancel.
- **Purge Bin (default):** deletions are quarantined for 30 days with one-click restore; permanent delete is explicit opt-in. Recycle Bin (`send2trash`) mode also available.

### 5. 💾 Comprehensive Space & Cache Purge (BleachBit Competitor)
- **System & Windows Update:** User Temp, System Temp, SoftwareDistribution Download cache, Delivery Optimization P2P cache, Windows Installer patch cache (`$PatchCache$`).
- **System Caches & Logs:** Windows Prefetch, Explorer thumbnail cache (`thumbcache_*.db`), icon cache, font cache, crash dumps (`WER` minidumps & `MEMORY.DMP`).
- **Browser Caches:** Google Chrome, Microsoft Edge, Mozilla Firefox, Brave, and Opera disk and V8 code caches.
- **Developer Caches:** `pip`, `npm`, NuGet, Yarn, and Gradle caches.
- **Gaming & App Caches:** Steam download/package caches, Epic Games Launcher cache, Teams, Discord, and Slack caches.
- **Network & Maintenance Utilities:** One-click **Flush DNS Cache** (`ipconfig /flushdns`) and **Clear Event Logs** (`wevtutil`).

---

## 🛡️ Built-in Safety Guardrails
- **Hardcoded Path Blacklist:** Prevents deletion of core OS components (`C:\Windows`, `C:\Windows\System32`, `C:\Users`, root drives).
- **Protected Processes:** Cannot kill vital Windows core processes (`explorer.exe`, `svchost.exe`, `csrss.exe`, `wininit.exe`, `services.exe`).
- **Automatic UAC Elevation:** Auto-prompts for Administrator privileges on launch.

---

## 🛠️ Building from Source

### Requirements
- Python 3.11+
- Install dependencies:
```bash
pip install -r requirements.txt
```

### Run
```bash
python main.py
```

### Compile Standalone Portable `.exe`
Run the included build script:
```cmd
build_exe.bat
```
The output executable will be generated at `./dist/VoidPurge.exe`.

---

## 📄 License

VoidPurge is released under the [MIT License](LICENSE). Free for everyone — personal and commercial use, no paywalls, no nag screens.
